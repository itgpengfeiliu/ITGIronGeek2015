package com.cei.kidvisionweb.service.impl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.AuthenticationServiceException;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.RememberMeAuthenticationToken;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.TransactionTemplate;
import org.springframework.util.Assert;

import com.cei.kidvisionweb.config.KidvisionWebConfig;
import com.cei.kidvisionweb.dao.ConfigDao;
import com.cei.kidvisionweb.dao.RegistrationDao;
import com.cei.kidvisionweb.dao.UserDao;
import com.cei.kidvisionweb.db.model.Config;
import com.cei.kidvisionweb.db.model.Registration;
import com.cei.kidvisionweb.db.model.User;
import com.cei.kidvisionweb.service.UserLoginService;
import com.cei.kidvisionweb.service.util.LoggedUser;
import com.cei.kidvisionweb.service.util.SimpleUser;
import com.google.gson.GsonBuilder;

public class UserLoginServiceImpl implements UserLoginService {

	private static Logger logger = LoggerFactory.getLogger(UserLoginServiceImpl.class);
    private final TransactionTemplate transactionTemplate;
    
    @Autowired
    private UserDao userDao;
    @Autowired
    private ConfigDao configDao;
    @Autowired
    private RegistrationDao registrationDao;
    
    @Value("#{kidvisionProperties['process.payment']}")
    private int processPayment;
    
    @Autowired
    private AuthenticationManager authenticationManager;
    private static final String internalHashKeyForAutomaticLoginAfterRegistration = "magicInternalHashKeyForAutomaticLoginAfterRegistration";
    
    @Autowired
    public UserLoginServiceImpl(PlatformTransactionManager transactionManager) {
        Assert.notNull(transactionManager, "The 'transactionManager' argument must not be null.");
        this.transactionTemplate = new TransactionTemplate(transactionManager);
        this.transactionTemplate.setPropagationBehavior(TransactionDefinition.PROPAGATION_REQUIRES_NEW);
        this.transactionTemplate.setTimeout(30);
        logger.debug("transaction template = " + transactionTemplate);
    }
    
    @Override
    public LoggedUser getLoggedUserUtil() {
    	LoggedUser loggedUserDetails = null;
    	try {
	        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
	        if (isAuthenticated(authentication)) {
	            Object principal = authentication.getPrincipal();
	            if (principal instanceof LoggedUser) {
	                loggedUserDetails = ((LoggedUser) principal);
	            } else {
	            	throw new Exception("Expected class of authentication principal is LoggedUser. Given: " + principal.getClass());
	            }
	        }
    	} catch (Exception ex) {
    		logger.error("Error occurred: : ", ex);
    	}
        return loggedUserDetails;
    }
    
    
	@Override
    public boolean login(String username, String password) throws AuthenticationServiceException {
		boolean isAuthenticated = false;
		try {
			UsernamePasswordAuthenticationToken upat = new UsernamePasswordAuthenticationToken(username, password);
			logger.debug("UserLoginService login UsernamePasswordAuthenticationToken name " + upat.getName());
	        Authentication authentication = authenticationManager.authenticate(upat);
	        logger.debug("UserLoginSerivce login Authentication name " + authentication.getName());
	        isAuthenticated = isAuthenticated(authentication);
	        if (isAuthenticated) {
	        	logger.debug("login username " + username + " is authenticated , ");
	            SecurityContextHolder.getContext().setAuthentication(authentication);
	            StringBuilder sb = new StringBuilder();
	            for (GrantedAuthority ga : authentication.getAuthorities()) {
	            	sb.append(ga.getAuthority() + " , ");
	            }
				logger.debug(" GrantedAuthority = " + sb);
	        }
	        return isAuthenticated;
		} catch (AuthenticationServiceException as) {
			logger.error("AuthenticationServiceException");
			return isAuthenticated;
		} catch (BadCredentialsException be) {
			logger.error("BadCredentialsException: Invalid username or password.");
			return isAuthenticated;
		} catch (Exception ex) {
			logger.error("IOException: ", ex);
			return isAuthenticated;
		}
    }
	
	private boolean isAuthenticated(Authentication authentication) {
        return authentication != null && !(authentication instanceof AnonymousAuthenticationToken) && authentication.isAuthenticated();
    }
	
	@Override
    public void logout() {
        SecurityContextHolder.getContext().setAuthentication(null);
    }
	
	@Override
    public boolean isLoggedIn() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        //logger.debug("UserLoginSerivce isLoggedIn Authentication name " + authentication.getName());
        return isAuthenticated(authentication);
    }
	
	// does not work
	@Override
	@Transactional
    public boolean login(Integer userId) {
        boolean isLoginSuccesfull = false;
        User user = userDao.get(userId);
        if (user != null) {
        	LoggedUser userDetails = new LoggedUser(user);
            final RememberMeAuthenticationToken rememberMeAuthenticationToken = new RememberMeAuthenticationToken(internalHashKeyForAutomaticLoginAfterRegistration, userDetails, null);
            rememberMeAuthenticationToken.setAuthenticated(true);
            SecurityContextHolder.getContext().setAuthentication(rememberMeAuthenticationToken);
            isLoginSuccesfull = true;
        }
        return isLoginSuccesfull;
    }

//	@Override
//	@Transactional
//	public User getLoggedUserModel() {
//		User loggedUser = null;
//        LoggedUser userDetails = getLoggedUserUtil();
//        if (userDetails != null) {            
//            loggedUser = userDao.get(userDetails.getId());
//        }
//        return loggedUser;
//	}
	
	@Override
	@Transactional
	public String getLoggedSimpleUser(Integer userId) {
		String result = null;
        try {
        	      	
			User user = userDao.get(userId);
			if (user != null) {
				Config config = null;
				Registration registration = null;
				
				if (user.getRegistrationtypeId() == 2) { // teacher membership
					config = getConfig();
					registration = registrationDao.getRegistrationByConfig(userId, config.getCurrentSchoolYearFrom());
	        	}
				
				SimpleUser sUser = new SimpleUser(user, config, registration, processPayment);
				result = new GsonBuilder().serializeNulls().create().toJson(sUser);
				logger.debug("getLoggedSimpleUser SimpleUser result : " + result);
				return result;
	        }
        } 
        catch (Exception ex) {
            logger.error("Error occurred::", ex);
        }
        return result;
	}
	
	@Override
	@Transactional
	public Config getConfig() {
		try {
			List<Config> msgs = configDao.getListOrderByProperty("currentSchoolYearFrom");
			if (msgs != null) {
				logger.debug("getConfig : " + msgs.get(0).toString());
				return msgs.get(0);
			}
		} catch (Exception ex) {
            logger.error("Error occurred::", ex);
        } 
		return null;
	}
		
	@Override
	@Transactional
	public User checkUserExist(String email) {
		User user = null;
		if (email != null) {
			user = userDao.getUniqueByProperty("email", email);
			//user = userDao.getUniqueByPropertyCaseSensitive("email", email);
		}
        return user;
	}
	
	@Override
	@Transactional
	public User setUserTempPassword(String email, String userName) {
		if (email != null) {
			User user = userDao.getUniqueByProperty("email", email);
			//User user = userDao.getUniqueByPropertyCaseSensitive("email", email);
			
			if (user != null) {
				if (user.getUserName().equals(userName)) {
					String tempPassword = KidvisionWebConfig.generateRandomPassword();
					user.setPassword(tempPassword);
					user.setPasswordReset((short)1);
					userDao.update(user);
					
					return user;
				}
			}
		}
        return null;
	}
	
}
