package com.cei.kidvisionweb.dao;

import java.util.List;

import com.cei.kidvisionweb.db.model.UserModuleActivity;
import com.cei.kidvisionweb.db.model.UserModuleActivityFieldtripDatatable;

public interface UserModuleActivityDao extends GenericDao<UserModuleActivity, Long> {

	List<UserModuleActivityFieldtripDatatable> getUserModuleActivitiesFieldtrip();
	
	//List<UserModuleActivity> getUserSurveyActivities(int userId, int moduleId);
	
	//List<UserModuleActivity> getUserModuleActivities(int userId, int moduleId);
}
