

package com.cei.kidvisionweb.dao.impl;

import java.util.List;

import com.cei.kidvisionweb.dao.VideoDao;
import com.cei.kidvisionweb.db.model.Video;

/**
 *
 * @author Shrikant
 */
public class VideoDaoImpl extends GenericDaoImpl<Video, Long> implements VideoDao{
    
    @SuppressWarnings("unchecked")
	@Override
    public List<Video> getVideoWithoutStreamingId() {
    	List<Video> videos = null;
    	try {
	        videos = getSession().createQuery("from " + getPersistentClass().getName() + " as model where videoStreamingId is null").list();
    	} catch (Exception ex) {
			logger.error("Error occurred::", ex);
		}
		return videos;
    }
}
