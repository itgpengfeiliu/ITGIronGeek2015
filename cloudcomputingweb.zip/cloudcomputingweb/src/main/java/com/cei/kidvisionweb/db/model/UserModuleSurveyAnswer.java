package com.cei.kidvisionweb.db.model;


import java.util.Date;

import org.apache.commons.lang3.builder.ToStringBuilder;


public class UserModuleSurveyAnswer  implements java.io.Serializable {

     /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	private Integer id;
    private Integer userId;
    private Integer questionId;
    private Integer moduleId;
    private Integer answer;
    private String comment;
    private Date createdOn;
    private Integer userModuleActivityId;

    public UserModuleSurveyAnswer() {
    }

    public UserModuleSurveyAnswer(Integer userId, Integer moduleId, Integer questionId, Integer answer, Date createdOn) {
       this.userId = userId;
       this.moduleId = moduleId;
       this.questionId = questionId;
       this.answer = answer;
       this.createdOn = createdOn;
    }
   
    public Integer getId() {
        return this.id;
    }
    
    public void setId(Integer id) {
        this.id = id;
    }
    public Integer getUserId() {
        return this.userId;
    }
    
    public void setUserId(Integer userId) {
        this.userId = userId;
    }
    
    public Integer getQuestionId() {
        return this.questionId;
    }
    
    public void setQuestionId(Integer questionId) {
        this.questionId = questionId;
    }
    public Integer getAnswer() {
        return this.answer;
    }
    
    public void setAnswer(Integer answer) {
        this.answer = answer;
    }
    public Date getCreatedOn() {
        return this.createdOn;
    }
    
    public void setCreatedOn(Date createdOn) {
        this.createdOn = createdOn;
    }

    public Integer getModuleId() {
		return moduleId;
	}

	public void setModuleId(Integer moduleId) {
		this.moduleId = moduleId;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public Integer getUserModuleActivityId() {
		return userModuleActivityId;
	}

	public void setUserModuleActivityId(Integer userModuleActivityId) {
		this.userModuleActivityId = userModuleActivityId;
	}
	
	@Override
    public String toString() {
        return new ToStringBuilder(this).append("id", id).
                append("userId", userId).
                append("moduleId", moduleId).
                append("questionId", questionId).
                append("answer", answer).
                append("comment", comment).
                append("createdOn", createdOn).
                append("userModuleActivityId", userModuleActivityId).
                toString();
    }


}


