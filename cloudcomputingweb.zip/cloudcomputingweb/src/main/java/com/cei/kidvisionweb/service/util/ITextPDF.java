package com.cei.kidvisionweb.service.util;

import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cei.kidvisionweb.db.model.UserModuleTestTranscriptDetail;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.Image;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

public class ITextPDF {

	//private static String FILE = "E:/FirstPdf.pdf";
	//private static Font catFont = new Font(Font.FontFamily.COURIER, 17, Font.BOLD);
    //private static Font redFont = new Font(Font.FontFamily.TIMES_ROMAN, 12, Font.NORMAL, BaseColor.RED);
    //private static Font subFont = new Font(Font.FontFamily.HELVETICA, 8, Font.BOLD);
    private static Font normalBold = new Font(Font.FontFamily.TIMES_ROMAN, 11, Font.BOLD);
    private static Font normal = new Font(Font.FontFamily.COURIER, 11, Font.NORMAL);
    private static Font titleBold = new Font(Font.FontFamily.TIMES_ROMAN, 11, Font.BOLD);
    //private static Font small = new Font(Font.FontFamily.TIMES_ROMAN, 9, Font.NORMAL);
    private static Font xsmall = new Font(Font.FontFamily.TIMES_ROMAN, 8, Font.NORMAL);
    private static Font tableHeader = new Font(Font.FontFamily.HELVETICA, 11, Font.BOLD);
    //private static Font smallBold = new Font(Font.FontFamily.TIMES_ROMAN, 10, Font.BOLD);
    private static Font certificateName = new Font(Font.FontFamily.HELVETICA, 13, Font.BOLD);
    
    private static Logger logger = LoggerFactory.getLogger(ITextPDF.class);
    
    private Document document;
    private PdfPTable table;
    
    public ITextPDF(String path, int type) {
    	try {
    		if (type == 0) {
    			document = new Document(PageSize.A4, 10, 10, 30, 30); // 0.8 inch PageSize.A4.rotate() PageSize.A4_LANDSCAPE
    		}
    		if (type == 1) {
    			document = new Document(PageSize.A4.rotate(), 10, 10, 30, 30); // 0.8 inch PageSize.A4.rotate() PageSize.A4_LANDSCAPE
    		}
    		else {
    			document = new Document(PageSize.A4, 10, 10, 30, 30); // 0.8 inch PageSize.A4.rotate() PageSize.A4_LANDSCAPE
    		}
	    	
	        PdfWriter.getInstance(document, new FileOutputStream(path));
	        document.open();
    	}
    	catch (Exception ex) {
    		logger.error("ITextPDF " + ex.toString());
    	}
    }
    
    public void printUserModuleTestTranscript(String userId, String fullName, java.util.List<UserModuleTestTranscriptDetail> msgs, String imagesPath) {
    	try {
    		addMetaData();
    		addTitlePage(userId, fullName, imagesPath, msgs);
            //addContent(msgs, imagesPath);
            document.close();
	    }
		catch (Exception ex) {
			logger.error("printUserModuleTestTranscript " + ex.toString());
		}
    }
    
    public void printUserModuleTestCertificate(String userId, String fullName, String testyear, String imagesPath) {
    	try {
    		addCertificatePage(userId, fullName, imagesPath, testyear);
            //addContent(msgs, imagesPath);
            document.close();
	    }
		catch (Exception ex) {
			logger.error("testyear " + ex.toString());
		}
    }
    
    private void addCertificatePage(String userId, String fullName, String imagesPath, String testyear) throws DocumentException {
    	try {
    		logger.debug("imagePath = " + imagesPath);
    		
    		table = new PdfPTable(3);
 	    	table.setWidthPercentage(95);
            float[] widthPerc = {30, 40, 30};
 	    	table.setWidths(widthPerc);
 	    	 	    	
    		String cLogoPath = imagesPath + "/certificate-vpk-tilt-logo.png";
    		Image cLogoImage = Image.getInstance(cLogoPath);
    		cLogoImage.scaleToFit(150, 100);
    		
    		PdfPCell cell = new PdfPCell(cLogoImage);
    		cell.setHorizontalAlignment(Element.ALIGN_LEFT);
    		cell.setBorderWidth(0);
    		cell.setColspan(1);
    		table.addCell(cell);
    		
    		String cHeadPath = imagesPath + "/certificate-heading.png";
    		Image cHeadImage = Image.getInstance(cHeadPath);
    		cHeadImage.scaleToFit(200, 100);
    		
    		cell = new PdfPCell(cHeadImage);
    		cell.setHorizontalAlignment(Element.ALIGN_CENTER);
    		cell.setBorderWidth(0);
    		cell.setColspan(1);
    		table.addCell(cell);
    		
    		cell = new PdfPCell(new Phrase(" "));
    		cell.setBorderWidth(0);
    		cell.setColspan(1);
    		table.addCell(cell);
    		
                cell = new PdfPCell(new Phrase(" "));
    		cell.setBorderWidth(0);
    		cell.setColspan(3);
    		table.addCell(cell);
                
//                cell = new PdfPCell(new Phrase(" "));
//    		cell.setBorderWidth(0);
//    		cell.setColspan(3);
//    		table.addCell(cell);
                
    		cell = new PdfPCell(new Phrase(fullName, certificateName));
    		cell.setHorizontalAlignment(Element.ALIGN_CENTER);
    		cell.setBorderWidth(0);
    		cell.setColspan(3);
    		table.addCell(cell);
    		
    		String cNamePath = imagesPath + "/certificate-name.jpg";
    		Image cNameImage = Image.getInstance(cNamePath);
    		cNameImage.scaleToFit(500, 100);
    		
    		cell = new PdfPCell(cNameImage);
    		cell.setHorizontalAlignment(Element.ALIGN_CENTER);
    		cell.setBorderWidth(0);
    		cell.setColspan(3);
    		table.addCell(cell);
    		
            cell = new PdfPCell(new Phrase(" ")); 
    		cell.setBorderWidth(0);
    		cell.setColspan(3);
    		table.addCell(cell);
                
//            cell = new PdfPCell(new Phrase(" "));
//    		cell.setBorderWidth(0);
//    		cell.setColspan(3);
//    		table.addCell(cell);
                
    		String cDSigPath = imagesPath + "/certificate-dolores-signature.png";
    		Image cDSigImage = Image.getInstance(cDSigPath);
    		cDSigImage.scaleToFit(150, 100);
    		
    		cell = new PdfPCell(cDSigImage);
    		cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
    		cell.setBorderWidth(0);
    		cell.setColspan(1);
    		table.addCell(cell);
    		
    		String cWebURLPath = imagesPath + "/certificate_website_url.jpg"; // // certificate_website_url.jpg
    		Image cWebURLImage = Image.getInstance(cWebURLPath);
    		cWebURLImage.scaleToFit(150, 60);
    		
    		cell = new PdfPCell(cWebURLImage);
    		cell.setHorizontalAlignment(Element.ALIGN_CENTER);
    		cell.setBorderWidth(0);
    		cell.setColspan(1);
    		table.addCell(cell);
    		
//    		cell = new PdfPCell(new Phrase(" "));
//    		cell.setBorderWidth(0);
//    		cell.setColspan(1);
//    		table.addCell(cell);
    		
    		String cPSigPath = imagesPath + "/certificate-pennys-signature.png";
    		Image cPSigImage = Image.getInstance(cPSigPath);
    		cPSigImage.scaleToFit(150, 100);
    		
    		cell = new PdfPCell(cPSigImage);
    		cell.setHorizontalAlignment(Element.ALIGN_LEFT);
    		cell.setBorderWidth(0);
    		cell.setColspan(1);
    		table.addCell(cell);
    		
//                cell = new PdfPCell(new Phrase(" "));
//    		cell.setBorderWidth(0);
//    		cell.setColspan(3);
//    		table.addCell(cell);
                
//                cell = new PdfPCell(new Phrase(" "));
//    		cell.setBorderWidth(0);
//    		cell.setColspan(3);
//    		table.addCell(cell);
                
    		String cMiddlePath = imagesPath + "/certificate-middle-tc.png";
    		Image cMiddleImage = Image.getInstance(cMiddlePath);
    		cMiddleImage.scaleToFit(700, 180);
    		
    		cell = new PdfPCell(cMiddleImage);
    		cell.setHorizontalAlignment(Element.ALIGN_CENTER);
    		cell.setBorderWidth(0);
    		cell.setColspan(3);
    		table.addCell(cell);
    		
                cell = new PdfPCell(new Phrase(" "));
    		cell.setBorderWidth(0);
    		cell.setColspan(3);
    		table.addCell(cell);
                
                cell = new PdfPCell(new Phrase(" "));
    		cell.setBorderWidth(0);
    		cell.setColspan(3);
    		table.addCell(cell);
                
    		cell = new PdfPCell(new Phrase("Member ID #: " + userId));
    		cell.setHorizontalAlignment(Element.ALIGN_CENTER);
    		cell.setBorderWidth(0);
    		cell.setColspan(1);
    		//BaseColor ab = new BaseColor(196,237,107);
    		//cell.setBackgroundColor(ab);
    		table.addCell(cell);
    		
    		String cWPBTPath = imagesPath + "/certificate-wpbt.jpg";
    		Image cWPBTImage = Image.getInstance(cWPBTPath);
    		cWPBTImage.scaleToFit(150, 80);
    		
    		cell = new PdfPCell(cWPBTImage);
    		cell.setHorizontalAlignment(Element.ALIGN_CENTER);
    		cell.setBorderWidth(0);
    		cell.setColspan(1);
    		table.addCell(cell);
    		
    		cell = new PdfPCell(new Phrase("Membership Registration Year: " + testyear));
    		cell.setHorizontalAlignment(Element.ALIGN_CENTER);
    		cell.setBorderWidth(0);
    		//BaseColor aa = new BaseColor(196,237,107);
    		//cell.setBackgroundColor(aa);
    		cell.setColspan(1);
    		table.addCell(cell);
    		
    		document.add(table);
    	}
    	catch (Exception ex) {
    		logger.error("addContent " + ex.toString());
    	}
    }
    
    // iText allows to add metadata to the PDF which can be viewed in your Adobe
    // Reader
    // under File -> Properties
    private void addMetaData() {
      //document.addTitle("My first PDF");
      //document.addSubject("Using iText");
      //document.addKeywords("Java, PDF, iText");
      //document.addAuthor("Kidvision VPK");
      //document.addCreator("Kidvision VPK");
    }
    
    private void addTitlePage(String userId, String fullName, String imagesPath, java.util.List<UserModuleTestTranscriptDetail> msgs) throws DocumentException {
    	try {
    		String titlePath = imagesPath + "/transcript_title.png";
    		logger.debug("imagePath = " + imagesPath);
		    Image img = Image.getInstance(titlePath);
	        img.scaleToFit(550, 100);
    		
	        table = new PdfPTable(5);
	    	table.setWidthPercentage(95);
            float[] widthPerc = {23, 17, 22, 23, 15}; 
	    	table.setWidths(widthPerc);
	    	
	    	table.setHeaderRows(7);
	    	table.setFooterRows(2);
	    	table.setSplitRows(false);
    		
    		PdfPCell cell = new PdfPCell(img);
    		cell.setHorizontalAlignment(Element.ALIGN_LEFT);
    		cell.setBorderWidth(0);
    		cell.setColspan(5);
    		table.addCell(cell);
    		    	    
    	    cell = new PdfPCell(new Phrase("Student Name: ", normalBold));
    		cell.setHorizontalAlignment(Element.ALIGN_LEFT);
    		cell.setBorderWidth(0);
    		cell.setColspan(1);
    		table.addCell(cell);
    	    
    	    cell = new PdfPCell(new Phrase("" + fullName, normal));
    		cell.setHorizontalAlignment(Element.ALIGN_LEFT);
    		cell.setBorderWidth(0);
    		cell.setColspan(2);
    		table.addCell(cell);
    	    
    	    cell = new PdfPCell(new Phrase("Student Number: ", normalBold));
    		cell.setHorizontalAlignment(Element.ALIGN_LEFT);
    		cell.setBorderWidth(0);
    		cell.setColspan(1);
    		table.addCell(cell);
    	    
    	    cell = new PdfPCell(new Phrase("" + userId, normal));
    		cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
    		cell.setBorderWidth(0);
    		cell.setColspan(1);
    		table.addCell(cell);
    		
    		cell = new PdfPCell(new Phrase("Total Credits: ", normalBold));
    		cell.setHorizontalAlignment(Element.ALIGN_LEFT);
    		cell.setBorderWidth(0);
    		cell.setColspan(1);
    		table.addCell(cell);
    	    
    	    cell = new PdfPCell(new Phrase(Integer.toString(msgs.size()) + " IN-SERVICE HOURS OR " + String.format("%.1f", msgs.size()*0.1) + " CEUs", normal));
    		cell.setHorizontalAlignment(Element.ALIGN_LEFT);
    		cell.setBorderWidth(0);
    		cell.setColspan(2);
    		table.addCell(cell);
    	        	    
    	    cell = new PdfPCell(new Phrase("Transcript Date: ", normalBold));
    		cell.setHorizontalAlignment(Element.ALIGN_LEFT);
    		cell.setBorderWidth(0);
    		cell.setColspan(1);
    		table.addCell(cell);
    	    
    	    cell = new PdfPCell(new Phrase("" + new SimpleDateFormat("MM/dd/yyyy").format(new Date()), normal));
    		cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
    		cell.setBorderWidth(0);
    		cell.setColspan(1);
    		table.addCell(cell);
	        
    	    cell = new PdfPCell(new Phrase(" "));
    		cell.setBorderWidth(0);
    		cell.setColspan(5);
    		table.addCell(cell);
    		
    		
    		cell = new PdfPCell(new Phrase("COURSE MODULE", tableHeader));
    		cell.setHorizontalAlignment(Element.ALIGN_LEFT);
    		cell.setVerticalAlignment(Element.ALIGN_CENTER);
            cell.setMinimumHeight(22f);
            cell.setColspan(1);
            
            cell.setBorderWidthRight(0);
            cell.setBorderWidthLeft(0.5f);
            cell.setBorderWidthBottom(0.5f);
            cell.setBorderWidthTop(0.5f);
            cell.setBackgroundColor(BaseColor.LIGHT_GRAY);
		    table.addCell(cell);
		    
		    cell = new PdfPCell(new Phrase("DATE COMPLETED", tableHeader));
		    cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
		    cell.setVerticalAlignment(Element.ALIGN_CENTER);
		    cell.setMinimumHeight(22f);
		    cell.setColspan(2);
		    cell.setBorderWidthRight(0);
		    cell.setBorderWidthLeft(0);
		    cell.setBorderWidthBottom(0.5f);
		    cell.setBorderWidthTop(0.5f);
		    cell.setBackgroundColor(BaseColor.LIGHT_GRAY);
		    table.addCell(cell);
		    
		    cell = new PdfPCell(new Phrase("CREDIT EARNED", tableHeader));
		    cell.setHorizontalAlignment(Element.ALIGN_CENTER);
		    cell.setVerticalAlignment(Element.ALIGN_CENTER);
		    cell.setColspan(2);
		    cell.setMinimumHeight(22f);
		    cell.setBorderWidthLeft(0);
		    cell.setBorderWidthRight(0.5f);
		    cell.setBorderWidthBottom(0.5f);
		    cell.setBorderWidthTop(0.5f);
		    cell.setBackgroundColor(BaseColor.LIGHT_GRAY);
		    table.addCell(cell);
		    
		    
//		    cell = new PdfPCell(new Phrase("page 1 of x", tableHeader));
//    		cell.setBorderWidth(0);
//    		cell.setColspan(5);
//    		table.addCell(cell);
		    
		    cell = new PdfPCell(new Phrase(" "));
		    cell.setBorderWidthLeft(0);
		    cell.setBorderWidthRight(0);
		    cell.setBorderWidthBottom(0);
		    cell.setBorderWidthTop(0.5f);
    		cell.setColspan(5);
    		table.addCell(cell);
    		
		    String sig = imagesPath + "/KV-VPK-Transcripts-Footer.jpg";//transcript_signature1.png";
		    logger.debug("imagePath sig = " + sig);
		    img = Image.getInstance(sig);
	        img.scaleToFit(530, 120);
	        
	        cell = new PdfPCell(img);
    		cell.setBorderWidth(0);
    		cell.setColspan(5);
    		table.addCell(cell);
    	    
//    	}
//    	catch (Exception ex) {
//    		logger.debug("addTitlePage " + ex.toString());
//    	}
//	}
//    
//    private void addContent(java.util.List<UserModuleTestTranscriptDetail> msgs, String imagesPath) throws DocumentException {
//    	try {

		    //PdfPCell cell;
		    for (UserModuleTestTranscriptDetail msg : msgs) {
		    	
		    	cell = new PdfPCell(new Phrase(msg.getTitle(), titleBold));
		    	cell.setColspan(2);
		    	cell.setBorderWidthBottom(0);
		    	cell.setBorderWidthTop(0);
	    		cell.setBorderWidthLeft(0.5f);
	    		cell.setBorderWidthRight(0);
	    		cell.setFixedHeight(18);
		    	table.addCell(cell);
		    	
		    	cell = new PdfPCell(new Phrase(new SimpleDateFormat("MM/dd/yyyy").format(msg.getDate()), titleBold));
		    	cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
		    	cell.setBorder(0);
		    	table.addCell(cell);
		    	
		    	cell = new PdfPCell(new Phrase("1 In-Service Hour/0.1 CEU", titleBold));
		    	cell.setHorizontalAlignment(Element.ALIGN_CENTER);
		    	cell.setColspan(2);
		    	cell.setBorderWidthBottom(0);
		    	cell.setBorderWidthTop(0);
		    	cell.setBorderWidthLeft(0);
		    	cell.setBorderWidthRight(0.5f);
		    	table.addCell(cell);
		    	// end course
		    	
		    	// Standards Heading
		    	cell = new PdfPCell(new Phrase("EARLY LEARNING AND DEVELOPMENT STANDARDS LEARNED IN THIS MODULE:", xsmall));
		    	cell.setBorderWidthBottom(0);
		    	cell.setBorderWidthTop(0);
	    		cell.setBorderWidthLeft(0.5f);
	    		cell.setBorderWidthRight(0.5f);
                cell.setColspan(5);
		    	table.addCell(cell);
		    	
                // s1
		    	cell = new PdfPCell(new Phrase(msg.getS1(), xsmall));
		    	cell.setBorderWidthBottom(0);
		    	cell.setBorderWidthTop(0);
	    		cell.setBorderWidthLeft(0.5f);
	    		cell.setBorderWidthRight(0);
                cell.setColspan(2);
		    	table.addCell(cell);
		    	
		    	// s2
		    	cell = new PdfPCell(new Paragraph(msg.getS2(), xsmall));
		    	cell.setBorderWidthBottom(0);
                cell.setBorderWidthTop(0);
                cell.setBorderWidthLeft(0);
                cell.setBorderWidthRight(0.5f);
                cell.setColspan(3);
		    	table.addCell(cell);
		    	
		    	// s3
		    	cell = new PdfPCell(new Phrase(msg.getS3(), xsmall));
		    	cell.setBorderWidthBottom(0);
                cell.setBorderWidthTop(0);
                cell.setBorderWidthLeft(0.5f);
                cell.setBorderWidthRight(0);
                cell.setColspan(2);
		    	table.addCell(cell);

		    	// s4
		    	cell = new PdfPCell(new Phrase(msg.getS4(), xsmall));
		    	cell.setBorderWidthBottom(0);
                cell.setBorderWidthTop(0);
                cell.setBorderWidthLeft(0);
                cell.setBorderWidthRight(0.5f);
                cell.setPaddingBottom(13f);
                cell.setColspan(3);
		    	table.addCell(cell);
			}
		    
		    cell = new PdfPCell(new Phrase(" "));
    		cell.setBorderWidth(0);
    		cell.setColspan(4);
    		table.addCell(cell);
		    
    	    
    	    document.add(table);
    	}
    	catch (Exception ex) {
    		logger.error("addContent " + ex.toString());
    	}
    }
}
