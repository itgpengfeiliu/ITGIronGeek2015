package com.cei.kidvisionweb.db.model;

import org.apache.commons.lang3.builder.ToStringBuilder;

public class Answer  implements java.io.Serializable {


     /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	private Integer id;
    private Integer questionId;
    private String answerValue;
    private short correct;
    private Integer sequence;
     
     
    public Answer() {
    }
    
    public Answer(short correct) {
        this.correct = correct;
    }
    public Answer(Integer questionId, String answerValue, short correct, Integer sequence) {
       this.questionId = questionId;
       this.answerValue = answerValue;
       this.correct = correct;
       this.sequence = sequence;
    }
   
    public Integer getId() {
        return this.id;
    }
    
    public void setId(Integer id) {
        this.id = id;
    }
    public Integer getQuestionId() {
        return this.questionId;
    }
    
    public void setQuestionId(Integer questionId) {
        this.questionId = questionId;
    }
    public String getAnswerValue() {
        return this.answerValue;
    }
    
    public void setAnswerValue(String answerValue) {
        this.answerValue = answerValue;
    }
    public short getCorrect() {
        return this.correct;
    }
    
    public void setCorrect(short correct) {
        this.correct = correct;
    }
    public Integer getSequence() {
        return this.sequence;
    }
    
    public void setSequence(Integer sequence) {
        this.sequence = sequence;
    }
    
    @Override
    public String toString() {
        return new ToStringBuilder(this).append("id", id).
                append("questionId", questionId).
                append("answerValue", answerValue).
                append("correct", correct).
                append("sequence", sequence).
                toString();
    }
}


