package com.cei.kidvisionweb.dao.impl;

import java.util.List;

import com.cei.kidvisionweb.dao.ResourceDao;
import com.cei.kidvisionweb.db.model.Resource;

public class ResourceDaoImpl extends GenericDaoImpl<Resource, Long> implements ResourceDao {

	@Override
	@SuppressWarnings("unchecked")
	public List<Resource> getModuleResources(int moduleId) {
		List<Resource> resources = null;
		try {
			resources = getSession().getNamedQuery("getModuleResources")
    				.setParameter("module_id", moduleId).list();
		} catch (Exception ex) {
			logger.error("Error occurred::", ex);
		}
		return resources;
	} 
}
