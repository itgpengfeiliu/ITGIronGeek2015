package com.cei.kidvisionweb.db.model;


import java.util.Date;
import org.apache.commons.lang3.builder.ToStringBuilder;

public class Video implements java.io.Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	private Integer id;
    private Integer moduleId;
    private String fileName;
    private String videoStreamingId;
    private String videoStreamingTitle;
    private short isOverview;
    private Byte sequence;
    private Date createdOn;
    private Integer createdbyId;

	public Video() {
		super();
    }

    public Video(Integer moduleId, String fileName, String videoStreamingId, short isOverview, Byte sequence, Date createdOn, Integer createdbyId) {
       this.moduleId = moduleId; 
       //this.module = module;  Module module
       this.fileName = fileName;
       this.videoStreamingId = videoStreamingId;
       this.isOverview = isOverview;
       this.sequence = sequence;
       this.createdOn = createdOn;
       this.createdbyId = createdbyId;
    }
   
    public Integer getId() {
        return this.id;
    }
    
    public void setId(Integer id) {
        this.id = id;
    }
    public Integer getModuleId() {
        return this.moduleId;
    }
    
    public void setModuleId(Integer moduleId) {
        this.moduleId = moduleId;
    }
    public String getFileName() {
        return this.fileName;
    }
    
    public void setFileName(String fileName) {
        this.fileName = fileName;
    }
    public String getVideoStreamingId() {
        return this.videoStreamingId;
    }
    
    public void setVideoStreamingId(String videoStreamingId) {
        this.videoStreamingId = videoStreamingId;
    }
    public short getIsOverview() {
        return this.isOverview;
    }
    
    public void setIsOverview(short isOverview) {
        this.isOverview = isOverview;
    }
    public Byte getSequence() {
        return this.sequence;
    }
    
    public void setSequence(Byte sequence) {
        this.sequence = sequence;
    }
    public Date getCreatedOn() {
        return this.createdOn;
    }
    
    public void setCreatedOn(Date createdOn) {
        this.createdOn = createdOn;
    }
    public Integer getCreatedbyId() {
        return this.createdbyId;
    }
    
    public void setCreatedbyId(Integer createdbyId) {
        this.createdbyId = createdbyId;
    }

    public String getVideoStreamingTitle() {
		return videoStreamingTitle;
	}

	public void setVideoStreamingTitle(String videoStreamingTitle) {
		this.videoStreamingTitle = videoStreamingTitle;
	}

	@Override
    public String toString() {
        return new ToStringBuilder(this).append("id", id).
                append("moduleId", moduleId).
                append("fileName", fileName).
                append("videoStreamingId", videoStreamingId).
                append("isOverview", isOverview).
                append("sequence", sequence).
                append("createdOn", createdOn).
                append("createdbyId", createdbyId).
                append("videoStreamingTitle", videoStreamingTitle).
                toString();
    }


}


