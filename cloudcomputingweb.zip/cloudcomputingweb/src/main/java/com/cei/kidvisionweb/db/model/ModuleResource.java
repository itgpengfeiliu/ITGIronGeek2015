package com.cei.kidvisionweb.db.model;

import org.apache.commons.lang3.builder.ToStringBuilder;

public class ModuleResource  implements java.io.Serializable {

     /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private Integer id;
    private Integer moduleId;
    private Integer resourceId;
    private Byte deleted;

    public ModuleResource() {
    }

    public ModuleResource(Integer moduleId, Integer resourceId, Byte deleted) {
       this.moduleId = moduleId;
       this.resourceId = resourceId;
       this.deleted = deleted;
    }
   
    public Integer getId() {
        return this.id;
    }
    
    public void setId(Integer id) {
        this.id = id;
    }
    public Integer getModuleId() {
        return this.moduleId;
    }
    
    public void setModuleId(Integer moduleId) {
        this.moduleId = moduleId;
    }
    public Integer getResourceId() {
        return this.resourceId;
    }
    
    public void setResourceId(Integer resourceId) {
        this.resourceId = resourceId;
    }
    public Byte getDeleted() {
        return this.deleted;
    }
    
    public void setDeleted(Byte deleted) {
        this.deleted = deleted;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("id", id).
                append("moduleId", moduleId).
                append("resourceId", resourceId).
                append("deleted", deleted).
                toString();
    }

}


