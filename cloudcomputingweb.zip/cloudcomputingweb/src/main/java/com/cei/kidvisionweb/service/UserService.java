package com.cei.kidvisionweb.service;

import com.cei.kidvisionweb.db.model.Address;
import com.cei.kidvisionweb.db.model.AuthenticationUserAnswer;
import com.cei.kidvisionweb.db.model.Config;
import com.cei.kidvisionweb.db.model.Registration;
import com.cei.kidvisionweb.db.model.User;

public interface UserService {


	//String addIfNotExistUserModulePretestActivity(int userId, byte completed);
	
	Config getConfig();
	
	String validUserPasswordRecoveryQuestionsAndAnswers(String username, String qid0, String qid1, String a0, String a1);
	
	String getPasswordRecoveryQuestions();
		
	String getUserPasswordRecoveryQuestions(String userName);
	
	Integer addUser(User newUser);
	
	String checkUserName(String username);
	
	String checkEmail(String email);

	String validNewUserEmailandUsername(String email, String username);
	
	Integer addRegistration(Registration registration);
	
	Integer updateRegistration(int userId, int currentRegistrationId);
	
	Integer addAddress(Address address);
	
	Integer addAuthenticationUserAnswer(AuthenticationUserAnswer authenUserAnswer);
	
	String getOccupationalTitles();
	
	String addUserLoginTime(Integer userId);
	
	int getProcessPayment();
}
