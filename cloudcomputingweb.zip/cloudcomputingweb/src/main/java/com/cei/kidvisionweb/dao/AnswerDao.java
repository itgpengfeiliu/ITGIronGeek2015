package com.cei.kidvisionweb.dao;

import java.util.List;

import com.cei.kidvisionweb.db.model.Answer;

/**
 *
 * @author Shrikant
 */
public interface AnswerDao extends GenericDao<Answer, Long> {

	List<Answer> getCorrectAnswers(String... strs);
}
