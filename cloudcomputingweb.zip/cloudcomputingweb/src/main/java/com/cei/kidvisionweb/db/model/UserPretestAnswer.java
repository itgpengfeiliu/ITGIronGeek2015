package com.cei.kidvisionweb.db.model;


import java.util.Date;
import org.apache.commons.lang3.builder.ToStringBuilder;


public class UserPretestAnswer  implements java.io.Serializable {


     /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	private Integer id;
     private Integer userId;
     private Integer questionId;
     private Integer answerId;
     private Date createdOn;

    public UserPretestAnswer() {
    }

    public UserPretestAnswer(Integer userId, Integer questionId, Integer answerId, Date createdOn) {
       this.userId = userId;
       this.questionId = questionId;
       this.answerId = answerId;
       this.createdOn = createdOn;
    }
   
    public Integer getId() {
        return this.id;
    }
    
    public void setId(Integer id) {
        this.id = id;
    }
    public Integer getUserId() {
        return this.userId;
    }
    
    public void setUserId(Integer userId) {
        this.userId = userId;
    }
    public Integer getQuestionId() {
        return this.questionId;
    }
    
    public void setQuestionId(Integer questionId) {
        this.questionId = questionId;
    }
    public Integer getAnswerId() {
        return this.answerId;
    }
    
    public void setAnswerId(Integer answerId) {
        this.answerId = answerId;
    }
    public Date getCreatedOn() {
        return this.createdOn;
    }
    
    public void setCreatedOn(Date createdOn) {
        this.createdOn = createdOn;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("id", id).
                append("userId", userId).
                append("questionId", questionId).
                append("answerId", answerId).
                append("createdOn", createdOn).
                toString();
    }


}


