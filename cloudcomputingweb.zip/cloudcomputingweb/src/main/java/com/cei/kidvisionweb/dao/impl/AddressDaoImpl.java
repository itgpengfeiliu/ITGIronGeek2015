
package com.cei.kidvisionweb.dao.impl;

import java.math.BigInteger;

import com.cei.kidvisionweb.dao.AddressDao;
import com.cei.kidvisionweb.db.model.Address;

/**
 *
 * @author Shrikant
 */
public class AddressDaoImpl extends GenericDaoImpl<Address, Long> implements AddressDao{
        
    @Override
    public BigInteger countAllCountyState() {
    	BigInteger count = new BigInteger("0");
        try {
        	String sql = " select count(distinct county, state) as count " 
            		+ " from address "
        			+ " where county IS NOT NULL and state IS NOT NULL ;";
        	count = (BigInteger) getSession().createSQLQuery(sql).uniqueResult();
        } catch (Exception ex) {
            logger.error("Error occurred::", ex);
        }
        return count;
    }
}
