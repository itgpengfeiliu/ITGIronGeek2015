package com.cei.kidvisionweb.db.model;

import java.util.Date;
import org.apache.commons.lang3.builder.ToStringBuilder;

public class AuthenticationUserAnswer implements java.io.Serializable {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	private Integer id;
    private Integer authenticationQuestionId;
    private String answer;
    private Integer userId;
    private Date createdOn;
    private Date updatedOn;

    public AuthenticationUserAnswer() {
    }

    public AuthenticationUserAnswer(Integer id) {
        this.id = id;
    }

    public AuthenticationUserAnswer(Integer authenticationQuestionId, String answer, Integer userId, Date createdOn, Date updatedOn) {
        this.authenticationQuestionId = authenticationQuestionId;
        this.answer = answer;
        this.userId = userId;
        this.createdOn = createdOn;
        this.updatedOn = updatedOn;
    }

    public Integer getId() {
        return this.id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getAuthenticationQuestionId() {
        return this.authenticationQuestionId;
    }

    public void setAuthenticationQuestionId(Integer authenticationQuestionId) {
        this.authenticationQuestionId = authenticationQuestionId;
    }

    public String getAnswer() {
        return this.answer;
    }

    public void setAnswer(String answer) {
        this.answer = answer;
    }

    public Integer getUserId() {
        return this.userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public Date getCreatedOn() {
        return this.createdOn;
    }

    public void setCreatedOn(Date createdOn) {
        this.createdOn = createdOn;
    }

    public Date getUpdatedOn() {
        return this.updatedOn;
    }

    public void setUpdatedOn(Date updatedOn) {
        this.updatedOn = updatedOn;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("id", id).
                append("authenticationQuestionId", authenticationQuestionId).
                append("answer", answer).
                append("userId", userId).
                append("createdOn", createdOn).
                append("updatedOn", updatedOn).
                toString();
    }

}
