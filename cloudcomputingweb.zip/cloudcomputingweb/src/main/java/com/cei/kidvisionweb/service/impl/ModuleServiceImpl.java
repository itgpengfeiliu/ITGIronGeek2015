package com.cei.kidvisionweb.service.impl;


import com.cei.kidvisionweb.config.KidvisionWebConfig;
import com.cei.kidvisionweb.dao.AddressDao;
import com.cei.kidvisionweb.dao.AuthenticationUserAnswerDao;
import com.cei.kidvisionweb.dao.ConfigDao;
import com.cei.kidvisionweb.dao.ModuleDao;
import com.cei.kidvisionweb.dao.ModuleSurveyQuestionDao;
import com.cei.kidvisionweb.dao.QuestionDao;
import com.cei.kidvisionweb.dao.AnswerDao;
import com.cei.kidvisionweb.dao.RegistrationDao;
import com.cei.kidvisionweb.dao.ResourceDao;
import com.cei.kidvisionweb.dao.StandardDao;
import com.cei.kidvisionweb.dao.SurveyQuestionDao;
import com.cei.kidvisionweb.dao.SurveyResultDao;
import com.cei.kidvisionweb.dao.UserDao;
import com.cei.kidvisionweb.dao.UserModuleActivityDao;
import com.cei.kidvisionweb.dao.UserModulePretestAnswerDao;
import com.cei.kidvisionweb.dao.UserModuleSurveyAnswerDao;
import com.cei.kidvisionweb.dao.UserModuleTestAnswerDao;
import com.cei.kidvisionweb.dao.UserModuleTestDao;
import com.cei.kidvisionweb.dao.UserPretestAnswerDao;
import com.cei.kidvisionweb.dao.UserSurveyAnswerDao;
import com.cei.kidvisionweb.db.model.Address;
import com.cei.kidvisionweb.db.model.Answer;
import com.cei.kidvisionweb.db.model.AuthenticationUserAnswer;
import com.cei.kidvisionweb.db.model.Config;
import com.cei.kidvisionweb.db.model.Module;
import com.cei.kidvisionweb.db.model.ModuleSurveyQuestion;
import com.cei.kidvisionweb.db.model.Question;
import com.cei.kidvisionweb.db.model.Registration;
import com.cei.kidvisionweb.db.model.Resource;
import com.cei.kidvisionweb.db.model.Standard;
import com.cei.kidvisionweb.db.model.SurveyQuestion;
import com.cei.kidvisionweb.db.model.User;
import com.cei.kidvisionweb.db.model.UserModuleActivity;
import com.cei.kidvisionweb.db.model.UserModulePretestAnswer;
import com.cei.kidvisionweb.db.model.UserModuleSurveyAnswer;
import com.cei.kidvisionweb.db.model.UserModuleTest;
import com.cei.kidvisionweb.db.model.UserModuleTestAnswer;
import com.cei.kidvisionweb.db.model.UserModuleTestTranscriptDetail;
import com.cei.kidvisionweb.db.model.UserModuleTestTranscriptTitle;
import com.cei.kidvisionweb.db.model.UserPretestAnswer;
import com.cei.kidvisionweb.db.model.UserSurveyAnswer;
import com.cei.kidvisionweb.service.ModuleService;
import com.cei.kidvisionweb.service.util.ITextPDF;
import com.cei.kidvisionweb.service.util.SagePayment;
import com.cei.kidvisionweb.service.util.SimpleUser;
import com.google.gson.GsonBuilder;

import java.io.File;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.TransactionTemplate;
import org.springframework.util.Assert;

/**
 *
 * @author Shrikant
 */

public class ModuleServiceImpl implements ModuleService{
    
    private static Logger logger = LoggerFactory.getLogger(ModuleServiceImpl.class);
    private final TransactionTemplate transactionTemplate;
    
    @Autowired
    private AddressDao addressDao;
    @Autowired
    private UserDao userDao;
    @Autowired
    private ModuleDao moduleDao;
    @Autowired
    private StandardDao standardDao;
    @Autowired
    private QuestionDao questionDao;
    @Autowired
    private AnswerDao answerDao;
    @Autowired
    private UserModuleActivityDao userModuleActivityDao;
    @Autowired
    private UserModuleTestDao userModuleTestDao;
    @Autowired
    private UserPretestAnswerDao userPretestAnswerDao;
    @Autowired
    private UserModulePretestAnswerDao userModulePretestAnswerDao;
    @Autowired
    private UserModuleTestAnswerDao userModuleTestAnswerDao;
    @Autowired
    private UserSurveyAnswerDao userSurveyAnswerDao;
    @Autowired
    private SurveyResultDao surveyResultDao;
    @Autowired
    private SurveyQuestionDao surveyQuestionDao;
    @Autowired
    private AuthenticationUserAnswerDao authenUserAnswerDao;
    @Autowired
    private ResourceDao resourceDao;
    @Autowired
    private RegistrationDao registrationDao;
    @Autowired
    private ConfigDao configDao;
    @Autowired
    private ModuleSurveyQuestionDao moduleSurveyQuestionDao;
    @Autowired
    private UserModuleSurveyAnswerDao userModuleSurveyAnswerDao;
    
    @Value("#{kidvisionProperties['process.payment']}")
    private int processPayment;
    
	@Value("#{kidvisionProperties['sagepayment.M_ID']}")
    private String M_ID;
	
	@Value("#{kidvisionProperties['sagepayment.M_KEY']}")
    private String M_KEY;
	
	@Value("#{kidvisionProperties['sagepayment.T_APPLICATION_ID']}")
    private String T_APPLICATION_ID;
    
    @Autowired
    public ModuleServiceImpl( PlatformTransactionManager transactionManager) {
        Assert.notNull(transactionManager, "The 'transactionManager' argument must not be null.");
        this.transactionTemplate = new TransactionTemplate(transactionManager);
        this.transactionTemplate.setPropagationBehavior(TransactionDefinition.PROPAGATION_REQUIRES_NEW);
        this.transactionTemplate.setTimeout(30);
        logger.debug("transaction template = " + transactionTemplate);
    }
    
    @Override
    @Transactional
    @PreAuthorize("hasAnyRole('Administrator', 'User')")
    public String triggerRegistrationType(int userId, boolean isContinue) throws AccessDeniedException {
        String result = null;
        try {
        	User user = userDao.get(userId);
			if (user != null) {
				
				if (isContinue) {
		        	Config config = getConfig();
					Registration registration = registrationDao.getRegistrationByConfig(userId, config.getCurrentSchoolYearFrom());
		      	  
		        	if (registration == null) {
		    			registration = new Registration();
		        		registration.setUserId(userId);
		        		registration.setCreatedonDatetime(new Date());
		        		registration.setIsActive(true);
		        		registration.setCreatedbyId(userId);
		        		registration.setFromDatetime(config.getCurrentSchoolYearFrom());
		        		registration.setToDatetime(config.getCurrentSchoolYearTo());
		        		registrationDao.add(registration);
		        		Integer registrationId = registration.getId();
		        		
		        		user.setRegistrationtypeId((byte)2);
		        		user.setCurrentRegistrationId(registrationId);
		        		userDao.update(user);
		        		
		        		user = userDao.get(userId);
		        		registration = registrationDao.getRegistrationByConfig(userId, config.getCurrentSchoolYearFrom());
		    		}
		        	else {
		        		if ( !registration.getIsActive() ) {
			        		registration.setIsActive(true);
			        		registration.setModifiedbyId(userId);
			        		registration.setModifiedonDatetime(new Date());
			        		registrationDao.update(registration);
		        		}
		        	}
		        	
		        	SimpleUser sUser = new SimpleUser(user, config, registration, processPayment);
					result = new GsonBuilder().serializeNulls().create().toJson(sUser);
				}
				else {
					user.setRegistrationtypeId((byte)1);
					user.setCurrentRegistrationId(null);
					userDao.update(user);
					
					SimpleUser sUser = new SimpleUser(user);
					result = new GsonBuilder().serializeNulls().create().toJson(sUser);
				}
			}
			logger.debug("triggerRegistrationType result : " + result);
        } 
        catch (Exception ex) {
            logger.error("Error occurred::", ex);
        }
        return result;
    }
    
    @Override
    @Transactional
    @PreAuthorize("hasAnyRole('Administrator', 'User')")
    public String addUserSurveyAnswers(int userId, int surveyQuestionId, byte answer, int moduleId) throws AccessDeniedException {
        String result = "false";
        try {
        	UserSurveyAnswer usa = new UserSurveyAnswer();
        	usa.setUserId(userId);
        	usa.setSurveyQuestionId(surveyQuestionId);
        	usa.setSurveyAnswerYesNo(answer);
        	usa.setCreatedOn(new Date());
        	usa.setModuleId(moduleId);
        	userSurveyAnswerDao.add(usa);
        	logger.debug("addUserSurveyAnswers : " + usa.toString());
        	
//        	SurveyResult sr = surveyResultDao.get(surveyQuestionId);
//        	if (answer == 1) {
//        		sr.setYes(sr.getYes()+1);
//        	}
//        	else {
//        		sr.setNo(sr.getNo()+1);
//        	}
//        	surveyResultDao.update(sr);
//        	logger.debug("update SurveyResult : " + sr.toString());
        	
        	result = "true";
        } 
        catch (Exception ex) {
            logger.error("Error occurred::", ex);
        }
        return result;
    }
    
    @Override
    @Transactional
    @PreAuthorize("hasAnyRole('Administrator', 'User')")
    public int scoreUserModuleTest(String qaids) {
    	int score = 0;
        try {
        	logger.debug("scoreUserModuleTest param qaids : " + qaids);
        	String[] params = qaids.split(",");
        	String[] qids = Arrays.copyOfRange(params, 0, params.length/2);
        	String[] aids = Arrays.copyOfRange(params, params.length/2, params.length);
        	String[] strs = new String[params.length];
        	for (int i = 0; i < qids.length; i++){
        		strs[i*2] = "questionId";
        		strs[i*2+1] = qids[i];
            }
         	List<Answer> msgs = answerDao.getCorrectAnswers(strs);

    		for (Answer a : msgs) {
    			logger.debug("correct answer id : " + a.getId());
    			if (a.getCorrect() == (short)1) {
    				for (int i = 0; i < aids.length; i++) {
    					if ((int)a.getId() == Integer.parseInt(aids[i])) {
    						logger.debug("user answer id : " + aids[i]);
    						score++;
    					}
    				}
    			}
    		}
        	return score;
        } 
        catch (Exception ex) {
            logger.error("Error occurred::", ex);
        }
        return score;
    }
    
    
    @Override
    @Transactional
    @PreAuthorize("hasAnyRole('Administrator', 'User')")
    public String addUserPretestAnswers(int userId, String qaids) throws AccessDeniedException {
        String result = "false";
        try {
        	String[] params = qaids.split(",");
        	String[] qids = Arrays.copyOfRange(params, 0, params.length/2);
        	String[] aids = Arrays.copyOfRange(params, params.length/2, params.length);
        	UserPretestAnswer userPretestAnswer = null;
        	Date date = new Date();
        	for (int i = 0; i < qids.length; i++){
        		logger.debug("question id = " + qids[i] + " , answer id = " + aids[i]);
        		userPretestAnswer = new UserPretestAnswer();
        		userPretestAnswer.setUserId(userId);
        		userPretestAnswer.setQuestionId(Integer.parseInt(qids[i]));
        		userPretestAnswer.setAnswerId(Integer.parseInt(aids[i]));
        		userPretestAnswer.setCreatedOn(date);
        		userPretestAnswerDao.add(userPretestAnswer);
        		logger.debug(" addUserPretestAnswers update : " + userPretestAnswer.toString());
        	}
        	result = "true";
        } 
        catch (Exception ex) {
            logger.error("Error occurred::", ex);
        }
        return result;
    }
    
    @Override
    @Transactional
    @PreAuthorize("hasAnyRole('Administrator', 'User')")
    public String addUserModuleSurveyAnswer(int userId, int moduleId, int questionId, int answer, String comment, int userModuleActivityId) throws AccessDeniedException {
        String result = null;
        try {
    		logger.debug("addUserModuleSurveyAnswer userId = " + userId 
    				+ " , moduleId = " + moduleId + " , userModuleActivityId = " + userModuleActivityId
    				+ " , questionId = " + questionId
    				+ " , answer = " + answer + " , comment " + comment);
    		UserModuleSurveyAnswer newUserModuleSurveyAnswer = new UserModuleSurveyAnswer();
    		newUserModuleSurveyAnswer.setUserId(userId);
    		newUserModuleSurveyAnswer.setModuleId(moduleId);
    		newUserModuleSurveyAnswer.setQuestionId(questionId);
    		newUserModuleSurveyAnswer.setAnswer(answer);
    		newUserModuleSurveyAnswer.setComment(comment);
    		if (userModuleActivityId == -1) {
    			newUserModuleSurveyAnswer.setUserModuleActivityId(null);
			}
    		else {
    			newUserModuleSurveyAnswer.setUserModuleActivityId(userModuleActivityId);
    		}
    		
    		newUserModuleSurveyAnswer.setCreatedOn(new Date());
        	
    		userModuleSurveyAnswerDao.add(newUserModuleSurveyAnswer);
            logger.debug("add new : " + newUserModuleSurveyAnswer.toString());
            
        	result = newUserModuleSurveyAnswer.getId().toString();
        } 
        catch (Exception ex) {
            logger.error("Error occurred::", ex);
        }
        return result;
    }
    
    @Override
    @Transactional
    @PreAuthorize("hasAnyRole('Administrator', 'User')")
    public String addUserModulePretestAnswer(int userId, int moduleId, int questionId, int answerId, int userModuleActivityId) throws AccessDeniedException {
        String result = null;
        try {
        	logger.debug("addUserModulePretestAnswer userId = " + userId 
    				+ " , moduleId = " + moduleId
    				+ " , questionId = " + questionId
    				+ " , answerId = " + answerId);
        	UserModulePretestAnswer newUserModulePretestAnswer = new UserModulePretestAnswer();
    		newUserModulePretestAnswer.setUserId(userId);
    		newUserModulePretestAnswer.setModuleId(moduleId);
    		newUserModulePretestAnswer.setQuestionId(questionId);
    		newUserModulePretestAnswer.setAnswerId(answerId);
    		newUserModulePretestAnswer.setUserModuleActivityId(userModuleActivityId);
    		newUserModulePretestAnswer.setCreatedOn(new Date());
            	
    		userModulePretestAnswerDao.add(newUserModulePretestAnswer);
            logger.debug("addUserModulePretestAnswer : " + newUserModulePretestAnswer.toString());

        	result = newUserModulePretestAnswer.getId().toString();
        } 
        catch (Exception ex) {
            logger.error("Error occurred::", ex);
        }
        return result;
    }
    
    @Override
    @Transactional
    @PreAuthorize("hasAnyRole('Administrator', 'User')")
    public String addOrUpdateUserModuleTestAnswer(int userId, int userModuleTestId, int questionId, int answerId) throws AccessDeniedException {
        String result = null;
        try {
        	UserModuleTestAnswer newUserModuleTestAnswer = 
        			userModuleTestAnswerDao.getByProperties("userId", Integer.toString(userId), 
        												    "userModuleTestId", Integer.toString(userModuleTestId),
        												    "questionId", Integer.toString(questionId));
        	if (newUserModuleTestAnswer == null) {
        		logger.debug("addOrUpdateUserModuleTestAnswer not exist. userId = " + userId 
        				+ " , userModuleTestId = " + userModuleTestId
        				+ " , questionId = " + questionId
        				+ " , answerId = " + answerId);
        		newUserModuleTestAnswer = new UserModuleTestAnswer();
        		newUserModuleTestAnswer.setUserId(userId);
        		newUserModuleTestAnswer.setUserModuleTestId(userModuleTestId);
        		newUserModuleTestAnswer.setQuestionId(questionId);
        		newUserModuleTestAnswer.setAnswerId(answerId);
        		newUserModuleTestAnswer.setCreatedOn(new Date());
            	
        		userModuleTestAnswerDao.add(newUserModuleTestAnswer);
                logger.debug("add new : " + newUserModuleTestAnswer.toString());
            }
        	else {
        		newUserModuleTestAnswer.setAnswerId(answerId);
        		userModuleTestAnswerDao.add(newUserModuleTestAnswer);
        		logger.debug("addOrUpdateUserModuleTestAnswer update : " + newUserModuleTestAnswer.toString());
        	}
        	result = newUserModuleTestAnswer.getId().toString();
        } 
        catch (Exception ex) {
            logger.error("Error occurred::", ex);
        }
        return result;
    }
    
    @Override
    @Transactional
    @PreAuthorize("hasAnyRole('Administrator', 'User')")
    public String completeUserModuleTestE(int userModuleTestId) throws AccessDeniedException {
        String result = null;
        try {
        	UserModuleTest newUserModuleTest = userModuleTestDao.get(userModuleTestId);
        	if (newUserModuleTest != null) {
        		logger.debug("completeUserModuleTestE exist : " + newUserModuleTest.toString());
        		newUserModuleTest.setCompletedOn(new Date());
        		newUserModuleTest.setIsCompleted((byte)1);
        		
        		userModuleTestDao.update(newUserModuleTest);
                logger.debug("completeUserModuleTestE update : " + newUserModuleTest.toString());
            }
        	result = new GsonBuilder().serializeNulls().create().toJson(newUserModuleTest);
        } 
        catch (Exception ex) {
            logger.error("Error occurred::", ex);
        }
        return result;
    }
    
    @Override
    @Transactional
    @PreAuthorize("hasAnyRole('Administrator', 'User')")
    public String updateUserModuleTest(int userModuleTestId, int totalQuestionCount, int score) throws AccessDeniedException {
        String result = null;
        try {
        	UserModuleTest newUserModuleTest = userModuleTestDao.get(userModuleTestId);
        	if (newUserModuleTest != null) {
        		logger.debug("updateUserModuleTest exist : " + newUserModuleTest.toString());
        		newUserModuleTest.setCorrectAnswersCount((byte)score);
        		newUserModuleTest.setCompletedOn(new Date());
        		newUserModuleTest.setIsCompleted((byte)1);
        		if (score == totalQuestionCount) {
        			newUserModuleTest.setIsPassed((byte)1);
        		}
        		else {
        			newUserModuleTest.setIsPassed((byte)0);
        		}
        		newUserModuleTest.setTotalQuestionCount((byte)totalQuestionCount);
            	
        		userModuleTestDao.update(newUserModuleTest);
                logger.debug("updateUserModuleTest update : " + newUserModuleTest.toString());
            }
        	result = new GsonBuilder().serializeNulls().create().toJson(newUserModuleTest);
        } 
        catch (Exception ex) {
            logger.error("Error occurred::", ex);
        }
        return result;
    }
    
    @Override
    @Transactional
    @PreAuthorize("hasAnyRole('Administrator', 'User')")
    public String getUserModuleTests(int userId, int moduleId) throws AccessDeniedException {
        String result = null;
        try {
        	logger.debug("getUserModuleTests userId = " + userId + " , moduleId = " + moduleId);
        	List<UserModuleTest> msgs = userModuleTestDao.getUserModuleTests(userId, moduleId);
        	 			// userModuleTestDao.getListByProperties("userId", Integer.toString(userId), "moduleId", Integer.toString(moduleId));
        	logger.debug("getUserModuleTests result : " + msgs.size());
        	result = new GsonBuilder().serializeNulls().create().toJson(msgs);
        } 
        catch (Exception ex) {
            logger.error("Error occurred::", ex);
        }
        return result;
    }
    
    @Override
    @Transactional
    @PreAuthorize("hasAnyRole('Administrator', 'User')")
    public String getModuleSurveyQuestions() throws AccessDeniedException {
        String result = null;
        try {
        	logger.debug("getModuleSurveyQuestions ");
        	List<ModuleSurveyQuestion> msgs = moduleSurveyQuestionDao.getListOrderByProperty("id");
        	logger.debug("getModuleSurveyQuestions result : " + msgs.size());
        	result = new GsonBuilder().serializeNulls().create().toJson(msgs);
        } 
        catch (Exception ex) {
            logger.error("Error occurred::", ex);
        }
        return result;
    }
    
    
//    @Override
//    @Transactional
//    @PreAuthorize("hasAnyRole('Administrator', 'User')")
//    public String addIfNotExistUserModuleTest(int userId, int moduleId) throws AccessDeniedException {
//        String result = null;
//        try {
//        	UserModuleTest newUserModuleTest = 
//        			userModuleTestDao.getByProperties("userId", Integer.toString(userId), 
//        												  "moduleId", Integer.toString(moduleId));
//        	if (newUserModuleTest == null) {
//        		logger.debug("addIfNotExistUserModuleTest not exist. userId = " + userId + " , moduleId = " + moduleId);
//        		newUserModuleTest = new UserModuleTest();
//        		newUserModuleTest.setUserId(userId);
//        		newUserModuleTest.setModuleId(moduleId);
//        		newUserModuleTest.setStartedOn(new Date());
//        		newUserModuleTest.setIsCompleted((byte)0);
//            	
//        		userModuleTestDao.add(newUserModuleTest);
//                logger.debug("addIfNotExistUserModuleTest add new : " + newUserModuleTest.toString());
//            }
//        	else {
//        		logger.debug("addIfNotExistUserModuleTest existing : " + newUserModuleTest.toString());
//        	}
//        	result = newUserModuleTest.getId().toString();
//        } 
//        catch (Exception ex) {
//            logger.error("Error occurred::", ex);
//        }
//        return result;
//    }
    
    @Override
    @Transactional
    @PreAuthorize("hasAnyRole('Administrator', 'User')")
    public String addUserModuleTest(int userId, int moduleId) throws AccessDeniedException {
        String result = null;
        try {
            logger.debug("log user module test entry for userId = " + userId + " , moduleId = " + moduleId);
            UserModuleTest newUserModuleTest = new UserModuleTest();
            newUserModuleTest.setUserId(userId);
            newUserModuleTest.setModuleId(moduleId);
            newUserModuleTest.setStartedOn(new Date());
            newUserModuleTest.setIsCompleted((byte) 0);

            userModuleTestDao.add(newUserModuleTest);
            logger.debug("added new user module test entry : " + newUserModuleTest.toString());
            result = newUserModuleTest.getId().toString();
        } catch (Exception ex) {
            logger.error("Error occurred::", ex);
        }
        return result;
    }
    
    @Override
    @Transactional
    @PreAuthorize("hasAnyRole('Administrator', 'User')")
    public String getUserModuleTestE(int userModuleTestId) throws AccessDeniedException {
        String result = null;
        try {
        	UserModuleTest msgs = userModuleTestDao.get(userModuleTestId);
            result = new GsonBuilder().serializeNulls().create().toJson(msgs);
            logger.debug("getUserModuleTestE result: " + msgs.toString());
        } 
        catch (Exception ex) {
            logger.error("Error occurred::", ex);
        }
        return result;
    }
    
    @Override
    @Transactional
    @PreAuthorize("hasAnyRole('Administrator', 'User')")
    public Integer addUserModuleTestE(int userId, int moduleId, int fieldtripActivityId, byte correct, byte isPassed) throws AccessDeniedException {
        Integer result = null;
        try {
            logger.debug("addUserModuleTestE userId = " + userId + " , moduleId = " + moduleId + " , fieldtripActivityId = " + fieldtripActivityId);
            UserModuleTest newUserModuleTest = new UserModuleTest();
            newUserModuleTest.setUserId(userId);
            newUserModuleTest.setModuleId(moduleId);
            newUserModuleTest.setStartedOn(new Date());
            newUserModuleTest.setIsCompleted((byte) 0);
            newUserModuleTest.setCompletedOn(new Date());
            newUserModuleTest.setCorrectAnswersCount(correct);
            newUserModuleTest.setTotalQuestionCount((byte)4);
            newUserModuleTest.setIsPassed(isPassed);
            newUserModuleTest.setUserModuleActivityId(fieldtripActivityId);

            userModuleTestDao.add(newUserModuleTest);
            logger.debug("addUserModuleTestE result : " + newUserModuleTest.toString());
            result = newUserModuleTest.getId();
        } catch (Exception ex) {
            logger.error("Error occurred::", ex);
        }
        return result;
    }
    
    @Override
    @Transactional
    @PreAuthorize("hasAnyRole('Administrator', 'User')")
    public String getUserSurveyActivities(int userId, int moduleId) throws AccessDeniedException {
        String result = null;
        try {
            List<UserModuleActivity> msgs = userModuleActivityDao.getListByProperties("userId", 
            		Integer.toString(userId), "moduleId", Integer.toString(moduleId), 
            		"activityType", "survey");
            		// userModuleActivityDao.getUserSurveyActivities(userId, moduleId);
            result = new GsonBuilder().serializeNulls().create().toJson(msgs);
            logger.debug("getUserSurveyActivities result: " + msgs.size());
        } 
        catch (Exception ex) {
            logger.error("Error occurred::", ex);
        }
        return result;
    }
        
    @Override
    @Transactional
    @PreAuthorize("hasAnyRole('Administrator', 'User')")
    public String getUserModuleActivities(int userId, int moduleId) throws AccessDeniedException {
        String result = null;
        try {
            List<UserModuleActivity> msgs = userModuleActivityDao.getListByProperties("userId", Integer.toString(userId), "moduleId", Integer.toString(moduleId));
            		// userModuleActivityDao.getUserModuleActivities(userId, moduleId);
            result = new GsonBuilder().serializeNulls().create().toJson(msgs);
            logger.debug("getUserModuleActivities result: " + msgs.size());
        } 
        catch (Exception ex) {
            logger.error("Error occurred::", ex);
        }
        return result;
    }
    
    @Override
    @Transactional
    @PreAuthorize("hasAnyRole('Administrator', 'User')")
    public String updateUserModuleActivityCompleted(int activityId) throws AccessDeniedException {
        String result = "false";
        try {
        	Date datetime = new Date();
        	UserModuleActivity newUserModuleActivity = userModuleActivityDao.get(activityId);
        	if (newUserModuleActivity != null) {
        		newUserModuleActivity.setIsCompleted((byte)1);
            	newUserModuleActivity.setEndDatetime(datetime);
            	
        		userModuleActivityDao.update(newUserModuleActivity);
                logger.debug("updateUserModuleActivityCompleted update result: " + newUserModuleActivity.toString());
                result = new GsonBuilder().serializeNulls().create().toJson(newUserModuleActivity);
        	}
        } 
        catch (Exception ex) {
            logger.error("Error occurred::", ex);
        }
        return result;
    }
    
    @Override
    @Transactional
    @PreAuthorize("hasAnyRole('Administrator', 'User')")
    public String completeFieldTripModuleActivity(int activityId) throws AccessDeniedException {
        String result = "false";
        try {
        	Date datetime = new Date();
        	UserModuleActivity newUserModuleActivity = userModuleActivityDao.get(activityId);
        	if (newUserModuleActivity != null) {
        		newUserModuleActivity.setIsCompleted((byte)1);
            	newUserModuleActivity.setEndDatetime(datetime);
            	
        		userModuleActivityDao.update(newUserModuleActivity);
                logger.debug("completeFieldTripModuleActivity update result: " + newUserModuleActivity.toString());
                result = new GsonBuilder().serializeNulls().create().toJson(newUserModuleActivity);
        	}
        } 
        catch (Exception ex) {
            logger.error("Error occurred::", ex);
        }
        return result;
    }
    
    @Override
    @Transactional
    @PreAuthorize("hasAnyRole('Administrator', 'User')")
    public String addUserModuleActivity(int userId, int moduleId, String activityType) throws AccessDeniedException {
        String result = null;
        try {
            logger.debug("log user module activity for userId = " + userId + " , moduleId = " + moduleId + " , activityType = " + activityType);
            UserModuleActivity newUserModuleActivity = new UserModuleActivity();
            newUserModuleActivity.setUserId(userId);
            newUserModuleActivity.setModuleId(moduleId);
            //newUserModuleActivity.setActivityName(activityName);
            newUserModuleActivity.setIsCompleted((byte) 0);
            newUserModuleActivity.setStartDatetime(new Date());

            if (UserModuleActivity.ACTIVITY_TYPES.videos.name().indexOf(activityType) != -1) {
                newUserModuleActivity.setActivityType(UserModuleActivity.ACTIVITY_TYPES.videos.name());
            } //else if (UserModuleActivity.ACTIVITY_TYPES.pretest.name().indexOf(activityType) != -1) {
            //	newUserModuleActivity.setActivityType(UserModuleActivity.ACTIVITY_TYPES.pretest.name());
            //}
            else if (UserModuleActivity.ACTIVITY_TYPES.posttest.name().indexOf(activityType) != -1) {
                newUserModuleActivity.setActivityType(UserModuleActivity.ACTIVITY_TYPES.posttest.name());
            } else if (UserModuleActivity.ACTIVITY_TYPES.survey.name().indexOf(activityType) != -1) {
                newUserModuleActivity.setActivityType(UserModuleActivity.ACTIVITY_TYPES.survey.name());
            } else if (UserModuleActivity.ACTIVITY_TYPES.fieldtrip.name().indexOf(activityType) != -1) {
                newUserModuleActivity.setActivityType(UserModuleActivity.ACTIVITY_TYPES.fieldtrip.name());
            } else {
                return "invalid activity type";
            }
            userModuleActivityDao.add(newUserModuleActivity);
            logger.debug("new user mudue activity created : " + newUserModuleActivity.toString());
            result = Integer.toString(newUserModuleActivity.getId()); // new GsonBuilder().serializeNulls().create().toJson(newUserModuleActivity);
        } catch (Exception ex) {
            logger.error("Error occurred::", ex);
        }
        return result;
    }
    
    @Override
    @Transactional
    @PreAuthorize("hasAnyRole('Administrator', 'User')")
    public String addUserSurveyActivity(int userId, int moduleId) throws AccessDeniedException {
        String result = "false";
        try {
        	Date datetime = new Date();
        	UserModuleActivity newUserModuleActivity = new UserModuleActivity();
        	newUserModuleActivity.setUserId(userId);
        	newUserModuleActivity.setModuleId(moduleId);
        	newUserModuleActivity.setActivityType(UserModuleActivity.ACTIVITY_TYPES.survey.name());
        	newUserModuleActivity.setActivityName(null);
        	newUserModuleActivity.setStartDatetime(datetime);
        	newUserModuleActivity.setEndDatetime(datetime);
    		newUserModuleActivity.setIsCompleted((byte)1);
        	
            userModuleActivityDao.add(newUserModuleActivity);
            logger.debug("addUserSurveyActivity result: " + newUserModuleActivity.toString());
            result = "true";
        } 
        catch (Exception ex) {
            logger.error("Error occurred::", ex);
        }
        return result;
    }
    
    
    @Override
    @Transactional
    @PreAuthorize("hasAnyRole('Administrator', 'User')")
    public String addUserModuleActivityFiles(int userId, int moduleId, String activityName) throws AccessDeniedException {
        String result = "false";
        try {
        	Date datetime = new Date();
        	UserModuleActivity newUserModuleActivity = new UserModuleActivity();
        	newUserModuleActivity.setUserId(userId);
        	newUserModuleActivity.setModuleId(moduleId);
        	newUserModuleActivity.setActivityType(UserModuleActivity.ACTIVITY_TYPES.files.name());
        	newUserModuleActivity.setActivityName(activityName);
        	newUserModuleActivity.setStartDatetime(datetime);
        	newUserModuleActivity.setEndDatetime(datetime);
    		newUserModuleActivity.setIsCompleted((byte)1);
        	
            userModuleActivityDao.add(newUserModuleActivity);
            logger.debug("addUserModuleActivityFiles result: " + newUserModuleActivity.toString());
            result = "true";
        } 
        catch (Exception ex) {
            logger.error("Error occurred::", ex);
        }
        return result;
    }
    
    @Override
    @Transactional
    @PreAuthorize("hasAnyRole('Administrator', 'User')")
    public String getUserModuleTestAnswers(int userId, int userModuleTestId) throws AccessDeniedException {
        String result = null;
        try {
            List<UserModuleTestAnswer> msgs = userModuleTestAnswerDao.getListByProperties("userId", 
            		Integer.toString(userId), "userModuleTestId", Integer.toString(userModuleTestId)); 
            result = new GsonBuilder().serializeNulls().create().toJson(msgs);
            logger.debug("getUserModuleTestAnswers result: " + msgs.size());
        } 
        catch (Exception ex) {
            logger.error("Error occurred::", ex);
        }
        return result;
    }
    
    @Override
    @Transactional
    @PreAuthorize("hasAnyRole('Administrator', 'User')")
    public String getUserModuleTest(int userId, int moduleId) throws AccessDeniedException {
        String result = null;
        try {
        	UserModuleTest msgs = userModuleTestDao.getByProperties("userId", 
        			Integer.toString(userId), "moduleId", Integer.toString(moduleId));
            result = new GsonBuilder().serializeNulls().create().toJson(msgs);
            logger.debug("getUserModuleTest result: " + msgs.toString());
        } 
        catch (Exception ex) {
            logger.error("Error occurred::", ex);
        }
        return result;
    }
    
    @Override
    @Transactional
    @PreAuthorize("hasAnyRole('Administrator', 'User')")
    public String getPretestRandomQuestionsAndAnswers(int count) throws AccessDeniedException {
        String result = null;
        try {
            List<Question> msgs = questionDao.getRandomQuestionsAndAnswers(count);
            result = new GsonBuilder().serializeNulls().create().toJson(msgs);
            logger.debug("getPretestRandomQuestionsAndAnswers result: " + msgs.size());
        } 
        catch (Exception ex) {
            logger.error("Error occurred::", ex);
        }
        return result;
    }
    
    @Override
    @Transactional
    @PreAuthorize("hasAnyRole('Administrator', 'User')")
    public String getQuestionsAndAnswersByModule(int moduleId) throws AccessDeniedException {
        String result = null;
        try {
            List<Question> msgs = questionDao.getQuestionsAndAnswersByModule(moduleId);
            result = new GsonBuilder().serializeNulls().create().toJson(msgs);
            logger.debug("getQuestionsAndAnswersByModule result: " + msgs.size());
        } 
        catch (Exception ex) {
            logger.error("Error occurred::", ex);
        }
        return result;
    }
    
    
    @Override
    @Transactional
    @PreAuthorize("hasAnyRole('Administrator', 'User')")
    public String getStandardsByModule(int moduleId) throws AccessDeniedException {
        String result = null;
        try {
            List<Standard> msgs = standardDao.getModuleStandsByOrder(moduleId);
            result = new GsonBuilder().serializeNulls().create().toJson(msgs);
            logger.debug("getStandardsByModule result: " + msgs.size());
        } 
        catch (Exception ex) {
            logger.error("Error occurred::", ex);
        }
        return result;
    }
    
    
    @Override
    @Transactional
    @PreAuthorize("hasAnyRole('Administrator', 'User')")
    public String getModuleAndVideos(int ModuleId) throws AccessDeniedException {
        String result = null;
        try {
            Module msgs = moduleDao.get(ModuleId);// .getModuleAndVideos(ModuleId);
            result = new GsonBuilder().serializeNulls().create().toJson(msgs);
            logger.debug("getModuleAndVideos result: " + msgs.toString());
        } 
        catch (Exception ex) {
            logger.error("Error occurred::", ex);
        }
        return result;
    }
    
    @Override
    @Transactional
    @PreAuthorize("hasAnyRole('Administrator', 'User')")
    public String getModuleResources(int ModuleId) throws AccessDeniedException {
        String result = null;
        try {
            List<Resource> msgs = resourceDao.getModuleResources(ModuleId);
            result = new GsonBuilder().serializeNulls().create().toJson(msgs);
            logger.debug("getModuleResources result: " + msgs.size());
        } 
        catch (Exception ex) {
            logger.error("Error occurred::", ex);
        }
        return result;
    }
    
    @Override
    @Transactional
    @PreAuthorize("hasAnyRole('Administrator', 'User')")
    public String getAllModulesOrderBySequenceAndVideos() throws AccessDeniedException {
        String result = null;
        try {
            List<Module> msgs = moduleDao.getAllModulesOrderBySequenceAndVideos();
            result = new GsonBuilder().serializeNulls().create().toJson(msgs);
            logger.debug("getAllModulesOrderBySequenceAndVideos result: " + msgs.size());
        }
        catch (Exception ex) {
            logger.error("Error occurred::", ex);
        }
        return result;
    }
    
    @Override
    @Transactional
    @PreAuthorize("hasAnyRole('Administrator', 'User')")
    public String getUser(int userId) throws AccessDeniedException {
        String result = null;
        try {
        	User user = userDao.get(userId);
        	if (user != null) {
        	    SimpleUser sUser = new SimpleUser(user);
        		result = new GsonBuilder().serializeNulls().create().toJson(sUser);
        		logger.debug("getUser result: " + user.toString());
        	}
        } 
        catch (Exception ex) {
            logger.error("Error occurred::", ex);
        }
        return result;
    }
    
    @Override
    @Transactional
    @PreAuthorize("hasAnyRole('Administrator', 'User')")
    public int getProcessPayment() throws AccessDeniedException {
        return processPayment;
    }
    
    @Override
    @Transactional
    @PreAuthorize("hasAnyRole('Administrator', 'User')")
    public String updateUserPretestCompleted(int userId) throws AccessDeniedException {
        String result = null;
        try {
        	User user = userDao.get(userId);

        	if (user != null) {
        		user.setPretestCompleted((byte)1);
        		userDao.update(user);
        		SimpleUser sUser = new SimpleUser(user);
        		result = new GsonBuilder().serializeNulls().create().toJson(sUser);
        	}
            
            logger.debug("updateUserPretestCompleted result: " + user.toString());
        } 
        catch (Exception ex) {
            logger.error("Error occurred::", ex);
        }
        return result;
    }
    
    @Override
    @Transactional
    @PreAuthorize("hasAnyRole('Administrator', 'User')")
    public String updateUserPassword(int userId, String password) throws AccessDeniedException {
        String result = null;
        try {
        	User user = userDao.get(userId);

        	if (user != null) {
        		user.setPassword(password);
        		//user.setTempPassword(null);
        		user.setPasswordReset((short)0);
        		userDao.update(user);
        		SimpleUser sUser = new SimpleUser(user);
        		result = new GsonBuilder().serializeNulls().create().toJson(sUser);
        	}
            
            logger.debug("updateUserPassword result: " + user.toString());
        } 
        catch (Exception ex) {
            logger.error("Error occurred::", ex);
        }
        return result;
    }
    
    @Override
	@Transactional
	public Config getConfig() {
		try {
			List<Config> msgs = configDao.getListOrderByProperty("currentSchoolYearFrom");
			if (msgs != null) {
				logger.debug("getConfig : " + msgs.get(0).toString());
				return msgs.get(0);
			}
		} catch (Exception ex) {
            logger.error("Error occurred::", ex);
        } 
		return null;
	}
    
    @Transactional
	public String getConfigJson() {
    	String result = null;
		try {
			List<Config> msgs = configDao.getListOrderByProperty("currentSchoolYearFrom");
			if (msgs != null) {
				logger.debug("getConfig : " + msgs.get(0).toString());
				result = new GsonBuilder().serializeNulls().create().toJson(msgs.get(0));
			}
		} catch (Exception ex) {
            logger.error("Error occurred::", ex);
        } 
		return result;
	}
    
    @Override
    @Transactional
    @PreAuthorize("hasAnyRole('Administrator', 'User')")
    public String updateUser(int userId, String prefix, String firstName, String middleName, String lastName,
    		String email, String userName, String educationLevel, int occupationalTitleId, 
    		String otherOccupationalTitle, String phone, boolean emailNotification, byte registrationtypeId, 
    		String schoolName) throws AccessDeniedException {
        String result = null;
        try {
        	User user = userDao.get(userId);

        	if (user != null) {
        		
        		user.setPrefix(prefix);
	        	user.setFirstName(firstName);
	            user.setLastName(lastName);
	            user.setMiddleName(middleName);
	            user.setEmail(email);
	            user.setUserName(userName);
	            if (occupationalTitleId == 6) {
	            	user.setOtherOccupationalTitle(otherOccupationalTitle);
	            } 
	            else {
	            	user.setOtherOccupationalTitle(null);
	            }
	            user.setOccupationalTitleId(occupationalTitleId);
	            user.setPhone(phone);
	            user.setSchoolName(schoolName);
	            user.setEmailNotification(emailNotification);
	            user.setUpdatedOn(new Date());
	            user.setUpdatedbyId(userId);
	            
	            Config config = getConfig();
	            Registration registration = null;
	            
	            if (processPayment == 0) { // free
	            	byte originalRegistrationTypeId = user.getRegistrationtypeId();
	        		if (originalRegistrationTypeId != registrationtypeId) {
		            	if (registrationtypeId == (byte)1) { // non teacher membership
		            		user.setCurrentRegistrationId(null);
		            	}
		        		else {
		            		registration = registrationDao.getRegistrationByConfig(userId, config.getCurrentSchoolYearFrom());
		            		
		            		if (registration != null) {
		            			user.setCurrentRegistrationId(registration.getId());
		            		}
		            		else {
		            			registration = new Registration();
		                		registration.setUserId(userId);
		                		registration.setCreatedonDatetime(new Date());
		                		registration.setIsActive(true);
		                		registration.setCreatedbyId(userId);
		                		registration.setFromDatetime(config.getCurrentSchoolYearFrom());
		                		registration.setToDatetime(config.getCurrentSchoolYearTo());
		                		registrationDao.add(registration);
		                		//Integer registrationId = addRegistration(registration);
		                		
		                		user.setCurrentRegistrationId(registration.getId());
		            		}
		            	}
	        		}
	            	user.setRegistrationtypeId(registrationtypeId);
	            }
	            // if system is not free, don't update RegistrationtypeId
	            userDao.update(user);
	            
	            //SimpleUser sUser = new SimpleUser(user);
	            
				if (user.getRegistrationtypeId() == 2) { // teacher membership
					registration = registrationDao.getRegistrationByConfig(userId, config.getCurrentSchoolYearFrom());
	        	}
				
				SimpleUser sUser = new SimpleUser(user, config, registration, processPayment);
				result = new GsonBuilder().serializeNulls().create().toJson(sUser);
				logger.debug("updateUser SimpleUser result : " + result);
        	}
        	logger.debug("updateUser result: " + user.toString());
        } 
        catch (Exception ex) {
            logger.error("Error occurred::", ex);
        }
        return result;
    }
    
//    @Override
//	@Transactional
//	public Integer addRegistration(Registration registration) {
//		Integer result = null;
//		try {
//			registrationDao.add(registration);
//			result = registration.getId();
//			logger.debug("addRegistration : " + registration.toString());
//		} catch (Exception ex) {
//            logger.error("Error occurred::", ex);
//        } 
//		return result;
//	}
    
    @Override
    @Transactional
    @PreAuthorize("hasAnyRole('Administrator', 'User')")
    public String getUserAddress(int addressId) throws AccessDeniedException {
        String result = null;
        try {
        	Address msgs = addressDao.get(addressId);
            result = new GsonBuilder().serializeNulls().create().toJson(msgs);
            logger.debug("getUserAddress result: " + msgs.toString());
        } 
        catch (Exception ex) {
            logger.error("Error occurred::", ex);
        }
        return result;
    }
    
    @Override
    @Transactional
    @PreAuthorize("hasAnyRole('Administrator', 'User')")
    public String addOrUpdateSecurityQuestionsAndAnsers(int userId, int recorvery1, int recorvery2, String answer1, String answer2) throws AccessDeniedException {
    	String result = null;
        try {
        	List<AuthenticationUserAnswer> msgs = authenUserAnswerDao.getListByProperty("userId", userId);
        	//logger.debug("updateUserAddress result: " + msgs.size());
        	
        	if (msgs.size() == 0) {
        		AuthenticationUserAnswer authenUserAnswer1 = new AuthenticationUserAnswer();
        		authenUserAnswer1.setUserId(userId);
        		authenUserAnswer1.setAuthenticationQuestionId(recorvery1);
        		authenUserAnswer1.setAnswer(answer1);
        		authenUserAnswer1.setCreatedOn(new Date());
        		authenUserAnswerDao.add(authenUserAnswer1);
        		logger.debug("updateUserAddress add 1 : " + authenUserAnswer1.toString());
        		
        		AuthenticationUserAnswer authenUserAnswer2 = new AuthenticationUserAnswer();
        		authenUserAnswer2.setUserId(userId);
        		authenUserAnswer2.setAuthenticationQuestionId(recorvery2);
        		authenUserAnswer2.setAnswer(answer2);
        		authenUserAnswer2.setCreatedOn(new Date());
        		authenUserAnswerDao.add(authenUserAnswer2);
        		logger.debug("updateUserAddress add 2 : " + authenUserAnswer2.toString());
        	}
        	else if (msgs.size() == 1) {
        		AuthenticationUserAnswer authenUserAnswer1 = msgs.get(0);
        		//authenUserAnswer1.setUserId(userId);
        		authenUserAnswer1.setAuthenticationQuestionId(recorvery1);
        		authenUserAnswer1.setAnswer(answer1);
        		authenUserAnswer1.setUpdatedOn(new Date());
        		authenUserAnswerDao.update(authenUserAnswer1);
        		logger.debug("updateUserAddress update 1 : " + authenUserAnswer1.toString());
        		
        		AuthenticationUserAnswer authenUserAnswer2 = new AuthenticationUserAnswer();
        		authenUserAnswer2.setUserId(userId);
        		authenUserAnswer2.setAuthenticationQuestionId(recorvery2);
        		authenUserAnswer2.setAnswer(answer2);
        		authenUserAnswer2.setCreatedOn(new Date());
        		authenUserAnswerDao.add(authenUserAnswer2);
        		logger.debug("updateUserAddress add 2 : " + authenUserAnswer2.toString());
        	}
        	else if (msgs.size() >= 2) {
        		AuthenticationUserAnswer authenUserAnswer1 = msgs.get(0);
        		//authenUserAnswer1.setUserId(userId);
        		authenUserAnswer1.setAuthenticationQuestionId(recorvery1);
        		authenUserAnswer1.setAnswer(answer1);
        		authenUserAnswer1.setUpdatedOn(new Date());
        		authenUserAnswerDao.update(authenUserAnswer1);
        		logger.debug("updateUserAddress update 1 : " + authenUserAnswer1.toString());
        		
        		AuthenticationUserAnswer authenUserAnswer2 = msgs.get(1);
        		//authenUserAnswer2.setUserId(userId);
        		authenUserAnswer2.setAuthenticationQuestionId(recorvery2);
        		authenUserAnswer2.setAnswer(answer2);
        		authenUserAnswer2.setCreatedOn(new Date());
        		authenUserAnswerDao.update(authenUserAnswer2);
        		logger.debug("updateUserAddress update 2 : " + authenUserAnswer2.toString());
        		
        		for(int i=2; i<msgs.size(); i++) {
        			logger.debug("updateUserAddress delete : " + msgs.get(i).toString());
        			authenUserAnswerDao.delete(msgs.get(i));
        		}
        	}
        	
        	msgs = authenUserAnswerDao.getListByProperty("userId", userId);
        	result = new GsonBuilder().serializeNulls().create().toJson(msgs);
        	logger.debug("updateUserAddress result: " + msgs.size());
        } 
        catch (Exception ex) {
            logger.error("Error occurred::", ex);
        }
        return result;
    }
    
    @Override
    @Transactional
    @PreAuthorize("hasAnyRole('Administrator', 'User')")
    public String addOrUpdateAddress(Integer userId, Integer addressId, String streetAddress, String city, String county, 
    		String state, String country, String zipCode) throws AccessDeniedException {
    	String result = null;
        try {
        	Address address;
        	if (addressId == null) {
        		address = new Address();
        		address.setStreetAddress(streetAddress);
        		address.setCity(city);
        		address.setCounty(county);
        		address.setState(state);
        		address.setCountry(country);
        		address.setZipCode(zipCode);
        		addressDao.add(address);
        	}
        	else {
        		address = addressDao.get(addressId);
        		address.setStreetAddress(streetAddress);
        		address.setCity(city);
        		address.setCounty(county);
        		address.setState(state);
        		address.setCountry(country);
        		address.setZipCode(zipCode);
        		addressDao.update(address);
        	}
                
                User user = userDao.get(userId);
                if ((user != null) && (address !=null)) {
                    user.setPrimaryAddressId(address.getId());
                    userDao.update(user);
                }

        	result = new GsonBuilder().serializeNulls().create().toJson(address);
            logger.debug("updateUserAddress result: " + result);
        } 
        catch (Exception ex) {
            logger.error("Error occurred::", ex);
        }
        return result;
    }
    
    @Override
    @Transactional
    @PreAuthorize("hasAnyRole('Administrator', 'User')")
    public String addOrUpdateBillingAddress(Integer userId, Integer addressId, String streetAddress, String city, String county, 
    		String state, String country, String zipCode) throws AccessDeniedException {
    	String result = null;
        try {
        	Address address;
        	if (addressId == null) {
        		address = new Address();
        		address.setStreetAddress(streetAddress);
        		address.setCity(city);
        		address.setCounty(county);
        		address.setState(state);
        		address.setCountry(country);
        		address.setZipCode(zipCode);
        		addressDao.add(address);
        	}
        	else {
        		address = addressDao.get(addressId);
        		address.setStreetAddress(streetAddress);
        		address.setCity(city);
        		address.setCounty(county);
        		address.setState(state);
        		address.setCountry(country);
        		address.setZipCode(zipCode);
        		addressDao.update(address);
        	}
                
            User user = userDao.get(userId);
            if ((user != null) && (address !=null)) {
                user.setBillingAddressId(address.getId());
                userDao.update(user);
            }

        	result = new GsonBuilder().serializeNulls().create().toJson(address);
            logger.debug("updateUserBillingAddress result: " + result);
        } 
        catch (Exception ex) {
            logger.error("Error occurred::", ex);
        }
        return result;
    }
    
    @Override
    @Transactional
    @PreAuthorize("hasAnyRole('Administrator', 'User')")
    public String addOrUpdateShippingAddress(Integer userId, Integer addressId, String streetAddress, String city, String county, 
    		String state, String country, String zipCode) throws AccessDeniedException {
    	String result = null;
        try {
        	Address address;
        	if (addressId == null) {
        		address = new Address();
        		address.setStreetAddress(streetAddress);
        		address.setCity(city);
        		address.setCounty(county);
        		address.setState(state);
        		address.setCountry(country);
        		address.setZipCode(zipCode);
        		addressDao.add(address);
        	}
        	else {
        		address = addressDao.get(addressId);
        		address.setStreetAddress(streetAddress);
        		address.setCity(city);
        		address.setCounty(county);
        		address.setState(state);
        		address.setCountry(country);
        		address.setZipCode(zipCode);
        		addressDao.update(address);
        	}
                
            User user = userDao.get(userId);
            if ((user != null) && (address !=null)) {
                user.setShippingAddressId(address.getId());
                userDao.update(user);
            }

        	result = new GsonBuilder().serializeNulls().create().toJson(address);
            logger.debug("updateUserShippingAddress result: " + result);
        } 
        catch (Exception ex) {
            logger.error("Error occurred::", ex);
        }
        return result;
    }
    
    @Override
    @Transactional
    @PreAuthorize("hasAnyRole('Administrator', 'User')")
    public Integer updateUserAddress(int userId, int addressId) throws AccessDeniedException {
    	Integer result = null;
        try {
        	User user = userDao.get(userId);
        	if (user != null) {
        		user.setPrimaryAddressId(addressId);
        		userDao.update(user);
        		result = user.getPrimaryAddressId();
        	}
            logger.debug("updateUserAddress result: " + result);
        } 
        catch (Exception ex) {
            logger.error("Error occurred::", ex);
        }
        return result;
    }
    
    @Override
    @Transactional
    @PreAuthorize("hasAnyRole('Administrator')")
    public String getAllModules() throws AccessDeniedException {
        String result = null;
        logger.debug("request to get all modules.");
        try {
            List<Module> msgs = moduleDao.getAllModulesOrderBySequence();
            result = new GsonBuilder().serializeNulls().create().toJson(msgs);
            logger.debug("getAllModules result: " + msgs.size());
        } 
        catch (Exception ex) {
            logger.error("Error occurred::", ex);
        }
        return result;
    }
    
    @Override
    @Transactional
    @PreAuthorize("hasAnyRole('Administrator', 'User')")
    public String getSurveyQuestions() throws AccessDeniedException {
        String result = null;
        
        try {
            List<SurveyQuestion> msgs = surveyQuestionDao.getListOrderByProperty("id");
            result = new GsonBuilder().serializeNulls().create().toJson(msgs);
            logger.debug("getSurveyQuestions result : " + msgs.size());
            return result;
        } 
        catch (Exception ex) {
            logger.error("Error occurred::", ex);
        }
        return result;
    }
    
    @Override
    @Transactional
    @PreAuthorize("hasAnyRole('Administrator', 'User')")
    public String getUserCertificateTitles(int userId) throws AccessDeniedException {
        String result = null;
        try {
        	List<Registration> msgs = registrationDao.getUserPaidRegistrations(userId);
            result = new GsonBuilder().serializeNulls().create().toJson(msgs);
            if (msgs != null)
            {
                logger.debug("getUserCertificateTitles result: " + msgs.size());
            }
            else
            {
                logger.debug("getUserCertificateTitles result is null");
            }
            
        } 
        catch (Exception ex) {
            logger.error("Error occurred::", ex);
        }
        return result;
    }
    
    @Override
    @Transactional
    @PreAuthorize("hasAnyRole('Administrator', 'User')")
    public String getUserModuleTestTranscriptTitles(int userId) throws AccessDeniedException {
        String result = null;
        try {
        	List<UserModuleTestTranscriptTitle> msgs = userModuleTestDao.getTranscriptTitles(userId);
            result = new GsonBuilder().serializeNulls().create().toJson(msgs);
            logger.debug("getUserModuleTestTranscriptTitles result: " + msgs.size());
        } 
        catch (Exception ex) {
            logger.error("Error occurred::", ex);
        }
        return result;
    }
    
    @Override
    @Transactional
    @PreAuthorize("hasAnyRole('Administrator', 'User')")
    public String getUserModuleTestCertificateDetails(int userId, String fullName, String title, String testyear, String imagesPath) throws AccessDeniedException {
        String result = null;
        try {
        	
        	String path = KidvisionWebConfig.USER_MODULE_TEST_TRANSCRIPTS_DIRECTORY + title + " " + userId + ".pdf";
        	
        	File newUploadedFile = new File(KidvisionWebConfig.USER_MODULE_TEST_TRANSCRIPTS_DIRECTORY);
	    	if (!newUploadedFile.exists()) {  // Checks that Directory/Folder Doesn't Exists!  
	            if(newUploadedFile.mkdir()) {  
	            	logger.debug("create folder " + KidvisionWebConfig.USER_MODULE_TEST_TRANSCRIPTS_DIRECTORY);
	            }
	        }
	    	
        	ITextPDF itext = new ITextPDF(path, 1); // , imagesPath, Integer.toString(userId), fullName
        	itext.printUserModuleTestCertificate(Integer.toString(userId), fullName, testyear, imagesPath);
        	
            result = path; // new GsonBuilder().serializeNulls().create().toJson(msgs);
            logger.debug("getUserModuleTestCertificateDetails path: " + path);
        } 
        catch (Exception ex) {
            logger.error("Error occurred::", ex);
        }
        return result;
    }
    
    @Override
    @Transactional
    @PreAuthorize("hasAnyRole('Administrator', 'User')")
    public String getUserModuleTestTranscriptDetails(int userId, String fullName, String title, int testyear, String imagesPath) throws AccessDeniedException {
        String result = null;
        try {
        	List<UserModuleTestTranscriptDetail> msgs = userModuleTestDao.getTranscriptDetails(userId, testyear);
        	logger.debug("getUserModuleTestTranscriptDetails msgs: " + msgs.size());
        	
        	String path = KidvisionWebConfig.USER_MODULE_TEST_TRANSCRIPTS_DIRECTORY + title + " " + userId + ".pdf";
        	
        	File newUploadedFile = new File(KidvisionWebConfig.USER_MODULE_TEST_TRANSCRIPTS_DIRECTORY);
	    	if (!newUploadedFile.exists()) {  // Checks that Directory/Folder Doesn't Exists!  
	            if(newUploadedFile.mkdir()) {  
	            	logger.debug("create folder " + KidvisionWebConfig.USER_MODULE_TEST_TRANSCRIPTS_DIRECTORY);
	            }
	        }
	    	
        	ITextPDF itext = new ITextPDF(path, 0); // , imagesPath, Integer.toString(userId), fullName
        	itext.printUserModuleTestTranscript(Integer.toString(userId), fullName, msgs, imagesPath);
        	
            result = path; // new GsonBuilder().serializeNulls().create().toJson(msgs);
            logger.debug("getUserModuleTestTranscriptDetails path: " + path);
        } 
        catch (Exception ex) {
            logger.error("Error occurred::", ex);
        }
        return result;
    }
    
    @Override
    @Transactional
    @PreAuthorize("hasAnyRole('Administrator', 'User')")
    public Integer getUserPrimaryAddressId(int userId) throws AccessDeniedException {
    	Integer result = null;
        try {
        	User user = userDao.get(userId);
        	if (user != null) {
        		result = user.getPrimaryAddressId();
        		logger.debug("getUserPrimaryAddressId result: " + user.toString());
        	}
        } 
        catch (Exception ex) {
            logger.error("Error occurred::", ex);
        }
        return result;
    }
    
    @Override
    @Transactional
    @PreAuthorize("hasAnyRole('Administrator', 'User')")
    public Integer getUserBillingAddressId(int userId) throws AccessDeniedException {
    	Integer result = null;
        try {
        	User user = userDao.get(userId);
        	if (user != null) {
        		result = user.getBillingAddressId();
        		logger.debug("getUserBillingAddressId result: " + user.toString());
        	}
        } 
        catch (Exception ex) {
            logger.error("Error occurred::", ex);
        }
        return result;
    }
    
    @Override
    @Transactional
    @PreAuthorize("hasAnyRole('Administrator', 'User')")
    public Integer getUserShippingAddressId(int userId) throws AccessDeniedException {
    	Integer result = null;
        try {
        	User user = userDao.get(userId);
        	if (user != null) {
        		result = user.getShippingAddressId();
        		logger.debug("getUserShippingAddressId result: " + user.toString());
        	}
        } 
        catch (Exception ex) {
            logger.error("Error occurred::", ex);
        }
        return result;
    }
    
//    @Override
//    @Transactional
//    @PreAuthorize("hasAnyRole('Administrator', 'User')")
//    public String getUserCurrentRegistration(int userId) throws AccessDeniedException {
//    	String result = "";
//        try {
//        	User user = userDao.get(userId);
//        	if (user != null) {
//        		Integer cRId = user.getCurrentRegistrationId();
//        		if (cRId != null) {
//        			Registration r = registrationDao.get(cRId);
//        			result = new GsonBuilder().serializeNulls().create().toJson(r);
//        		}
//        		
//        		logger.debug("getUserCurrentRegistration result: " + result.toString());
//        	}
//        } 
//        catch (Exception ex) {
//            logger.error("Error occurred::", ex);
//        }
//        return result;
//    }
    
    @Override
	@Transactional
	public String getFullSimpleUser(Integer userId) {
		String result = null;
        try {
        	      	
			User user = userDao.get(userId);
			if (user != null) {
				Config config = null;
				Registration registration = null;
				
				if (user.getRegistrationtypeId() == 2) { // teacher membership
					config = getConfig();
					registration = registrationDao.getRegistrationByConfig(userId, config.getCurrentSchoolYearFrom());
	        	}
				
				SimpleUser sUser = new SimpleUser(user, config, registration, processPayment);
				result = new GsonBuilder().serializeNulls().create().toJson(sUser);
				logger.debug("getLoggedSimpleUser SimpleUser result : " + result);
				return result;
	        }
        } 
        catch (Exception ex) {
            logger.error("Error occurred::", ex);
        }
        return result;
	}
    
    @Override
    @Transactional
    @PreAuthorize("hasAnyRole('Administrator', 'User')")
    public String payRegistration(int userId, String billingFullName, String billingStreetAddress, 
    		String billingCity, String billingState, String billingZipCode, String email, String cardNumber, 
    		String exp, String cardSecurityCode, String billingCountry, String shippingStreetAddress, 
    		String shippingCity, String shippingState, String shippingZipCode, String shippingCountry, String phone) throws AccessDeniedException {
    	String result = "";
        try {

        	Config config = getConfig();
        	
        	//T_APPLICATION_ID
        	SagePayment sagepayment = new SagePayment(M_ID, M_KEY, T_APPLICATION_ID,
        			billingFullName, billingStreetAddress, 
        			billingCity, billingState, billingZipCode, email, cardNumber, exp, 
        			cardSecurityCode, config.getTmRegistrationAmount().toString());
        	
        	if (billingCountry != null && billingCountry.length() > 0) {
        		sagepayment.setC_COUNTRY(billingCountry);
        	}
        	
        	if (shippingStreetAddress != null && shippingStreetAddress.length() > 0) {
        		sagepayment.setC_SHIP_ADDRESS(shippingStreetAddress);
        	}
        	
        	if (shippingCity != null && shippingCity.length() > 0) {
        		sagepayment.setC_SHIP_CITY(shippingCity);
        	}
        	
        	if (shippingState != null && shippingState.length() > 0) {
        		sagepayment.setC_SHIP_STATE(shippingState);
        	}
        	
        	if (shippingZipCode != null && shippingZipCode.length() > 0) {
        		sagepayment.setC_SHIP_ZIP(shippingZipCode);
        	}
        	
        	if (shippingCountry != null && shippingCountry.length() > 0) {
        		sagepayment.setC_SHIP_COUNTRY(shippingCountry);
        	}
        	
        	if (phone != null && phone.length() > 0) {
        		sagepayment.setC_TELEPHONE(phone);
        	}
        	//sagepayment.setT_ORDERNUM("0");
        	//sagepayment.setT_SHIPPING("0");
        	//sagepayment.setT_TAX(tax);
        	
        	// process.payment=1
        	result = sagepayment.sendPost();
        	
        	if (sagepayment.getResponse_APPROVAL_INDICATOR().equalsIgnoreCase("A")) {
        		// A = Approved
        		User user = userDao.get(userId);
        		
        		Registration registration = registrationDao.getRegistrationByConfig(userId, config.getCurrentSchoolYearFrom());
        		
        		if (registration != null) {
        			user.setCurrentRegistrationId(registration.getId());
        		}
        		else {
        			registration = new Registration();
            		registration.setUserId(userId);
            		registration.setCreatedonDatetime(new Date());
            		registration.setIsActive(true);
            		registration.setCreatedbyId(userId);
            		registration.setFromDatetime(config.getCurrentSchoolYearFrom());
            		registration.setToDatetime(config.getCurrentSchoolYearTo());
            		registrationDao.add(registration);
            		//Integer registrationId = addRegistration(registration);
            		
            		user.setCurrentRegistrationId(registration.getId());
        		}
        		user.setRegistrationtypeId((byte)2);
        		userDao.update(user);

        		registration.setIsPaid((short)1);
        		registration.setCardFullName(billingFullName);
        		registration.setCardLastFour(cardNumber.substring(12));
        		registration.setCardExp(exp);
        		registration.setSagePaymentOrderNumber(sagepayment.getResponse_ORDER_NUMBER());
        		registration.setSagePaymentReference(sagepayment.getResponse_REFERENCE());
        		registration.setSagePaymentDatetime(new Date());
        		
        		registrationDao.update(registration);
        	}
        	else if (sagepayment.getResponse_APPROVAL_INDICATOR().equalsIgnoreCase("E")) {
				// E = Front-End Error/Non Approved
			}
        	else if (sagepayment.getResponse_APPROVAL_INDICATOR().equalsIgnoreCase("X")) {
				// X = Gateway Error/Non Approved
			}
        	
        	result = new GsonBuilder().serializeNulls().create().toJson(sagepayment);
            logger.debug("sagepayment result: " + result);
        } 
        catch (Exception ex) {
            logger.error("Error occurred::", ex);
        }
        return result;
    }
    
    
    
//    @Override
//    @Transactional
//    public String getAllModules() {
//        String result = "";
//        logger.debug("request to get all modules.");
//        try {
//            Gson gson = new GsonBuilder().serializeNulls().create();
//            
//            List<Module> msgs = moduleDao.getList();//.getAllModules();
//            result = gson.toJson(msgs);
//            logger.debug("getAllModules result: " + result.length());
//        } catch (Exception ex) {
//            logger.error("Error occurred::", ex);
//            result = "error occured while fetching the modules";
//        }
//        return result;
//    }
}
