package com.cei.kidvisionweb.api.rest;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;

import com.cei.kidvisionweb.config.KidvisionWebConfig;
import com.cei.kidvisionweb.service.AdminService;
import com.cei.kidvisionweb.service.UserLoginService;
import com.cei.kidvisionweb.service.util.FileProcessor;
import com.cei.kidvisionweb.service.util.LoggedUser;
import com.cei.kidvisionweb.service.util.RegularExpressionUtil;
import com.cei.kidvisionweb.service.util.VideoProcessor;
import com.google.api.services.youtube.model.PlaylistItem;
import com.sun.jersey.api.core.InjectParam;
import com.sun.jersey.core.header.FormDataContentDisposition;
import com.sun.jersey.multipart.FormDataParam;

import javax.servlet.ServletContext;
import javax.ws.rs.Consumes;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;
import javax.ws.rs.core.Response.ResponseBuilder;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.AccessDeniedException;

@Path("/admin")
public class AdminResource {

    private static Logger logger = LoggerFactory.getLogger(AdminResource.class);

    @Context
    ServletContext context;

    @Context
    UriInfo uriInfo;

    @InjectParam
    private UserLoginService userLoginService;

    @InjectParam
    private VideoProcessor videoProcessor;

    @InjectParam
    private AdminService adminService;

    @Autowired
    public AdminResource() {
    }

    @Path("/getUploadVideosFromYoutube")
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response getUploadVideoFromYoutube() {
        try {            
            if (userLoginService.isLoggedIn()) {
                LoggedUser loggedUser = userLoginService.getLoggedUserUtil();
                logger.debug("getUploadVideoFromYoutube logged user : " + loggedUser.toString());
                logger.info("get uploaded videos from YouTube account, request from username: " + loggedUser.getUsername() + " userId: " + loggedUser.getId().toString());
                logger.debug("kidvisionWebConfig.getUploadVideoDirectory() = " + KidvisionWebConfig.UPLOADED_VIDEOS_DIRECTORY);
                String result = videoProcessor.getYoutubeVideoList();
                logger.info("got the videos.");
                return Response.ok(result, MediaType.APPLICATION_JSON).build();
                
            } else {
                logger.info("unauthorized request.");
                return Response.status(Response.Status.UNAUTHORIZED).entity("").build();
            }
        } catch (AccessDeniedException ex) {
            logger.error("Error occurred:", ex);
            
            return Response.status(Response.Status.FORBIDDEN).entity("").build();
        } catch (Exception ex) {
            logger.error("Error occurred:: ", ex);
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("").build();
        }
    }

    // select count(*) from (
    //SELECT * FROM kidvisiondb.videos group by file_name ) as a;
    // SELECT * FROM kidvisiondb.videos where is_overview = 0 group by file_name;
    @Path("/mappingyoutubemp4videosandtablevideos")
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response mappingYoutubeMP4VideosAndTableVideos() {
        try {
            if (userLoginService.isLoggedIn()) {
                LoggedUser loggedUser = userLoginService.getLoggedUserUtil();
                logger.debug("mappingYoutubeMP4VideosAndTableVideos logged user : " + loggedUser.toString());
                logger.info("map video streams request from username: " + loggedUser.getUsername() + " userId: " + loggedUser.getId().toString());
                //logger.debug("kidvisionWebConfig.getUploadVideoDirectory() = " + KidvisionWebConfig.UPLOADED_VIDEOS_DIRECTORY);
                List<PlaylistItem> streams = videoProcessor.getYoutubeVideoTitleIdList();
                logger.debug("List<PlaylistItem> size = " + streams.size());

                String result = adminService.mappingYoutubeMP4VideosAndTableVideos(streams);

				//List<Video> videos = adminService.getAllVideosList();
				//adminService.getUnmappingVideos();
                logger.info("video streams mapped successfully.");
                return Response.ok(result, MediaType.APPLICATION_JSON).build();
            } else {
                logger.info("unauthorized request.");
                return Response.status(Response.Status.UNAUTHORIZED).entity("").build();
                
            }
        } catch (AccessDeniedException ex) {
            logger.error("Error occurred::", ex);
            return Response.status(Response.Status.FORBIDDEN).entity("").build();
        } catch (Exception ex) {
            logger.error("Error occurred:: ", ex);
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("").build();
        }
    }

    /*@Path("/mappingyoutubevideosandtablevideos")
     @GET
     @Produces(MediaType.APPLICATION_JSON)
     public Response mappingYoutubeVideosAndTableVideos() {
     try {
     if ( userLoginService.isLoggedIn() ) {
     LoggedUser loggedUser = userLoginService.getLoggedUserUtil();
     logger.debug("mappingYoutubeVideosAndTableVideos logged user : " + loggedUser.toString());

     logger.debug("kidvisionWebConfig.getUploadVideoDirectory() = " + KidvisionWebConfig.UPLOADED_VIDEOS_DIRECTORY);
     List<PlaylistItem> streams = videoProcessor.getYoutubeVideoTitleIdList();
				
     List<Video> videos = adminService.getAllVideosList();
				
     for (Video video : videos) {
     for (PlaylistItem stream : streams) {
     String fileName = video.getFileName();
     String fileNamewithoutextension = fileName.substring(0, fileName.indexOf("."));
     String fileNamewithoutunderscore = fileNamewithoutextension.replaceAll("_", " ");
     logger.debug("fileNamewithoutunderscore = " + fileNamewithoutunderscore);
     if ( fileNamewithoutunderscore.equalsIgnoreCase( stream.getSnippet().getTitle() ) ) {
     logger.debug("tite = " + stream.getSnippet().getTitle() + " , stream id = " + stream.getContentDetails().getVideoId());
     adminService.mappingVideo(video.getId(), stream.getContentDetails().getVideoId());
     break;
     }
     }
     }
				
     String result = adminService.getAllVideos();
		        
     return Response.ok(result, MediaType.APPLICATION_JSON).build();
     }
     else {
     return Response.status(Response.Status.UNAUTHORIZED).entity("").build();
     }
     } catch (AccessDeniedException ex) {
     logger.error("Error occurred::", ex);
     return Response.status(Response.Status.FORBIDDEN).entity("").build();
     } catch (Exception ex) {
     logger.error("Error occurred:: ", ex);
     return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("").build();
     }
     }*/
    @Path("/deletemodulequestion")
    @POST
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    @Produces(MediaType.TEXT_HTML)
    public Response deleteModuleQuestion(@FormParam("questionid") int questionId) {
        logger.debug("deleteModuleQuestion params questionid = " + questionId);
        try {
            
            if (userLoginService.isLoggedIn()) {
                LoggedUser loggedUser = userLoginService.getLoggedUserUtil();
                logger.debug("logged user : " + loggedUser.toString());
                logger.info("delete module question, for questionId: " + questionId + ", request from username: " + loggedUser.getUsername() + " userId: " + loggedUser.getId().toString());
                adminService.deleteModuleQuestionAndAnswers(questionId);
                logger.info("question deleted.");
                return Response.ok("true").build();
            } else {
                logger.info("unauthorized request.");
                return Response.status(Response.Status.UNAUTHORIZED).entity("").build();
            }
        } catch (AccessDeniedException ex) {
            logger.error("Error occurred::", ex);
            return Response.status(Response.Status.FORBIDDEN).entity("").build();
        } catch (Exception ex) {
            logger.error("Error occurred:: ", ex);
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("").build();
        }
    }

    @Path("/updatemodulestandards")
    @POST
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    @Produces(MediaType.APPLICATION_JSON)
    public Response updateModuleStandards(@FormParam("moduleId") int moduleId,
            @FormParam("s0id") int s0id, @FormParam("s0v") String s0v,
            @FormParam("s1id") int s1id, @FormParam("s1v") String s1v,
            @FormParam("s2id") int s2id, @FormParam("s2v") String s2v,
            @FormParam("s3id") int s3id, @FormParam("s3v") String s3v) {
        logger.debug("updateModuleStandards params moduleId = " + moduleId + " , s0id = " + s0id
                + " , s0v = " + s0v + " , s1id = " + s1id + " , s1v = " + s1v
                + " , s2id = " + s2id + " , s2v = " + s2v + " s3id = " + s3id + " , s3v = " + s3v);
        try {
            
            if (userLoginService.isLoggedIn()) {
                LoggedUser loggedUser = userLoginService.getLoggedUserUtil();
                logger.debug("logged user : " + loggedUser.toString());
                logger.info("update module standards, for moduleid: " + moduleId + " request from username: " + loggedUser.getUsername() + " userId: " + loggedUser.getId().toString());
                adminService.createOrUpdateModuleStandard(s0id, moduleId, "standard_1", s0v, 0);
                adminService.createOrUpdateModuleStandard(s1id, moduleId, "standard_2", s1v, 1);
                adminService.createOrUpdateModuleStandard(s2id, moduleId, "standard_3", s2v, 2);
                adminService.createOrUpdateModuleStandard(s3id, moduleId, "standard_4", s3v, 3);

                String result = adminService.getStandardsByModule(moduleId);
                logger.info("module standards updated successfully.");
                return Response.ok(result, MediaType.APPLICATION_JSON).build();
            } else {
                logger.info("unauthorized request.");
                return Response.status(Response.Status.UNAUTHORIZED).entity("").build();
            }
        } catch (AccessDeniedException ex) {
            logger.error("Error occurred::", ex);
            return Response.status(Response.Status.FORBIDDEN).entity("").build();
        } catch (Exception ex) {
            logger.error("Error occurred:: ", ex);
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("").build();
        }
    }

    @Path("/updatemodulequestion")
    @POST
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    @Produces(MediaType.APPLICATION_JSON)
    public Response updateModuleQuestion(//@FormParam("moduleId") int moduleId, 
            @FormParam("questionid") int questionId,
            @FormParam("question") String question,
            @FormParam("sequence") int sequence,
            @FormParam("standardId") int standardId,
            @FormParam("a0id") int a0id,
            @FormParam("a1id") int a1id,
            @FormParam("a2id") int a2id,
            @FormParam("a3id") int a3id,
            @FormParam("a0") String a0,
            @FormParam("a1") String a1,
            @FormParam("correct") int correct,
            @FormParam("a2") String a2,
            @FormParam("a3") String a3) {
        logger.debug("updateModuleQuestion params questionid = " + questionId + " , question = " + question + " , correct = " + correct
                + " , sequence = " + sequence + " , a0 = " + a0
                + " , a1 = " + a1 + " , a2 = " + a2 + " , a3 = " + a3 + " , a0id = " + a0id
                + " , a1id = " + a1id + " , a2id = " + a2id + " , a3id = " + a3id);
        try {
            if (userLoginService.isLoggedIn()) {
                LoggedUser loggedUser = userLoginService.getLoggedUserUtil();
                logger.debug("logged user : " + loggedUser.toString());
                logger.info("update module questions, for questionId: " + questionId + ", request from username: " + loggedUser.getUsername() + " userId: " + loggedUser.getId().toString());
                //adminService.deleteModuleQuestion(moduleId, sequence);
                int qid = adminService.updateModuleQuestion(questionId, question, sequence, standardId);

                if (qid != -1) {
					//qid = adminService.createModuleQuestion(moduleId, question, sequence, standardId);
                    //}
                    //String[] ansArray = answers.split(",");
                    //String[] ansId = aids.split(",");
                    //for (int i = 0; i < ansArray.length; i++) {
                    //logger.debug("aid = " + ansId[i] + " , ans = " + ansArray[i]);
                    //if (ansId[i] == "0") {
                    if (a0id == 0) {
                        if (0 == correct) {
                            adminService.createModuleQuestionAnswer(qid, a0, (short) 1, 1);
                        } else {
                            adminService.createModuleQuestionAnswer(qid, a0, (short) 0, 1);
                        }
                    } else {
                        if (0 == correct) {
                            adminService.updateModuleQuestionAnswer(a0id, a0, (short) 1, 1);
                        } else {
                            adminService.updateModuleQuestionAnswer(a0id, a0, (short) 0, 1);
                        }
                    }
					//}

                    if (a1id == 0) {
                        if (1 == correct) {
                            adminService.createModuleQuestionAnswer(qid, a1, (short) 1, 2);
                        } else {
                            adminService.createModuleQuestionAnswer(qid, a1, (short) 0, 2);
                        }
                    } else {
                        if (1 == correct) {
                            adminService.updateModuleQuestionAnswer(a1id, a1, (short) 1, 2);
                        } else {
                            adminService.updateModuleQuestionAnswer(a1id, a1, (short) 0, 2);
                        }
                    }

                    if (a2id == 0) {
                        if (2 == correct) {
                            adminService.createModuleQuestionAnswer(qid, a2, (short) 1, 3);
                        } else {
                            adminService.createModuleQuestionAnswer(qid, a2, (short) 0, 3);
                        }
                    } else {
                        if (2 == correct) {
                            adminService.updateModuleQuestionAnswer(a2id, a2, (short) 1, 3);
                        } else {
                            adminService.updateModuleQuestionAnswer(a2id, a2, (short) 0, 3);
                        }
                    }

                    if (a3id == 0) {
                        if (3 == correct) {
                            adminService.createModuleQuestionAnswer(qid, a3, (short) 1, 4);
                        } else {
                            adminService.createModuleQuestionAnswer(qid, a3, (short) 0, 4);
                        }
                    } else {
                        if (3 == correct) {
                            adminService.updateModuleQuestionAnswer(a3id, a3, (short) 1, 4);
                        } else {
                            adminService.updateModuleQuestionAnswer(a3id, a3, (short) 0, 4);
                        }
                    }

                    String result = adminService.getQuestionAndAnsers(qid);
                    logger.info("question updated successfully.");
                    return Response.ok(result, MediaType.APPLICATION_JSON).build();
                }
                return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("").build();
            } else {
                logger.info("unauthorized request.");
                return Response.status(Response.Status.UNAUTHORIZED).entity("").build();
            }
        } catch (AccessDeniedException ex) {
            logger.error("Error occurred::", ex);
            return Response.status(Response.Status.FORBIDDEN).entity("").build();
        } catch (Exception ex) {
            logger.error("Error occurred:: ", ex);
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("").build();
        }
    }

    @Path("/updatemodelclassroommaterials")
    @POST
    @Consumes(MediaType.MULTIPART_FORM_DATA)
    @Produces(MediaType.APPLICATION_JSON)
    public Response uploadModelClassroomMaterials(@FormDataParam("moduleId") int moduleId,
            @FormDataParam("lessonPlan") InputStream lessionPlanInputStream,
            @FormDataParam("lessonPlan") FormDataContentDisposition lessionPlanDetail,
            @FormDataParam("assessment") InputStream assessmentInputStream,
            @FormDataParam("assessment") FormDataContentDisposition assessmentDetail,
            @FormDataParam("takeHome") InputStream takeHomeInputStream,
            @FormDataParam("takeHome") FormDataContentDisposition takeHomeDetail) throws IOException {

        logger.debug("uploadModelClassroomMaterials params moduleId = " + moduleId);

        try {
            if (userLoginService.isLoggedIn()) {
                LoggedUser loggedUser = userLoginService.getLoggedUserUtil();
                logger.debug("logged user : " + loggedUser.toString());
                logger.info("upload module classroom material for moduleid: " + moduleId + ", request from username: " + loggedUser.getUsername() + " userId: " + loggedUser.getId().toString());
                String lessionPlanFileName = null;
                String assessmentFileName = null;
                String takeHomeFileName = null;

                FileProcessor fileProcessor = new FileProcessor();
                if (lessionPlanInputStream != null && lessionPlanDetail != null) {
                    logger.debug("lession plan file name " + lessionPlanDetail.getFileName());

                    //if ( fileProcessor.writeToWebapp(context.getRealPath("/classroom_materials")+"/", lessionPlanInputStream, lessionPlanDetail) ) {
                    if (fileProcessor.writeToWebapp(KidvisionWebConfig.CLASSROOM_MATERIALS_DIRECTORY, lessionPlanInputStream, lessionPlanDetail)) {
                        logger.debug("lession plan saved locally.");
                        lessionPlanFileName = lessionPlanDetail.getFileName();
                    }
                }

                if (assessmentInputStream != null && assessmentDetail != null) {
                    logger.debug("icon name " + assessmentDetail.getFileName());

                    //if ( fileProcessor.writeToWebapp(context.getRealPath("/classroom_materials")+"/", assessmentInputStream, assessmentDetail) ) {
                    if (fileProcessor.writeToWebapp(KidvisionWebConfig.CLASSROOM_MATERIALS_DIRECTORY, assessmentInputStream, assessmentDetail)) {
                        logger.debug("assessment saved locally.");
                        assessmentFileName = assessmentDetail.getFileName();
                    }
                }

                if (takeHomeInputStream != null && takeHomeDetail != null) {
                    logger.debug("icon name " + takeHomeDetail.getFileName());

                    //if ( fileProcessor.writeToWebapp(context.getRealPath("/classroom_materials")+"/", takeHomeInputStream, takeHomeDetail) ) {
                    if (fileProcessor.writeToWebapp(KidvisionWebConfig.CLASSROOM_MATERIALS_DIRECTORY, takeHomeInputStream, takeHomeDetail)) {
                        logger.debug("assessment saved locally.");
                        takeHomeFileName = takeHomeDetail.getFileName();
                    }
                }

                String result = adminService.updateModuleClassroomMaterials(loggedUser.getId(), moduleId,
                        lessionPlanFileName, assessmentFileName, takeHomeFileName);
                logger.info("classroom material uploaded successfully.");
                return Response.ok(result, MediaType.APPLICATION_JSON).build();
            } else {
                logger.info("unauthorized request.");
                return Response.status(Response.Status.UNAUTHORIZED).entity("").build();
            }
        } catch (AccessDeniedException ex) {
            logger.error("Error occurred::", ex);
            return Response.status(Response.Status.FORBIDDEN).entity("").build();
        } catch (Exception ex) {
            logger.error("Error occurred:: ", ex);
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("").build();
        }
    }

    @Path("/triggeruser")
    @POST
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    @Produces(MediaType.APPLICATION_JSON)
    public Response triggerUser(@FormParam("userId") int userId) throws IOException {

        logger.debug("triggerModule params userId = " + userId);

        try {
            if (userLoginService.isLoggedIn()) {
                LoggedUser loggedUser = userLoginService.getLoggedUserUtil();
                logger.debug("logged user : " + loggedUser.toString());
                logger.info("changed user active status for userId: " + userId + ", request from username: " + loggedUser.getUsername() + " userId: " + loggedUser.getId().toString());
                String result = adminService.triggerUser(loggedUser.getId(), userId);
                logger.info("user status changed successfully"); 
                return Response.ok(result, MediaType.APPLICATION_JSON).build();
            } else {
                logger.info("unauthorized request.");
                return Response.status(Response.Status.UNAUTHORIZED).entity("").build();
            }
        } catch (AccessDeniedException ex) {
            logger.error("Error occurred::", ex);
            return Response.status(Response.Status.FORBIDDEN).entity("").build();
        } catch (Exception ex) {
            logger.error("Error occurred:: ", ex);
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("").build();
        }
    }
    
    @Path("/triggeruserpaid")
    @POST
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    @Produces(MediaType.APPLICATION_JSON)
    public Response triggerUserPaid(@FormParam("userId") int userId, @FormParam("ispaid") short isPaid) throws IOException {

        logger.debug("triggerUserPaid params userId = " + userId + " , isPaid = " + isPaid);

        try {
            if (userLoginService.isLoggedIn()) {
                LoggedUser loggedUser = userLoginService.getLoggedUserUtil();
                logger.debug("logged user : " + loggedUser.toString());

                String result = adminService.triggerUserPaid(loggedUser.getId(), userId, isPaid);
                logger.info("user paid status changed successfully"); 
                return Response.ok(result, MediaType.APPLICATION_JSON).build();
            } else {
                logger.info("unauthorized request.");
                return Response.status(Response.Status.UNAUTHORIZED).entity("").build();
            }
        } catch (AccessDeniedException ex) {
            logger.error("Error occurred::", ex);
            return Response.status(Response.Status.FORBIDDEN).entity("").build();
        } catch (Exception ex) {
            logger.error("Error occurred:: ", ex);
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("").build();
        }
    }

    @Path("/triggermodule")
    @POST
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    @Produces(MediaType.APPLICATION_JSON)
    public Response triggerModule(@FormParam("moduleId") int moduleId) throws IOException {

        logger.debug("triggerModule params moduleId = " + moduleId);

        try {
            if (userLoginService.isLoggedIn()) {
                LoggedUser loggedUser = userLoginService.getLoggedUserUtil();
                logger.debug("logged user : " + loggedUser.toString());
                logger.info("changed module delete status for moduleId: " + moduleId + ", request from username: " + loggedUser.getUsername() + " userId: " + loggedUser.getId().toString());
                String result = adminService.triggerModule(loggedUser.getId(), moduleId);
                logger.info("module delete status changed successfully.");
                return Response.ok(result, MediaType.APPLICATION_JSON).build();
            } else {
                logger.info("unauthorized request.");
                return Response.status(Response.Status.UNAUTHORIZED).entity("").build();
            }
        } catch (AccessDeniedException ex) {
            logger.error("Error occurred::", ex);
            return Response.status(Response.Status.FORBIDDEN).entity("").build();
        } catch (Exception ex) {
            logger.error("Error occurred:: ", ex);
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("").build();
        }
    }

    @Path("/updatemodule")
    @POST
    @Consumes(MediaType.MULTIPART_FORM_DATA)
    @Produces(MediaType.APPLICATION_JSON)
    public Response updatedModule(@FormDataParam("moduleId") int moduleId,
            @FormDataParam("title") String title,
            @FormDataParam("shortDescription") String shortDescription,
            @FormDataParam("longDescription") String longDescription,
            @FormDataParam("imageFile") InputStream imageFileInputStream,
            @FormDataParam("imageFile") FormDataContentDisposition imageFileDetail,
            @FormDataParam("iconFile") InputStream iconFileInputStream,
            @FormDataParam("iconFile") FormDataContentDisposition iconFileDetail) throws IOException {

        logger.debug("uploadModule params moduleId = " + moduleId + " , title = " + title
                + " , shortDescription = " + shortDescription + " , longDescription = " + longDescription);

        try {
            if (userLoginService.isLoggedIn()) {
                LoggedUser loggedUser = userLoginService.getLoggedUserUtil();
                logger.debug("logged user : " + loggedUser.toString());
                logger.info("update module, moduleId = " + moduleId + ", request from username: " + loggedUser.getUsername() + " userId: " + loggedUser.getId().toString());
                String imageFileName = null;
                String iconFileName = null;

				//logger.debug("!!!" + context.getRealPath(KidvisionWebConfig.MODULE_IMAGES_DIRECTORY));
                //String webRoot = context.getRealPath(context.getContextPath());
                FileProcessor fileProcessor = new FileProcessor();
                if (imageFileInputStream != null && imageFileDetail != null) {
                    logger.debug("image name " + imageFileDetail.getFileName());

                    //if ( fileProcessor.writeToWebapp(context.getRealPath("/module_images")+"/", imageFileInputStream, imageFileDetail) ) {
                    if (fileProcessor.writeToWebapp(KidvisionWebConfig.MODULE_IMAGE_DIRECTORY, imageFileInputStream, imageFileDetail)) {
                        logger.debug("image saved locally.");
                        imageFileName = imageFileDetail.getFileName();
                    }
                }

                if (iconFileInputStream != null && iconFileDetail != null) {
                    logger.debug("icon name " + iconFileDetail.getFileName());

                    //if ( fileProcessor.writeToWebapp(context.getRealPath("/module_icons")+"/", iconFileInputStream, iconFileDetail) ) {
                    if (fileProcessor.writeToWebapp(KidvisionWebConfig.MODULE_ICON_DIRECTORY, iconFileInputStream, iconFileDetail)) {
                        logger.debug("icon saved locally.");
                        iconFileName = iconFileDetail.getFileName();
                    }
                }

                String result = adminService.updateModule(loggedUser.getId(), moduleId, title, shortDescription, longDescription,
                        imageFileName, iconFileName);
                logger.info("module updated successfully. moduleId: " + moduleId);
                return Response.ok(result, MediaType.APPLICATION_JSON).build();
            } else {
                logger.info("unauthorized request.");
                return Response.status(Response.Status.UNAUTHORIZED).entity("").build();
            }
        } catch (AccessDeniedException ex) {
            logger.error("Error occurred::", ex);
            return Response.status(Response.Status.FORBIDDEN).entity("").build();
        } catch (Exception ex) {
            logger.error("Error occurred:: ", ex);
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("").build();
        }
    }

    @Path("/updatemoduleresource")
    @POST
    @Consumes(MediaType.MULTIPART_FORM_DATA)
    @Produces(MediaType.APPLICATION_JSON)
    public Response updatedModuleResource(@FormDataParam("moduleId") int moduleId,
            @FormDataParam("resourceId") int resourceId,
            @FormDataParam("title") String title,
            @FormDataParam("shortDescription") String shortDescription,
            @FormDataParam("link") String link,
            @FormDataParam("imageFile") InputStream imageFileInputStream,
            @FormDataParam("imageFile") FormDataContentDisposition imageFileDetail) throws IOException {

        logger.debug("uploadModule params moduleId = " + moduleId + " , resourceId = " + resourceId + " , title = " + title
                + " , shortDescription = " + shortDescription + " , link = " + link);

        try {
            if (userLoginService.isLoggedIn()) {
                LoggedUser loggedUser = userLoginService.getLoggedUserUtil();
                logger.debug("logged user : " + loggedUser.toString());
                logger.info("update module resource request for moduleId: " + moduleId + " from username: " + loggedUser.getUsername() + " userId: " + loggedUser.getId().toString());
                String imageFileName = null;

                FileProcessor fileProcessor = new FileProcessor();
                if (imageFileInputStream != null && imageFileDetail != null) {
                    logger.debug("image name " + imageFileDetail.getFileName());

                    //if ( fileProcessor.writeToWebapp(context.getRealPath("/module_resource_images")+"/", imageFileInputStream, imageFileDetail) ) {
                    if (fileProcessor.writeToWebapp(KidvisionWebConfig.MODULE_RESOURCE_IMAGE_DIRECTORY, imageFileInputStream, imageFileDetail)) {
                        logger.debug("image saved locally.");
                        imageFileName = imageFileDetail.getFileName();
                    }
                }

                String result = adminService.createOrUpdateModuleResource(loggedUser.getId(), moduleId, resourceId, title, shortDescription, link, imageFileName);
                logger.info("module resource updated successfully.");
                return Response.ok(result, MediaType.APPLICATION_JSON).build();
            } else {
                logger.info("unauthorized request.");
                return Response.status(Response.Status.UNAUTHORIZED).entity("").build();
            }
        } catch (AccessDeniedException ex) {
            logger.error("Error occurred::", ex);
            return Response.status(Response.Status.FORBIDDEN).entity("").build();
        } catch (Exception ex) {
            logger.error("Error occurred:: ", ex);
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("").build();
        }
    }

    /*@Path("/updatemodulepreviewvideo")
     @POST
     @Consumes(MediaType.MULTIPART_FORM_DATA)
     @Produces(MediaType.APPLICATION_JSON)
     public Response updateModulePreviewVideo(@FormDataParam("moduleId") int moduleId,
     @FormDataParam("previewId") int previewId,
     @FormDataParam("previewFile") InputStream previewInputStream,
     @FormDataParam("previewFile") FormDataContentDisposition previewDetail) {
     logger.debug("updateModulePreviewVideo params moduleId = " + moduleId + " , previewId = " + previewId);
     try {
     if ( userLoginService.isLoggedIn() ) {
     LoggedUser loggedUser = userLoginService.getLoggedUserUtil();
     logger.debug("logged user : " + loggedUser.toString());
				
     // better to create once when application starts
     File newUploadedFile = new File(KidvisionWebConfig.UPLOADED_VIDEOS_DIRECTORY);
     if (!newUploadedFile.exists()) {  // Checks that Directory/Folder Doesn't Exists!  
     if(newUploadedFile.mkdir()) {  
     logger.debug("create folder " + KidvisionWebConfig.UPLOADED_VIDEOS_DIRECTORY);
     }
     }
				
     FileProcessor fileProcessor=new FileProcessor();
				
     if (previewInputStream != null && previewDetail != null) {
     logger.debug("preview name " + previewDetail.getFileName());
		        		        	
     if ( fileProcessor.writeToFile(previewInputStream, previewDetail) ) {
     logger.debug("preview saved locally.");
		        		
     logger.debug("start process to upload preview to youtube server.");
     String streamId = videoProcessor.uploadVideo(previewDetail.getFileName(), loggedUser.getId(), moduleId,  
     (short)1, null);
     logger.debug("preview upload process started.");
		                
     //if (streamId != null) {
     //	int newPreviewId = adminService.createVideo(loggedUser.getId(), moduleId, previewDetail.getFileName(), 
     //			streamId, (short)1, null);
     //}
     }
     }
		
     String result = adminService.getModule(moduleId);

     return Response.ok(result, MediaType.APPLICATION_JSON).build();
     }
     else {
     return Response.status(Response.Status.UNAUTHORIZED).entity("").build();
     }
     } catch (AccessDeniedException ex) {
     logger.error("Error occurred::", ex);
     return Response.status(Response.Status.FORBIDDEN).entity("").build();
     } catch (Exception ex) {
     logger.error("Error occurred:: ", ex);
     return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("").build();
     }
     }*/
    @Path("/updatemodulevideo")
    @POST
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    @Produces(MediaType.APPLICATION_JSON)
    public Response updateModuleVideo(@FormParam("moduleId") int moduleId, @FormParam("videoId") int videoId) throws IOException {

        logger.debug("updateModuleVideo params moduleId = " + moduleId + " , videoId = " + videoId);

        try {
            if (userLoginService.isLoggedIn()) {
                LoggedUser loggedUser = userLoginService.getLoggedUserUtil();
                logger.debug("logged user : " + loggedUser.toString());
                logger.info("update module video request for moduleId= " + moduleId + " from username: " + loggedUser.getUsername() + " userId: " + loggedUser.getId().toString());
                if (videoId != -1) {
                    String result = adminService.createOrUpdateVideo(loggedUser.getId(), moduleId, videoId);
                    logger.info("module video updated successfully.");
                    return Response.ok(result, MediaType.APPLICATION_JSON).build();
                } else {
                    logger.info("Invalid video stream id.");
                    return Response.status(Response.Status.NOT_FOUND).entity("").build();
                }
                
            } else {
                logger.info("unauthorized request.");
                return Response.status(Response.Status.UNAUTHORIZED).entity("").build();
            }
        } catch (AccessDeniedException ex) {
            logger.error("Error occurred::", ex);
            return Response.status(Response.Status.FORBIDDEN).entity("").build();
        } catch (Exception ex) {
            logger.error("Error occurred:: ", ex);
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("").build();
        }
    }

    @Path("/uploadmodulevideo")
    @POST
    @Consumes(MediaType.MULTIPART_FORM_DATA)
    @Produces(MediaType.APPLICATION_JSON)
    public Response uploadModuleVideo(@FormDataParam("moduleId") int moduleId,
            @FormDataParam("isOverview") int isOverview,
            @FormDataParam("videoFile") InputStream uploadedInputStream,
            @FormDataParam("videoFile") FormDataContentDisposition fileDetail) {
        logger.debug("uploadModuleVideo params moduleId = " + moduleId + " , isOverview = " + isOverview);
        try {
            if (userLoginService.isLoggedIn()) {
                LoggedUser loggedUser = userLoginService.getLoggedUserUtil();
                logger.debug("logged user : " + loggedUser.toString());
                logger.info("Upload module video request for moduleId= " + moduleId + " from username: " + loggedUser.getUsername() + " userId: " + loggedUser.getId().toString());
                // better to create once when application starts
                File newUploadedFile = new File(KidvisionWebConfig.UPLOADED_VIDEOS_DIRECTORY);
                if (!newUploadedFile.exists()) {  // Checks that Directory/Folder Doesn't Exists!  
                    if (newUploadedFile.mkdir()) {
                        logger.debug("create folder " + KidvisionWebConfig.UPLOADED_VIDEOS_DIRECTORY);
                    }
                }

                if (uploadedInputStream != null && fileDetail != null) {
                    logger.debug("video name " + fileDetail.getFileName());

                    FileProcessor fileProcessor = new FileProcessor();
                    if (fileProcessor.writeToFile(uploadedInputStream, fileDetail)) {
                        logger.debug("video saved locally.");

                        String result = adminService.createOrUpdateUploadedVideo(loggedUser.getId(), moduleId, (short) isOverview, fileDetail.getFileName());

                        logger.debug("start process to upload file to youtube server.");
                        videoProcessor.uploadVideo(fileDetail.getFileName(), loggedUser.getId(), moduleId,
                                (short) isOverview, null);
                        logger.debug("video upload process started.");
                        logger.info("new video uploaded for module successfully.");
                        return Response.ok(result, MediaType.APPLICATION_JSON).build();
                    }
                }

                return Response.status(Response.Status.UNAUTHORIZED).entity("").build();
            } else {
                logger.info("unauthorized request.");
                return Response.status(Response.Status.UNAUTHORIZED).entity("").build();
            }
        } catch (AccessDeniedException ex) {
            logger.error("Error occurred::", ex);
            return Response.status(Response.Status.FORBIDDEN).entity("").build();
        } catch (Exception ex) {
            logger.error("Error occurred:: ", ex);
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("").build();
        }
    }

    /*@Path("/updatemodulevideos")
     @POST
     @Consumes(MediaType.MULTIPART_FORM_DATA)
     @Produces(MediaType.APPLICATION_JSON)
     public Response updateModuleVideos(@FormDataParam("moduleId") int moduleId,
     @FormDataParam("videoId") int videoId,
     @FormDataParam("previewId") int previewId,
     @FormDataParam("videoFile") InputStream uploadedInputStream,
     @FormDataParam("videoFile") FormDataContentDisposition fileDetail,
     @FormDataParam("previewFile") InputStream previewInputStream,
     @FormDataParam("previewFile") FormDataContentDisposition previewDetail) {
     logger.debug("updateModuleVideos params moduleId = " + moduleId + " , videoId = " + videoId +
     " , previewId = " + previewId);
     try {
     if ( userLoginService.isLoggedIn() ) {
     LoggedUser loggedUser = userLoginService.getLoggedUserUtil();
     logger.debug("logged user : " + loggedUser.toString());
				
     // better to create once when application starts
     File newUploadedFile = new File(KidvisionWebConfig.UPLOADED_VIDEOS_DIRECTORY);
     if (!newUploadedFile.exists()) {  // Checks that Directory/Folder Doesn't Exists!  
     if(newUploadedFile.mkdir()) {  
     logger.debug("create folder " + KidvisionWebConfig.UPLOADED_VIDEOS_DIRECTORY);
     }
     }
				
     FileProcessor fileProcessor=new FileProcessor();
     if (uploadedInputStream != null && fileDetail != null) {
     logger.debug("video name " + fileDetail.getFileName());
		        		        	
     if ( fileProcessor.writeToFile(uploadedInputStream, fileDetail) ) {
     logger.debug("video saved locally.");
		        		
     logger.debug("start process to upload file to youtube server.");
     String streamId = videoProcessor.uploadVideo(fileDetail.getFileName(), loggedUser.getId(), moduleId, 
     (short)0, null);
     logger.debug("video upload process started.");
		                
     //if (streamId != null) {
     //	int newVideoId = adminService.createVideo(loggedUser.getId(), moduleId, fileDetail.getFileName(), 
     //			streamId, (short)0, null);
     //}
     }
     }
     else if (videoId != -1) {
     //adminService.updateVideo(videoId, loggedUser.getId(), moduleId, fileDetail.getFileName(), 
     //    			streamId, (short)0, null))
     }
		        
     if (previewInputStream != null && previewDetail != null) {
     logger.debug("preview name " + previewDetail.getFileName());
		        		        	
     if ( fileProcessor.writeToFile(previewInputStream, previewDetail) ) {
     logger.debug("preview saved locally.");
		        		
     logger.debug("start process to upload preview to youtube server.");
     String streamId = videoProcessor.uploadVideo(previewDetail.getFileName(), loggedUser.getId(), moduleId,  
     (short)1, null);
     logger.debug("preview upload process started.");
		                
     //if (streamId != null) {
     //	int newPreviewId = adminService.(loggedUser.getId(), moduleId, previewDetail.getFileName(), 
     //			streamId, (short)1, null);
     //}
     }
     }
		
     String result = adminService.getModule(moduleId);

     return Response.ok(result, MediaType.APPLICATION_JSON).build();
     }
     else {
     return Response.status(Response.Status.UNAUTHORIZED).entity("").build();
     }
     } catch (AccessDeniedException ex) {
     logger.error("Error occurred::", ex);
     return Response.status(Response.Status.FORBIDDEN).entity("").build();
     } catch (Exception ex) {
     logger.error("Error occurred:: ", ex);
     return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("").build();
     }
     }*/
    @Path("/triggersurveyquestion")
    @POST
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    @Produces(MediaType.TEXT_HTML)
    public Response triggerSurveyQuestion(@FormParam("questionId") int questionId) {
        logger.debug("triggerSurveyQuestion params questionId = " + questionId);
        try {
            if (userLoginService.isLoggedIn()) {
                LoggedUser loggedUser = userLoginService.getLoggedUserUtil();
                logger.debug("logged user : " + loggedUser.toString());
                logger.info("update survey question status for questionId = " + questionId + ", request from username: " + loggedUser.getUsername() + " userId: " + loggedUser.getId().toString());
                String result = adminService.triggerSurveyQuestion(loggedUser.getId(), questionId);
                return Response.ok(result).build();
            } else {
                logger.info("unauthorized request.");
                return Response.status(Response.Status.UNAUTHORIZED).entity("").build();
            }
        } catch (AccessDeniedException ex) {
            logger.error("Error occurred::", ex);
            return Response.status(Response.Status.FORBIDDEN).entity("").build();
        } catch (Exception ex) {
            logger.error("Error occurred:: ", ex);
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("").build();
        }
    }

    @Path("/updatesurveyquestion")
    @POST
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    @Produces(MediaType.TEXT_HTML)
    public Response updateSurveyQuestion(@FormParam("questionId") int questionId,
            @FormParam("question") String question, @FormParam("sequence") int sequence) {
        logger.debug("updateSurveyQuestion params question = " + question + " , sequence = " + sequence + " , questionId = " + questionId);
        try {
            if (userLoginService.isLoggedIn()) {
                LoggedUser loggedUser = userLoginService.getLoggedUserUtil();
                logger.debug("updateSurveyQuestion logged user : " + loggedUser.toString());
                logger.info("update survey question for questionId = " + questionId + ", request from username: " + loggedUser.getUsername() + " userId: " + loggedUser.getId().toString());
                String result = adminService.updateSurveyQuestion(loggedUser.getId(), questionId, question, sequence);
                logger.info("survey updated.");
                return Response.ok(result).build();
            } else {
                logger.info("unauthorized request.");
                return Response.status(Response.Status.UNAUTHORIZED).entity("").build();
            }
        } catch (AccessDeniedException ex) {
            logger.error("Error occurred::", ex);
            return Response.status(Response.Status.FORBIDDEN).entity("").build();
        } catch (Exception ex) {
            logger.error("Error occurred:: ", ex);
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("").build();
        }
    }

    @Path("/createsurveyquestion")
    @POST
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    @Produces(MediaType.TEXT_HTML)
    public Response createSurveyQuestion(@FormParam("question") String question, @FormParam("sequence") int sequence) {
        logger.debug("createSurveyQuestion params question = " + question + " , sequence = " + sequence);
        try {
            
            if (userLoginService.isLoggedIn()) {
                LoggedUser loggedUser = userLoginService.getLoggedUserUtil();
                logger.debug("createSurveyQuestion logged user : " + loggedUser.toString());
                logger.info("create new survey question request from username: " + loggedUser.getUsername() + " userId: " + loggedUser.getId().toString());
                String result = adminService.createSurveyQuestion(loggedUser.getId(), question, sequence);
                return Response.ok(result).build();
            } else {
                logger.info("unauthorized request.");
                return Response.status(Response.Status.UNAUTHORIZED).entity("").build();
            }
        } catch (AccessDeniedException ex) {
            logger.error("Error occurred::", ex);
            return Response.status(Response.Status.FORBIDDEN).entity("").build();
        } catch (Exception ex) {
            logger.error("Error occurred:: ", ex);
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("").build();
        }
    }

    @Path("/createmodule")
    @POST
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    @Produces(MediaType.TEXT_HTML)
    public Response createModule(@FormParam("moduleid") int moduleId, @FormParam("title") String title) {
        logger.debug("createModule params moduleid = " + moduleId + " , title = " + title);
        try {
            if (userLoginService.isLoggedIn()) {
                LoggedUser loggedUser = userLoginService.getLoggedUserUtil();
                logger.debug("createModule logged user : " + loggedUser.toString());
                logger.info("create new module from existing moduleId = " + moduleId + ", request from username: " + loggedUser.getUsername() + " userId: " + loggedUser.getId().toString());
                if (title != null && title != "") {
                    String result = adminService.createModule(loggedUser.getId(), moduleId, title);
                    logger.info("new module created.");
                    return Response.ok(result).build();
                }
                return Response.status(Response.Status.BAD_REQUEST).entity("").build();
            } else {
                logger.info("unauthorized request.");
                return Response.status(Response.Status.UNAUTHORIZED).entity("").build();
            }
        } catch (AccessDeniedException ex) {
            logger.error("Error occurred::", ex);
            return Response.status(Response.Status.FORBIDDEN).entity("").build();
        } catch (Exception ex) {
            logger.error("Error occurred:: ", ex);
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("").build();
        }
    }

    @Path("/createmodulequestion")
    @POST
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    @Produces(MediaType.APPLICATION_JSON)
    public Response createModuleQuestion(@FormParam("moduleId") int moduleId,
            @FormParam("question") String question, @FormParam("sequence") int sequence,
            @FormParam("standardId") int standardId, @FormParam("a0") String a0, @FormParam("a1") String a1,
            @FormParam("correct") int correct, @FormParam("a2") String a2, @FormParam("a3") String a3) {
        logger.debug("createModuleQuestion params moduleid = " + moduleId + " , question = " + question + " , correct = " + correct
                + " , sequence = " + sequence + " , standardId = " + standardId + " , a0 = " + a0
                + " , a1 = " + a1 + " , a2 = " + a2 + " , a3 = " + a3);
        try {
            if (userLoginService.isLoggedIn()) {
                LoggedUser loggedUser = userLoginService.getLoggedUserUtil();
                logger.debug("createModuleQuestion logged user : " + loggedUser.toString());
                logger.info("create new module question request from username: " + loggedUser.getUsername() + " userId: " + loggedUser.getId().toString());
                adminService.deleteModuleQuestion(moduleId, sequence);
                int qid = adminService.createModuleQuestion(moduleId, question, sequence, standardId);

                if (qid != -1) {
					//String[] ansArray = answers.split(",");
                    //for (int i = 0; i < ansArray.length; i++) {
                    //logger.debug("qid = " + qid + " , ans = " + ansArray[i]);
                    //if (i == correct) {
                    if (correct == 0) {
                        adminService.createModuleQuestionAnswer(qid, a0, (short) 1, null);
                    } else {
                        adminService.createModuleQuestionAnswer(qid, a0, (short) 0, null);
                    }
					//}

                    if (correct == 1) {
                        adminService.createModuleQuestionAnswer(qid, a1, (short) 1, null);
                    } else {
                        adminService.createModuleQuestionAnswer(qid, a1, (short) 0, null);
                    }

                    if (correct == 2) {
                        adminService.createModuleQuestionAnswer(qid, a2, (short) 1, null);
                    } else {
                        adminService.createModuleQuestionAnswer(qid, a2, (short) 0, null);
                    }

                    if (correct == 3) {
                        adminService.createModuleQuestionAnswer(qid, a3, (short) 1, null);
                    } else {
                        adminService.createModuleQuestionAnswer(qid, a3, (short) 0, null);
                    }

                    String result = adminService.getQuestionAndAnsers(qid);
                    logger.info("module question created successfully.");
                    return Response.ok(result, MediaType.APPLICATION_JSON).build();
                }
                return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("").build();
            } else {
                logger.info("unauthorized request.");
                return Response.status(Response.Status.UNAUTHORIZED).entity("").build();
            }
        } catch (AccessDeniedException ex) {
            logger.error("Error occurred::", ex);
            return Response.status(Response.Status.FORBIDDEN).entity("").build();
        } catch (Exception ex) {
            logger.error("Error occurred:: ", ex);
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("").build();
        }
    }

    @Path("/getModule")
    @GET
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    @Produces(MediaType.APPLICATION_JSON)
    public Response getModule(@QueryParam("mid") int moduleId) {
        logger.debug("getModule param moduleId = " + moduleId);
        try {
            logger.info("get module.");
            if (userLoginService.isLoggedIn()) {
                LoggedUser loggedUser = userLoginService.getLoggedUserUtil();
                logger.debug("getModule logged user : " + loggedUser.toString());
                logger.info("request from username: " + loggedUser.getUsername() + ", userId: " + loggedUser.getId().toString());
                String result = adminService.getModule(moduleId);

                return Response.ok(result, MediaType.APPLICATION_JSON).build();
            } else {
                logger.info("unauthorized request.");
                return Response.status(Response.Status.UNAUTHORIZED).entity("").build();
            }
        } catch (AccessDeniedException ex) {
            logger.error("Error occurred::", ex);
            return Response.status(Response.Status.FORBIDDEN).entity("").build();
        } catch (Exception ex) {
            logger.error("Error occurred:: ", ex);
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("").build();
        }
    }

    @Path("/getmodulevideos")
    @GET
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    @Produces(MediaType.APPLICATION_JSON)
    public Response getModuleVideos(@QueryParam("mid") int moduleId) {
        try {
            logger.info("get module videos.");
            if (userLoginService.isLoggedIn()) {
                LoggedUser loggedUser = userLoginService.getLoggedUserUtil();
                logger.debug("getModuleVideos logged user : " + loggedUser.toString());
                logger.info("request from username: " + loggedUser.getUsername() + " userId: " + loggedUser.getId().toString());
                String result = adminService.getModuleVideos(moduleId);

                return Response.ok(result, MediaType.APPLICATION_JSON).build();
            } else {
                logger.info("unauthorized request.");
                return Response.status(Response.Status.UNAUTHORIZED).entity("").build();
            }
        } catch (AccessDeniedException ex) {
            logger.error("Error occurred::", ex);
            return Response.status(Response.Status.FORBIDDEN).entity("").build();
        } catch (Exception ex) {
            logger.error("Error occurred:: ", ex);
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("").build();
        }
    }

    @Path("/allmodules")
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response getAllModules() {
        try {
            logger.info("get all modules.");
            if (userLoginService.isLoggedIn()) {
                LoggedUser loggedUser = userLoginService.getLoggedUserUtil();
                logger.debug("getAllModules logged user : " + loggedUser.toString());
                logger.info("request from username: " + loggedUser.getUsername() + " userId: " + loggedUser.getId().toString());
                String result = adminService.getAllModules();

                return Response.ok(result, MediaType.APPLICATION_JSON).build();
            } else {
                logger.info("unauthorized request.");
                return Response.status(Response.Status.UNAUTHORIZED).entity("").build();
            }
        } catch (AccessDeniedException ex) {
            logger.error("Error occurred::", ex);
            return Response.status(Response.Status.FORBIDDEN).entity("").build();
        } catch (Exception ex) {
            logger.error("Error occurred:: ", ex);
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("").build();
        }
    }

    @Path("/allvideos")
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response getAllVideos() {
        try {
            logger.info("get all videos.");
            if (userLoginService.isLoggedIn()) {
                LoggedUser loggedUser = userLoginService.getLoggedUserUtil();
                logger.debug("getAllVideos logged user : " + loggedUser.toString());
                logger.info("request from username: " + loggedUser.getUsername() + " userId: " + loggedUser.getId().toString());
                String result = adminService.getAllVideos();

                return Response.ok(result, MediaType.APPLICATION_JSON).build();
            } else {
                logger.info("unauthorized request.");
                return Response.status(Response.Status.UNAUTHORIZED).entity("").build();
            }
        } catch (AccessDeniedException ex) {
            logger.error("Error occurred::", ex);
            return Response.status(Response.Status.FORBIDDEN).entity("").build();
        } catch (Exception ex) {
            logger.error("Error occurred:: ", ex);
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("").build();
        }
    }

    @Path("/alluserspagination")
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response getAllUsersPagination(@QueryParam("iDisplayLength") int length, @QueryParam("iDisplayStart") int start,
            @QueryParam("iSortCol_0") int orderIndex, @QueryParam("sSortDir_0") String order,
            @QueryParam("sSearch") String search) {
        logger.debug("alluserspagination length = " + length + " , start = " + start + " , orderIndex = " + orderIndex
                + " , order = " + order);
        try {
            logger.info("get users, length = " + length + " , start = " + start + " , orderIndex = " + orderIndex
                + " , order = " + order);
            if (userLoginService.isLoggedIn()) {
                LoggedUser loggedUser = userLoginService.getLoggedUserUtil();
                logger.debug("getAllUsersPagination logged user : " + loggedUser.toString());
                logger.info("request from username: " + loggedUser.getUsername() + " userId: " + loggedUser.getId().toString());
                String result = adminService.getAllUsersPagination(length, start, orderIndex, order, search);

                return Response.ok(result, MediaType.APPLICATION_JSON).build();
            } else {
                logger.info("unauthorized request.");
                return Response.status(Response.Status.UNAUTHORIZED).entity("").build();
            }
        } catch (AccessDeniedException ex) {
            logger.error("Error occurred::", ex);
            return Response.status(Response.Status.FORBIDDEN).entity("").build();
        } catch (Exception ex) {
            logger.error("Error occurred:: ", ex);
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("").build();
        }
    }

    @Path("/countUsersByCountyStatePagination")
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response countUsersByCountyStatePagination(@QueryParam("iDisplayLength") int length, @QueryParam("iDisplayStart") int start,
            @QueryParam("iSortCol_0") int orderIndex, @QueryParam("sSortDir_0") String order,
            @QueryParam("sSearch") String search) {
        logger.debug("countUsersByCountyStatePagination length = " + length + " , start = " + start + " , orderIndex = " + orderIndex
                + " , order = " + order);
        try {
            logger.info("user count by county, length = " + length + " , start = " + start + " , orderIndex = " + orderIndex
                + " , order = " + order);
            if (userLoginService.isLoggedIn()) {
                LoggedUser loggedUser = userLoginService.getLoggedUserUtil();
                logger.debug("countUsersByCountyStatePagination logged user : " + loggedUser.toString());
                logger.info("request from username: " + loggedUser.getUsername() + " userId: " + loggedUser.getId().toString());
                String result = adminService.countUsersByCountyStatePagination(length, start, orderIndex, order, search);

                return Response.ok(result, MediaType.APPLICATION_JSON).build();
            } else {
                logger.info("unauthorized request.");
                return Response.status(Response.Status.UNAUTHORIZED).entity("").build();
            }
        } catch (AccessDeniedException ex) {
            logger.error("Error occurred::", ex);
            return Response.status(Response.Status.FORBIDDEN).entity("").build();
        } catch (Exception ex) {
            logger.error("Error occurred:: ", ex);
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("").build();
        }
    }

    @Path("/surveyquestions")
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response getSurveyQuestions() {
        try {
            logger.info("get survey questions.");
            if (userLoginService.isLoggedIn()) {
                LoggedUser loggedUser = userLoginService.getLoggedUserUtil();
                logger.debug("getSurveyQuestions logged user : " + loggedUser.toString());
                logger.info("request from username: " + loggedUser.getUsername() + " userId: " + loggedUser.getId().toString());
                String result = adminService.getSurveyQuestions();

                return Response.ok(result, MediaType.APPLICATION_JSON).build();
            } else {
                logger.info("unauthorized request.");
                return Response.status(Response.Status.UNAUTHORIZED).entity("").build();
            }
        } catch (AccessDeniedException ex) {
            logger.error("Error occurred::", ex);
            return Response.status(Response.Status.FORBIDDEN).entity("").build();
        } catch (Exception ex) {
            logger.error("Error occurred:: ", ex);
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("").build();
        }
    }

    @Path("/surveyresults")
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response getSurveyResults() {
        try {
            logger.info("get survey result.");
            if (userLoginService.isLoggedIn()) {
                LoggedUser loggedUser = userLoginService.getLoggedUserUtil();
                logger.debug("getSurveyResults logged user : " + loggedUser.toString());
                logger.info("request from username: " + loggedUser.getUsername() + " userId: " + loggedUser.getId().toString());
                String result = adminService.getSurveyResults();

                return Response.ok(result, MediaType.APPLICATION_JSON).build();
            } else {
                logger.info("unauthorized request.");
                return Response.status(Response.Status.UNAUTHORIZED).entity("").build();
            }
        } catch (AccessDeniedException ex) {
            logger.error("Error occurred::", ex);
            return Response.status(Response.Status.FORBIDDEN).entity("").build();
        } catch (Exception ex) {
            logger.error("Error occurred:: ", ex);
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("").build();
        }
    }

    @Path("/getusersurveyanswers")
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response getUserSurveyAnswers() {
        try {
            logger.info("get users survey answers.");
            if (userLoginService.isLoggedIn()) {
                LoggedUser loggedUser = userLoginService.getLoggedUserUtil();
                logger.debug("getSurveyResults logged user : " + loggedUser.toString());
                logger.info("request from username: " + loggedUser.getUsername() + " userId: " + loggedUser.getId().toString());
                String result = adminService.getUserSurveyAnswers();

                return Response.ok(result, MediaType.APPLICATION_JSON).build();
            } else {
                logger.info("unauthorized request.");
                return Response.status(Response.Status.UNAUTHORIZED).entity("").build();
            }
        } catch (AccessDeniedException ex) {
            logger.error("Error occurred::", ex);
            return Response.status(Response.Status.FORBIDDEN).entity("").build();
        } catch (Exception ex) {
            logger.error("Error occurred:: ", ex);
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("").build();
        }
    }
    
    @Path("/getallusermodulesurveyanswers")
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response getUserModuleSurveyAnswers() {
        try {
            logger.info("getallusermodulesurveyanswers");
            if (userLoginService.isLoggedIn()) {
                LoggedUser loggedUser = userLoginService.getLoggedUserUtil();
                logger.info("request from username: " + loggedUser.getUsername() + " userId: " + loggedUser.getId().toString());
                String result = adminService.getAllUserModuleSurveyAnswers();

                return Response.ok(result, MediaType.APPLICATION_JSON).build();
            } else {
                logger.info("unauthorized request.");
                return Response.status(Response.Status.UNAUTHORIZED).entity("").build();
            }
        } catch (AccessDeniedException ex) {
            logger.error("Error occurred::", ex);
            return Response.status(Response.Status.FORBIDDEN).entity("").build();
        } catch (Exception ex) {
            logger.error("Error occurred:: ", ex);
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("").build();
        }
    }
    
    @Path("/getusermoduleactivityfieldtripcvs")
    @GET
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    @Produces(MediaType.APPLICATION_OCTET_STREAM)
    public Response getUserModuleActivityFieldtripCVS() {
    	logger.debug("getUserModuleActivityFieldtripCVS");
        try {        	
        	if ( userLoginService.isLoggedIn() ) {
	    		LoggedUser loggedUser = userLoginService.getLoggedUserUtil();
	    		logger.debug("getusermoduleactivityfieldtripcvs logged user : " + loggedUser.toString());
	            
	    		String title = "all";
	    		String pathname = adminService.getUserModuleActivityFieldtripCVS(title);

	    		File file = new File(pathname);
	    		logger.debug("file fullpath = " + pathname);
	    		
	    		if(file.exists()){
	    			ResponseBuilder responseBuilder = Response.ok(file);
	    			responseBuilder.header("Content-Disposition", "attachment; filename=\"" + title + ".csv\"");
		    		return responseBuilder.build();
	    		}
	    		else {
	    			return Response.status(Response.Status.NOT_FOUND).entity("").build();
	    		}
	    	}
	    	else {
	    		return Response.status(Response.Status.UNAUTHORIZED).entity("").build();
	    	}
	    } catch (AccessDeniedException ex) {
	    	logger.error("Error occurred::", ex);
	    	return Response.status(Response.Status.FORBIDDEN).entity("").build();
	    } catch (Exception ex) {
	        logger.error("Error occurred:: ", ex);
	        return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("").build();
	    }
    }

    @Path("/updateuser")
    @POST
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    @Produces(MediaType.TEXT_HTML)
    public Response updateUser(@FormParam("userId") int userId,
            @DefaultValue("") @FormParam("prefix") String prefix,
            @DefaultValue("") @FormParam("firstName") String firstName,
            @DefaultValue("") @FormParam("middleName") String middleName,
            @DefaultValue("") @FormParam("lastName") String lastName,
            @DefaultValue("") @FormParam("educationLevel") String educationLevel,
            @DefaultValue("") @FormParam("email") String email,
            @DefaultValue("") @FormParam("userName") String userName,
            @DefaultValue("6") @FormParam("occupationalTitleId") int occupationalTitleId,
            @DefaultValue("") @FormParam("otherOccupationalTitle") String otherOccupationalTitle,
            @DefaultValue("") @FormParam("phone") String phone,
            @DefaultValue("") @FormParam("schoolName") String schoolName,
            @DefaultValue("1") @FormParam("registrationtypeId") byte registrationtypeId,
            @DefaultValue("true") @FormParam("emailNotification") boolean emailNotification,
            @DefaultValue("-1") @FormParam("primaryAddressId") int primaryAddressId,
            @DefaultValue("") @FormParam("streetAddress") String streetAddress,
            @DefaultValue("") @FormParam("city") String city,
            @DefaultValue("") @FormParam("state") String state,
            @DefaultValue("") @FormParam("county") String county,
            @DefaultValue("") @FormParam("country") String country,
            @DefaultValue("") @FormParam("zipCode") String zipCode) {
        logger.debug("updateUser params userId = " + userId + " , firstName = " + firstName + " , lastName = " + lastName
                + " , middleName = " + middleName + " , educationLevel = " + educationLevel + " , email = " + " , prefix = " + prefix
                + email + " , userName = " + userName + " , occupationalTitleId = " + occupationalTitleId
                + " , otherOccupationalTitle = " + otherOccupationalTitle + " , phone = " + phone + " , emailNotification = " + emailNotification);

        logger.debug("updateProfile params streetAddress = " + streetAddress + " , primaryAddressId = " + primaryAddressId
                + " , city = " + city + " , state = " + state + " , county = "
                + county + " , country = " + country + " , zipCode = " + zipCode);
        try {
            logger.info("update user, userId: " + userId);
            if (userLoginService.isLoggedIn()) {
                LoggedUser loggedUser = userLoginService.getLoggedUserUtil();
                logger.debug("logged user : " + loggedUser.toString());
                logger.info("request from username: " + loggedUser.getUsername() + " userId: " + loggedUser.getId().toString());
                //Integer primaryAddressId = adminService.getUserPrimaryAddressId(userId);
                adminService.addOrUpdateAddress(userId, primaryAddressId, streetAddress,
                        city, county, state, country, zipCode);

                String result = adminService.updateUser(userId, prefix, firstName.trim(), middleName.trim(), lastName.trim(),
                        email.trim(), userName.trim(), educationLevel, occupationalTitleId, otherOccupationalTitle, phone, emailNotification, registrationtypeId,
                        schoolName);
                logger.info("user updated successfully.");
                return Response.ok(result, MediaType.APPLICATION_JSON).build();
            } else {
                logger.info("unauthorized request.");
                return Response.status(Response.Status.UNAUTHORIZED).entity("").build();
            }
        } catch (AccessDeniedException ex) {
            logger.error("Error occurred::", ex);
            return Response.status(Response.Status.FORBIDDEN).entity("").build();
        } catch (Exception ex) {
            logger.error("Error occurred:: ", ex);
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("").build();
        }
    }

    @Path("/getUserAddress")
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response getUserAddress(@QueryParam("addressId") int addressId) {
        logger.debug("getUserAddress");
        try {
            if (userLoginService.isLoggedIn()) {
                LoggedUser loggedUser = userLoginService.getLoggedUserUtil();
                logger.debug("logged user : " + loggedUser.toString());
	    		//Integer primaryAddressId = adminService.getUserPrimaryAddressId(userId);
                //String result = null;
                //if (primaryAddressId != null) {
                String result = adminService.getUserAddress(addressId);
                //}     	
                return Response.ok(result, MediaType.APPLICATION_JSON).build();
            } else {
                logger.info("unauthorized request.");
                return Response.status(Response.Status.UNAUTHORIZED).entity("").build();
            }
        } catch (AccessDeniedException ex) {
            logger.error("Error occurred::", ex);
            return Response.status(Response.Status.FORBIDDEN).entity("").build();
        } catch (Exception ex) {
            logger.error("Error occurred:: ", ex);
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("").build();
        }
    }

    @Path("/getUser")
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response getUser(@QueryParam("userId") int userId) {
        logger.debug("getUser");
        try {
            
            if (userLoginService.isLoggedIn()) {
                LoggedUser loggedUser = userLoginService.getLoggedUserUtil();
                logger.debug("logged user : " + loggedUser.toString());                
                String result = adminService.getUser(userId);

                return Response.ok(result, MediaType.APPLICATION_JSON).build();
            } else {
                logger.info("unauthorized request.");
                return Response.status(Response.Status.UNAUTHORIZED).entity("").build();
            }
        } catch (AccessDeniedException ex) {
            logger.error("Error occurred::", ex);
            return Response.status(Response.Status.FORBIDDEN).entity("").build();
        } catch (Exception ex) {
            logger.error("Error occurred:: ", ex);
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("").build();
        }
    }

    /*
     * [10:00:19 AM] Shrikant Pathak: select distinct umt.user_id, year(umt.started_on) AS testYear ,CONCAT('KIDVISION VPK TRAINING TRANSCRIPT - ', CONCAT(year(umt.started_on), '-', year(umt.started_on)+1)) as testtitle
     from user_module_test umt
     where umt.user_id=40 and umt.is_passed=1 order by umt.user_id;
     */
    @Path("/getnewregistrationusers")
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response getNewRegistrationUsers(@QueryParam("starttime") String starttime, @QueryParam("endtime") String endtime) {
        try {
            
            if (userLoginService.isLoggedIn()) {
                LoggedUser loggedUser = userLoginService.getLoggedUserUtil();
                logger.debug("getSurveyResults logged user : " + loggedUser.toString());
                String result = adminService.getUserSurveyAnswers();

                return Response.ok(result, MediaType.APPLICATION_JSON).build();
            } else {
                logger.info("unauthorized request.");
                return Response.status(Response.Status.UNAUTHORIZED).entity("").build();
            }
        } catch (AccessDeniedException ex) {
            logger.error("Error occurred::", ex);
            return Response.status(Response.Status.FORBIDDEN).entity("").build();
        } catch (Exception ex) {
            logger.error("Error occurred:: ", ex);
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("").build();
        }
    }
    
    @Path("/adminsetuserpassword")
    @POST
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    @Produces(MediaType.TEXT_HTML)
    public Response adminsetuserpassword(@FormParam("userId") int userId, @FormParam("password") String password) {
    	logger.debug("adminsetuserpassword userId = " + userId + " , password = " + password);
		try {
			if ( userLoginService.isLoggedIn() ) {
				LoggedUser loggedUser = userLoginService.getLoggedUserUtil();
				logger.debug("logged user : " + loggedUser.toString());
				
				String result = adminService.updateUserPassword(userId, password);
				return Response.ok(result).build();
			}
        	else {
        		return Response.status(Response.Status.UNAUTHORIZED).entity("").build();
	    	}
		} catch (AccessDeniedException ex) {
        	logger.error("Error occurred::", ex);
        	return Response.status(Response.Status.FORBIDDEN).entity("").build();
        } catch (Exception ex) {
            logger.error("Error occurred:: ", ex);
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("").build();
        }
    }
    
    @Path("/adminsetusername")
    @POST
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    @Produces(MediaType.TEXT_HTML)
    public Response adminsetusername(@FormParam("userId") int userId, @FormParam("username") String username) {
    	logger.debug("adminsetusername userId = " + userId + " , username = " + username);
		try {
			if ( userLoginService.isLoggedIn() ) {
				LoggedUser loggedUser = userLoginService.getLoggedUserUtil();
				logger.debug("logged user : " + loggedUser.toString());
				
				logger.debug("checkUserName param username = " + username);
	    		
				String result = "";
	        	if ( !RegularExpressionUtil.checkUsernamePattern(username) ) {
	        		result = "username pattern";
	        	}
	        	else {
	        		result = adminService.checkUserName(username);
	        		
	        		if (result.equalsIgnoreCase("true")) {
	        			result = adminService.updateUsername(userId, username);
	        		}
	        	}
	        					
				return Response.ok(result).build();
			}
        	else {
        		return Response.status(Response.Status.UNAUTHORIZED).entity("").build();
	    	}
		} catch (AccessDeniedException ex) {
        	logger.error("Error occurred::", ex);
        	return Response.status(Response.Status.FORBIDDEN).entity("").build();
        } catch (Exception ex) {
            logger.error("Error occurred:: ", ex);
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("").build();
        }
    }
}
