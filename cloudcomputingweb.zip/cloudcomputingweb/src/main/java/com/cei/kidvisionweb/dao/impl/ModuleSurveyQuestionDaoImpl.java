

package com.cei.kidvisionweb.dao.impl;

import com.cei.kidvisionweb.dao.ModuleSurveyQuestionDao;
import com.cei.kidvisionweb.db.model.ModuleSurveyQuestion;

public class ModuleSurveyQuestionDaoImpl extends GenericDaoImpl<ModuleSurveyQuestion, Long> implements ModuleSurveyQuestionDao{
    
}
