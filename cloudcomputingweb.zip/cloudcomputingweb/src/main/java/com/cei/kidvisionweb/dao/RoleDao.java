package com.cei.kidvisionweb.dao;


import com.cei.kidvisionweb.db.model.Role;
import java.util.List;

/**
 *
 * @author Shrikant
 */
public interface RoleDao extends GenericDao<Role, Long> {
//    void add(Role object);
//
//    void update(Role object);
//
//    void delete(Role object);
//
    void deleteById(String id);

    public List<Role> getRoles();
}
