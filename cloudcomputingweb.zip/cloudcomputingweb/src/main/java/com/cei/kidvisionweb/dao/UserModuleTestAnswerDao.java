package com.cei.kidvisionweb.dao;

import com.cei.kidvisionweb.db.model.UserModuleTestAnswer;

/**
 *
 * @author Shrikant
 */
public interface UserModuleTestAnswerDao extends GenericDao<UserModuleTestAnswer, Long> {
	
}
