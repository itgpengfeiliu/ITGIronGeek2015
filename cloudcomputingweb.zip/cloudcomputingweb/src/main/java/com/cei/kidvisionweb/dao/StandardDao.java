package com.cei.kidvisionweb.dao;

import java.util.List;
import com.cei.kidvisionweb.db.model.Standard;

/**
 *
 * @author Shrikant
 */
public interface StandardDao extends GenericDao<Standard, Long> {
    
    List<Standard> getModuleStandsByOrder(int moduleId);
}
