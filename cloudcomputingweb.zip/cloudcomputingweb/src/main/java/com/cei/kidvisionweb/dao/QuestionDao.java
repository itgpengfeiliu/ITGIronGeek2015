package com.cei.kidvisionweb.dao;

import java.util.List;

import com.cei.kidvisionweb.db.model.Question;

/**
 *
 * @author Shrikant
 */
public interface QuestionDao extends GenericDao<Question, Long> {
    
    List<Question> getQuestionsAndAnswersByModule(int moduleId);
    
    List<Question> getRandomQuestionsAndAnswers(int count);
}
