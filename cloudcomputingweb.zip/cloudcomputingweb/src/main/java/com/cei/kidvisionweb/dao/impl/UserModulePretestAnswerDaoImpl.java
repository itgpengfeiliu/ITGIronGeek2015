

package com.cei.kidvisionweb.dao.impl;

import com.cei.kidvisionweb.dao.UserModulePretestAnswerDao;
import com.cei.kidvisionweb.db.model.UserModulePretestAnswer;

/**
 *
 * @author Shrikant
 */
public class UserModulePretestAnswerDaoImpl extends GenericDaoImpl<UserModulePretestAnswer, Long> implements UserModulePretestAnswerDao{
    
}
