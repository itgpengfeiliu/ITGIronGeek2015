package com.cei.kidvisionweb.service.util;

import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;

public class EmailService {
	
	@Value("#{kidvisionProperties['email.username']}")
    private String email_username;
    @Value("#{kidvisionProperties['email.password']}")
    private String email_password; // = "51cragwood"; 
    @Value("#{kidvisionProperties['email.from']}")
    private String email_from;
    
    @Value("#{kidvisionProperties['mail.smtp.auth']}")
    private String MAIL_SMTP_AUTH;
    @Value("#{kidvisionProperties['mail.smtp.starttls.enable']}")
    private String MAIL_SMTP_STARTTLS_ENABLE;
    @Value("#{kidvisionProperties['mail.smtp.host']}")
    private String MAIL_SMTP_HOST;
    @Value("#{kidvisionProperties['mail.smtp.port']}")
    private String MAIL_SMTP_PORT;
    
    @Value("#{kidvisionProperties['forgot.password.email.subject']}")
    public String FORGOT_PASSWORD_EMAIL_SUBJECT;
    @Value("#{kidvisionProperties['forgot.username.email.subject']}")
    public String FORGOT_USERNAME_EMAIL_SUBJECT;
    @Value("#{kidvisionProperties['registration.welcome.email.subject']}")
    public String REGISTRATION_WELCOME_EMAIL_SUBJECT;
    
    @Value("#{kidvisionProperties['email.logo.path']}")
    public String email_logo_path;
    
	private static Logger logger = LoggerFactory.getLogger(EmailService.class);
	
	public boolean sendEmail(String emailSubject, String text, String to) {
		
		Properties props = new Properties();
		
		logger.debug("MAIL_SMTP_AUTH = " + MAIL_SMTP_AUTH);
		props.put("mail.smtp.auth", MAIL_SMTP_AUTH);
		
		logger.debug("MAIL_SMTP_STARTTLS_ENABLE = " + MAIL_SMTP_STARTTLS_ENABLE);
		props.put("mail.smtp.starttls.enable", MAIL_SMTP_STARTTLS_ENABLE);
		
		logger.debug("MAIL_SMTP_HOST = " + MAIL_SMTP_HOST);
		props.put("mail.smtp.host", MAIL_SMTP_HOST);
		
		logger.debug("MAIL_SMTP_PORT = " + MAIL_SMTP_PORT);
		props.put("mail.smtp.port", MAIL_SMTP_PORT);
  
		Session session = Session.getDefaultInstance(props,
			new javax.mail.Authenticator() {
				protected PasswordAuthentication getPasswordAuthentication() {
					return new PasswordAuthentication(email_username, email_password);
				}
			});
 
		try {
 
			MimeMessage message = new MimeMessage(session);
			message.setFrom(new InternetAddress(email_from));
			message.setRecipients(Message.RecipientType.TO,
					InternetAddress.parse(to));
			message.setSubject(emailSubject);
			//message.setText(text); 
			message.setContent(text + "<img src='" + email_logo_path + "' alt='logo' height='140' width='380' />", "text/html");
 
			Transport.send(message);
 
			logger.debug("sendEmail subject = " + emailSubject + " , text = " + text + " , to = " + to);
			return true;
		} catch (MessagingException e) {
			logger.error("sendEmail " + e.toString());
		}
		
		return false;
    }
}
