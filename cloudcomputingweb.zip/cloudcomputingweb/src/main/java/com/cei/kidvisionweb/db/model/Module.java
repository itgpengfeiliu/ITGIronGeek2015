package com.cei.kidvisionweb.db.model;


import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import org.apache.commons.lang3.builder.ToStringBuilder;

public class Module implements java.io.Serializable {

    private Integer id;
    private String title;
    private String shortDescription;
    private String longDescription;
    private String pdfLessonPlan;
    private String studentAssessmentForm;
    private String activityPlan;
    private String coloringWorksheets;
    private String imageFile;
    private String iconFile;
    private Integer sequence;
    private Date createdOn;
    private Integer createdbyId;
    private Date updatedOn;
    private Integer modifiedbyId;
    private short deleted;

    private Set<Video> videos = new HashSet<Video>(0);

    private static final long serialVersionUID = 1L;

    public static long getSerialversionuid() {
        return serialVersionUID;
    }

    public Set<Video> getVideos() {
        return videos;
    }

    public void setVideos(Set<Video> videos) {
        this.videos = videos;
    }

    public Module() {
        super();
    }

    public Module(short deleted) {
        this.deleted = deleted;
    }

    public Module(String title, String shortDescription, String longDescription, String pdfLessonPlan, String studentAssessmentForm, String activityPlan, String coloringWorksheets, String imageFile, String iconFile, Integer sequence, Date createdOn, Integer createdbyId, Date updatedOn, Integer modifiedbyId, short deleted) {
        this.title = title;
        this.shortDescription = shortDescription;
        this.longDescription = longDescription;
        this.pdfLessonPlan = pdfLessonPlan;
        this.studentAssessmentForm = studentAssessmentForm;
        this.activityPlan = activityPlan;
        this.coloringWorksheets = coloringWorksheets;
        this.imageFile = imageFile;
        this.iconFile = iconFile;
        this.sequence = sequence;
        this.createdOn = createdOn;
        this.createdbyId = createdbyId;
        this.updatedOn = updatedOn;
        this.modifiedbyId = modifiedbyId;
        this.deleted = deleted;
    }

    public Integer getId() {
        return this.id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getTitle() {
        return this.title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getShortDescription() {
        return this.shortDescription;
    }

    public void setShortDescription(String shortDescription) {
        this.shortDescription = shortDescription;
    }

    public String getLongDescription() {
        return this.longDescription;
    }

    public void setLongDescription(String longDescription) {
        this.longDescription = longDescription;
    }

    public String getPdfLessonPlan() {
        return this.pdfLessonPlan;
    }

    public void setPdfLessonPlan(String pdfLessonPlan) {
        this.pdfLessonPlan = pdfLessonPlan;
    }

    public String getStudentAssessmentForm() {
        return this.studentAssessmentForm;
    }

    public void setStudentAssessmentForm(String studentAssessmentForm) {
        this.studentAssessmentForm = studentAssessmentForm;
    }

    public String getActivityPlan() {
        return this.activityPlan;
    }

    public void setActivityPlan(String activityPlan) {
        this.activityPlan = activityPlan;
    }

    public String getColoringWorksheets() {
        return this.coloringWorksheets;
    }

    public void setColoringWorksheets(String coloringWorksheets) {
        this.coloringWorksheets = coloringWorksheets;
    }

    public String getImageFile() {
        return this.imageFile;
    }

    public void setImageFile(String imageFile) {
        this.imageFile = imageFile;
    }

    public String getIconFile() {
        return this.iconFile;
    }

    public void setIconFile(String iconFile) {
        this.iconFile = iconFile;
    }

    public Integer getSequence() {
        return this.sequence;
    }

    public void setSequence(Integer sequence) {
        this.sequence = sequence;
    }

    public Date getCreatedOn() {
        return this.createdOn;
    }

    public void setCreatedOn(Date createdOn) {
        this.createdOn = createdOn;
    }

    public Integer getCreatedbyId() {
        return this.createdbyId;
    }

    public void setCreatedbyId(Integer createdbyId) {
        this.createdbyId = createdbyId;
    }

    public Date getUpdatedOn() {
        return this.updatedOn;
    }

    public void setUpdatedOn(Date updatedOn) {
        this.updatedOn = updatedOn;
    }

    public Integer getModifiedbyId() {
        return this.modifiedbyId;
    }

    public void setModifiedbyId(Integer modifiedbyId) {
        this.modifiedbyId = modifiedbyId;
    }

    public short getDeleted() {
        return this.deleted;
    }

    public void setDeleted(short deleted) {
        this.deleted = deleted;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("id", id).
                append("title", title).
                append("shortDescription", shortDescription).
                append("longDescription", longDescription).
                append("pdfLessonPlan", pdfLessonPlan).
                append("studentAssessmentForm", studentAssessmentForm).
                append("activityPlan", activityPlan).
                append("coloringWorksheets", coloringWorksheets).
                append("imageFile", imageFile).
                append("iconFile", iconFile).
                append("sequence", sequence).
                append("createdOn", createdOn).
                append("createdbyId", createdbyId).
                append("updatedOn", updatedOn).
                append("modifiedbyId", modifiedbyId).
                append("deleted", deleted).
                toString();
    }


}


