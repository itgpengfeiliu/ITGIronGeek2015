

package com.cei.kidvisionweb.dao.impl;

import com.cei.kidvisionweb.dao.ModuleDao;
import com.cei.kidvisionweb.db.model.Module;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author Shrikant
 */
public class ModuleDaoImpl extends GenericDaoImpl<Module, Long> implements ModuleDao {
    
	private static Logger logger = LoggerFactory.getLogger(ModuleDaoImpl.class);

//    @Override
//	@SuppressWarnings("unchecked")
//	public Module getModuleAndVideos(int moduleId) {
//    	Module module = null;
//    	try {
//	      	module = getSession().createQuery("from "
//	      			+ getPersistentClass().getName()
//	      			+ " where deleted=0 order by sequence").list();
//		} catch (Exception ex) {
//			logger.error("Error occurred::", ex);
//		}
//		return module;
//    }
    
	@Override
	@SuppressWarnings("unchecked")
	public List<Module> getAllModulesOrderBySequenceAndVideos() {
		List<Module> modules = null;
		try {
//	      	modules = getSession().createQuery("from "
//	      			+ getPersistentClass().getName() + ""
//	      			+ " where deleted=0 order by sequence").list();
        	modules = getSession().createCriteria(Module.class, "m")
        						.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY)
					            .add( Restrictions.eq("m.deleted", (short)0) )
					            .addOrder(Order.asc("m.sequence"))
					            .list();
	      	
	      	// criteria.setFetchMode(“product”, FetchMode.EAGER);
		} catch (Exception ex) {
			logger.error("Error occurred::", ex);
		}
		return modules;
	}
	
	@Override
	@SuppressWarnings("unchecked")
	public List<Module> getAllModulesOrderByTitleAndVideos() {
		List<Module> modules = null;
		try {
        	modules = getSession().createCriteria(Module.class, "m")
        						.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY)
					            .addOrder(Order.asc("m.title"))
					            .list();
		} catch (Exception ex) {
			logger.error("Error occurred::", ex);
		}
		return modules;
	}
    
	// Pengfei Liu backup code PLEASE DO NOT DELETE IT!
//    @Override
//    @SuppressWarnings("unchecked")
//    public List getAllModulesOrderBySequenceAndOverviewVideo() { // Restrictions v.isOverview does not work
//        List modules = null;
//        try {
//        	modules = getSession().createQuery("from "
//        			+ getPersistentClass().getName() + " as m inner join m.videos as v "
//        			+ "where m.deleted=0 and v.isOverview=:isOverview").setParameter("isOverview", (short)1).list();
//        	 
//        	modules = getSession().createCriteria(Module.class, "m")
//								.setFetchMode("m.videos", FetchMode.JOIN)
//        						.createAlias("m.videos", "v")
//					            .add( Restrictions.eq("m.deleted", (short)0) )
//					            .add( Restrictions.eq("v.isOverview", (short)1) )
//					            .addOrder(Order.asc("m.sequence"))
//					            .list();
//        } catch (Exception ex) {
//            logger.error("Error occurred::", ex);
//        }
//        return modules;
//    }
    
    @Override
    @SuppressWarnings("unchecked")
    public List<Module> getAllModulesOrderBySequence() {
        List<Module> modules = null;
        try {
            StringBuffer hql = new StringBuffer("select model from "
                    + getPersistentClass().getName() + " as model where model.deleted = 0 order by model.sequence"
                    );
            modules = getSession().createQuery(hql.toString()).list();
        } catch (Exception ex) {
            logger.error("Error occurred::", ex);
        }
        return modules;
    }
    
    @Override
    @SuppressWarnings("unchecked")
    public Module createModuleFromExistingModule(int userId, int moduleId, String title) {
        try {
        	List<Module> newModules = getSession().getNamedQuery("createModuleFromExistingModule")
    				.setParameter("created_by_id", userId).setParameter("from_module_id", moduleId).setParameter("new_module_title", title).list();
    			
			if (newModules != null && newModules.size() != 0) {
	            return newModules.get(0);
	        } else {
	            return null;
	        }
        } catch (Exception ex) {
            logger.error("Error occurred::", ex);
        }
        return null;
    }
}
