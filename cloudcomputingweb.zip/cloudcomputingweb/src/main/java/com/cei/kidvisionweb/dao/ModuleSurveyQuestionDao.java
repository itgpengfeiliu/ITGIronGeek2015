package com.cei.kidvisionweb.dao;


import com.cei.kidvisionweb.db.model.ModuleSurveyQuestion;

public interface ModuleSurveyQuestionDao extends GenericDao<ModuleSurveyQuestion, Long> {
    
}
