package com.cei.kidvisionweb.dao;

import java.util.List;

import com.cei.kidvisionweb.db.model.User;
import com.cei.kidvisionweb.db.model.UserDatatable;
import com.cei.kidvisionweb.db.model.UsersByCountyState;

/**
 *
 * @author Shrikant
 */

public interface UserDao extends GenericDao<User, Long> {

	String validNewUserEmailandUsername(String email, String username);
	
	List<UserDatatable> getAllUsersPagination(int length, int start, int orderIndex, String order, String search, String configCurrentSchoolYearFrom);
	
	long getAllUsersCount();
	
	List<UsersByCountyState> countUsersByCountyStatePagination(int length, int start, int orderIndex, String order, String search);

	List<UserDatatable> getNewRegistrationUsers(String starttime, String endtime);
}
