package com.cei.kidvisionweb.dao;

import com.cei.kidvisionweb.db.model.SurveyQuestion;

public interface SurveyQuestionDao extends GenericDao<SurveyQuestion, Long> {

}
