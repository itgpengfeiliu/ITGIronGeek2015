package com.cei.kidvisionweb.dao;

import com.cei.kidvisionweb.db.model.SurveyResult;

public interface SurveyResultDao extends GenericDao<SurveyResult, Long> {

}
