package com.cei.kidvisionweb.dao.impl;

import com.cei.kidvisionweb.dao.RoleDao;
import com.cei.kidvisionweb.db.model.Role;
import java.util.List;
import org.hibernate.Query;

/**
 *
 * @author Shrikant
 */
public class RoleDaoImpl extends GenericDaoImpl<Role, Long> implements RoleDao{
	
    @Override
    public void deleteById(String id) {
        StringBuffer hql = new StringBuffer(
                "delete from "
                + getPersistentClass().getName() + " as model where id="
                + id);
        Query query = getSession().createQuery(hql.toString());
        query.executeUpdate();
    }
    
    @Override
    @SuppressWarnings("unchecked")
    public List<Role> getRoles() {
        List<Role> roleLst = null;
        try {
            StringBuffer hql = new StringBuffer("select model from "
                    + getPersistentClass().getName() + " as model"
            );
            roleLst = getSession().createQuery(hql.toString()).list();
        } catch (Exception ex) {
            logger.error("Error occurred::", ex);
        }
        return roleLst;
    }
}
