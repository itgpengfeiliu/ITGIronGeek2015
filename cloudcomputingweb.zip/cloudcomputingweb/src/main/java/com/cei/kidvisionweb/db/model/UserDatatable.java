package com.cei.kidvisionweb.db.model;

import java.util.Date;

import org.apache.commons.lang3.builder.ToStringBuilder;

public class UserDatatable implements java.io.Serializable {

	private Integer id;
    private String firstName;
    private String lastName;
    private String userName;
    private String password;
    private String email;
    private byte roleId;
    private short isActive;
    private Date lastLogon;
    private String schoolName;
    //private Integer currentRegistrationId;
    private String cardNumber;
    private Short isPaid;
    private static final long serialVersionUID = 1L;

    public static long getSerialversionuid() {
        return serialVersionUID;
    }

    public UserDatatable() {
    }

    public Integer getId() {
        return this.id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getFirstName() {
        return this.firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return this.lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getUserName() {
        return this.userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPassword() {
        return this.password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getEmail() {
        return this.email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public byte getRoleId() {
        return this.roleId;
    }

    public void setRoleId(byte roleId) {
        this.roleId = roleId;
    }

	public short getIsActive() {
        return this.isActive;
    }

    public void setIsActive(short isActive) {
        this.isActive = isActive;
    }
    
	public Date getLastLogon() {
		return lastLogon;
	}

	public void setLastLogon(Date lastLogon) {
		this.lastLogon = lastLogon;
	}

	public String getSchoolName() {
		return schoolName;
	}

	public void setSchoolName(String schoolName) {
		this.schoolName = schoolName;
	}
	
//	public Integer getCurrentRegistrationId() {
//		return currentRegistrationId;
//	}
//
//	public void setCurrentRegistrationId(Integer currentRegistrationId) {
//		this.currentRegistrationId = currentRegistrationId;
//	}

	public String getCardNumber() {
		return cardNumber;
	}

	public void setCardNumber(String cardNumber) {
		this.cardNumber = cardNumber;
	}

	public Short getIsPaid() {
		return isPaid;
	}

	public void setIsPaid(Short isPaid) {
		this.isPaid = isPaid;
	}

	@Override
    public String toString() {
        return new ToStringBuilder(this).append("id", id).
                append("firstName", firstName).
                append("lastName", lastName).
                append("userName", userName).
                append("password", password).
                append("email", email).
                append("roleId", Integer.toString(roleId)).
                append("isActive", isActive).
                append("roleId", roleId).
                append("lastLogon", lastLogon).
                append("schoolName", schoolName).
                append("cardNumber", cardNumber).
                append("isPaid", isPaid).
                toString();
    }
}


