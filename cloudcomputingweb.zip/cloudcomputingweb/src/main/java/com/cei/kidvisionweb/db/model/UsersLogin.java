package com.cei.kidvisionweb.db.model;


import java.util.Date;

import org.apache.commons.lang3.builder.ToStringBuilder;

public class UsersLogin implements java.io.Serializable {

	private Integer id;
    private Integer userId;
    private Date loginOn;

    private static final long serialVersionUID = 1L;

    public static long getSerialversionuid() {
        return serialVersionUID;
    }

    public UsersLogin() {
    }

    public UsersLogin(Integer userId, Date loginOn) {
        this.userId = userId;
        this.loginOn = loginOn;
    }

    public Integer getId() {
        return this.id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    
	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	public Date getLoginOn() {
		return loginOn;
	}

	public void setLoginOn(Date loginOn) {
		this.loginOn = loginOn;
	}

	@Override
    public String toString() {
        return new ToStringBuilder(this).append("id", id).
                append("userId", userId).
                append("loginOn", loginOn).
                toString();
    }
}


