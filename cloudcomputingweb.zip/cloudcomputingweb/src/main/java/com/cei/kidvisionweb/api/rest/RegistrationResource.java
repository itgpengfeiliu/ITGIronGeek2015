package com.cei.kidvisionweb.api.rest;

import java.util.Date;

import javax.ws.rs.Consumes;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.access.AccessDeniedException;

import com.cei.kidvisionweb.config.KidvisionWebConfig;
import com.cei.kidvisionweb.db.model.Address;
import com.cei.kidvisionweb.db.model.AuthenticationUserAnswer;
import com.cei.kidvisionweb.db.model.Config;
import com.cei.kidvisionweb.db.model.Registration;
import com.cei.kidvisionweb.db.model.User;
import com.cei.kidvisionweb.service.UserLoginService;
import com.cei.kidvisionweb.service.UserService;
import com.cei.kidvisionweb.service.util.EmailService;
import com.cei.kidvisionweb.service.util.RegularExpressionUtil;
import com.sun.jersey.api.core.InjectParam;


@Path("/registration")
public class RegistrationResource {

	private static Logger logger = LoggerFactory.getLogger(RegistrationResource.class);
	
	@InjectParam
    private UserLoginService userLoginService;
	
    @InjectParam
    private UserService userService;
    
    @InjectParam
    private EmailService emailService;
    
	public RegistrationResource() {
	}
	
	@Path("/register")
    @POST
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	@Produces(MediaType.TEXT_HTML)
    public Response registration(
    		@DefaultValue("") @FormParam("prefix") String prefix,
    		@DefaultValue("") @FormParam("firstName") String firstName,
    		@DefaultValue("") @FormParam("middleName") String middleName,
    		@DefaultValue("") @FormParam("lastName") String lastName,
    		@DefaultValue("") @FormParam("educationLevel") String educationLevel,
    		@DefaultValue("") @FormParam("email") String email,
    		@DefaultValue("") @FormParam("userName") String userName,
    		@DefaultValue("") @FormParam("password") String password,
    		@DefaultValue("6") @FormParam("occupationalTitleId") int occupationalTitleId,
    		@DefaultValue("") @FormParam("otherOccupationalTitle") String otherOccupationalTitle,
    		@DefaultValue("1") @FormParam("registrationtypeId") byte registrationtypeId,
    		@DefaultValue("") @FormParam("phone") String phone,
    		//@DefaultValue("Public") @FormParam("facilityType") String facilityType,
    		@DefaultValue("") @FormParam("schoolName") String schoolName,
    		@DefaultValue("") @FormParam("streetAddress") String streetAddress,
    		@DefaultValue("") @FormParam("city") String city,
    		@DefaultValue("") @FormParam("state") String state,
    		@DefaultValue("") @FormParam("county") String county,
    		@DefaultValue("") @FormParam("country") String country,
    		@DefaultValue("") @FormParam("zipCode") String zipCode,
    		@DefaultValue("1") @FormParam("recovery1") int recovery1,
    		@DefaultValue("1") @FormParam("recovery2") int recovery2,
    		@DefaultValue("") @FormParam("answer1") String answer1,
    		@DefaultValue("") @FormParam("answer2") String answer2,
    		@DefaultValue("true") @FormParam("emailNotification") boolean emailNotification) {
    	
    	try {
    		// valid unique email and username
    		
        	if ( !RegularExpressionUtil.checkEmailPattern(email) ) {
        		return Response.status(Response.Status.BAD_REQUEST).entity("email pattern").build();
        	}
        	
        	if ( !RegularExpressionUtil.checkUsernamePattern(userName) ) {
        		return Response.status(Response.Status.BAD_REQUEST).entity("username pattern").build();
        	}
        	
        	if ( !RegularExpressionUtil.checkPasswordPattern(password) ) {
        		return Response.status(Response.Status.BAD_REQUEST).entity("password pattern").build();
        	}
        	
    		String isInUse = userService.validNewUserEmailandUsername(email, userName);
    		
    		if (isInUse.equalsIgnoreCase("email duplicate")) {
    			return Response.status(Response.Status.BAD_REQUEST).entity("email duplicate").build();
    		}
    		else if (isInUse.equalsIgnoreCase("username duplicate")) {
    			return Response.status(Response.Status.BAD_REQUEST).entity("username duplicate").build();
    		} 
    		else if (isInUse.equalsIgnoreCase("false")) {
    			return Response.status(Response.Status.BAD_REQUEST).entity("Error occurred:").build();
    		}
    		
    		Date date = new Date();
    		
    		Integer addressId = null;
    		if (streetAddress != "" || city != "" || county != "" || state != "" || country != "" || zipCode != "") {
    			Address address = new Address();
        		address.setStreetAddress(streetAddress);
        		address.setCity(city);
        		address.setCounty(county);
        		address.setState(state);
        		address.setCountry(country);
        		address.setZipCode(zipCode);
        		addressId = userService.addAddress(address);
    		}
    		
    		
            User user = new User();
            user.setPrefix(prefix);
            user.setFirstName(firstName.trim());
            user.setLastName(lastName.trim());
            user.setMiddleName(middleName.trim());
            user.setEmail(email.trim());
            user.setUserName(userName.trim());
            user.setPassword(password);
            user.setIsActive((short)1);
            user.setRoleId((byte)2); // User
            user.setSchoolName(schoolName);
            user.setPasswordReset((short)0);
            
            if (occupationalTitleId == 6) {
            	user.setOtherOccupationalTitle(otherOccupationalTitle);
            } 
            user.setOccupationalTitleId(occupationalTitleId);
            user.setRegistrationtypeId(registrationtypeId);
            user.setPhone(phone);
            //user.setFacilityType(facilityType);
            user.setEmailNotification(emailNotification);
            user.setPretestCompleted((byte)0);
            user.setCreatedOn(date);
            user.setUpdatedOn(date);
            
            if (addressId != null) {
            	user.setPrimaryAddressId(addressId);
            }
            //Integer billingAddressId = null;
    		//Integer shippingAddressId = null;
    		//Integer primaryAddressId = null;

            logger.debug("before add user = " + user.toString());  // user.getUpdatedbyId() null
            Integer newUserId = userService.addUser(user);
            logger.debug("after new user id = " + newUserId.toString());
            
            String accountType = "Standard Registration"; // either Standard Registration or Teachers Association Membership
            if (registrationtypeId == 2) {
            	accountType = "Teachers Association Membership";
            }
            try {
            	logger.debug("REGISTRATION_WELCOME_EMAIL_SUBJECT = " + emailService.REGISTRATION_WELCOME_EMAIL_SUBJECT);
            	 emailService.sendEmail(emailService.REGISTRATION_WELCOME_EMAIL_SUBJECT, 
					KidvisionWebConfig.REGISTRATION_WELCOME_EMAIL_TEXT(user.getFirstName(), user.getUserName(), accountType), email);
            } catch (Exception ex) {
                logger.error("Error occurred:: ", ex);
            }
            
            if (newUserId != null) {
            	if (registrationtypeId == 2) {
            		Config config = userService.getConfig();
            		
            		Registration registration = new Registration();
            		registration.setUserId(newUserId);
            		registration.setCreatedonDatetime(date);
            		registration.setIsActive(true);
            		registration.setFromDatetime(config.getCurrentSchoolYearFrom());
            		registration.setToDatetime(config.getCurrentSchoolYearTo());
            		Integer registrationId = userService.addRegistration(registration);
            		
            		userService.updateRegistration(newUserId, registrationId);
            	}
            	
        		AuthenticationUserAnswer authenUserAnswer1 = new AuthenticationUserAnswer();
        		authenUserAnswer1.setAnswer(answer1);
        		authenUserAnswer1.setAuthenticationQuestionId(recovery1);
        		authenUserAnswer1.setUserId(newUserId);
        		authenUserAnswer1.setCreatedOn(date);
        		authenUserAnswer1.setUpdatedOn(date);
        		userService.addAuthenticationUserAnswer(authenUserAnswer1);
        		
        		AuthenticationUserAnswer authenUserAnswer2 = new AuthenticationUserAnswer();
        		authenUserAnswer2.setAnswer(answer2);
        		authenUserAnswer2.setAuthenticationQuestionId(recovery2);
        		authenUserAnswer2.setUserId(newUserId);
        		authenUserAnswer2.setCreatedOn(date);
        		authenUserAnswer2.setUpdatedOn(date);
        		userService.addAuthenticationUserAnswer(authenUserAnswer2);
        		
        	    if ( userLoginService.login(userName, password) ) {
        		//if (userLoginService.login(newUserId)) {
        			return Response.ok().entity("islogin").build();
        		}
            }
            return Response.ok().entity("tologin").build();
        } catch (Exception ex) {
            logger.error("Error occurred:: ", ex);
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("Error occurred:").build();
        }
    }
	
	
    @Path("/checkusername")
    @POST
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    @Produces(MediaType.TEXT_HTML)
    public Response checkUserName(@FormParam("username") final String username) {
    	try {
    		String output = "false";
    		logger.debug("checkUserName param username = " + username);
    		
        	if ( !RegularExpressionUtil.checkUsernamePattern(username) ) {
        		output = "username pattern";
        	}
        	else {
	        	output = userService.checkUserName(username);
        	}
        	return Response.ok(output, MediaType.TEXT_HTML).build();
    	} catch (Exception ex) {
    		logger.error("Error occurred::", ex);
    		return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("Error occurred:").build();
    	} 
    }
	
    @Path("/checkemail")
    @POST
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    @Produces(MediaType.TEXT_HTML)
    public Response checkEmail(@FormParam("email") final String email) {
    	try {
    		String output = "false";
    		logger.debug("checkEmail param email= " + email);
        	
    		if ( !RegularExpressionUtil.checkEmailPattern(email) ) {
    			output = "email pattern";
        	}
    		else {
    			output = userService.checkEmail(email);
    		}
    		return Response.ok(output, MediaType.TEXT_HTML).build();
    	} catch (Exception ex) {
    		logger.error("Error occurred::", ex);
    		 return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("Error occurred:").build();
    	}
    }
    
    @Path("/getPasswordRecoveryQuestions")
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response getPasswordRecoveryQuestions() {
    	try {
    		String output = userService.getPasswordRecoveryQuestions();
    		logger.debug("getPasswordRecoveryQuestions : " + output);
    		return Response.ok(output, MediaType.APPLICATION_JSON).build();
    	} catch (Exception ex) {
    		logger.error("Error occurred::", ex);
    		 return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("Error occurred:").build();
    	}
    }
    
    @Path("/getoccupationaltitles")
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response getOccupationalTitles() {
        try {
        	String result = userService.getOccupationalTitles();
	   		return Response.ok(result, MediaType.APPLICATION_JSON).build();
	    } catch (AccessDeniedException ex) {
	    	logger.error("Error occurred::", ex);
	    	return Response.status(Response.Status.FORBIDDEN).entity("").build();
	    } catch (Exception ex) {
	        logger.error("Error occurred:: ", ex);
	        return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("").build();
	    }
    }
    
    @Path("/getprocesspayment")
    @GET
    @Produces(MediaType.TEXT_HTML)
    public Response getProcessPayment() {
        try {
        	int processPayment = userService.getProcessPayment();
        	
	   		return Response.ok("" + processPayment, MediaType.TEXT_HTML).build();
	    } catch (AccessDeniedException ex) {
	    	logger.error("Error occurred::", ex);
	    	return Response.status(Response.Status.FORBIDDEN).entity("").build();
	    } catch (Exception ex) {
	        logger.error("Error occurred:: ", ex);
	        return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("").build();
	    }
    }
}
