package com.cei.kidvisionweb.dao;

import com.cei.kidvisionweb.db.model.UserPretestAnswer;

/**
 *
 * @author Shrikant
 */
public interface UserPretestAnswerDao extends GenericDao<UserPretestAnswer, Long> {

//    void add(UserPretestAnswer object);
//
//    void update(UserPretestAnswer object);
//
//    void delete(UserPretestAnswer object);

    void deleteById(String id);
}
