package com.cei.kidvisionweb.db.model;

import org.apache.commons.lang3.builder.ToStringBuilder;

/**
 *
 * @author Shrikant
 */
public class Role implements java.io.Serializable {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	private Integer id;
    private String roleName;

    public Role() {
    }

    public Role(Integer id) {
        this.id = id;
    }

    public Role(Integer id, String roleName) {
        this.id = id;
        this.roleName = roleName;
    }

    public Integer getId() {
        return this.id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getRoleName() {
        return this.roleName;
    }

    public void setRoleName(String roleName) {
        this.roleName = roleName;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("id", id).
                append("roleName", roleName).
                toString();
    }

}
