package com.cei.kidvisionweb.dao.impl;

import com.cei.kidvisionweb.dao.SponsorDao;
import com.cei.kidvisionweb.db.model.Sponsor;

public class SponsorDaoImpl extends GenericDaoImpl<Sponsor, Long> implements SponsorDao {

}
