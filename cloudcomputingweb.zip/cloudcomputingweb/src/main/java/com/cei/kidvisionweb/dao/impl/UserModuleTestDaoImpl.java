

package com.cei.kidvisionweb.dao.impl;

import java.util.Calendar;
import java.util.List;

import org.hibernate.transform.Transformers;

import com.cei.kidvisionweb.dao.UserModuleTestDao;
import com.cei.kidvisionweb.db.model.UserModuleTest;
import com.cei.kidvisionweb.db.model.UserModuleTestTranscriptDetail;
import com.cei.kidvisionweb.db.model.UserModuleTestTranscriptTitle;


public class UserModuleTestDaoImpl extends GenericDaoImpl<UserModuleTest, Long> implements UserModuleTestDao{

	@Override
    @SuppressWarnings("unchecked")
    public List<UserModuleTestTranscriptDetail> getTranscriptDetails(int userId, int testYear) {
		List<UserModuleTestTranscriptDetail> transcriptDetails = null;
        try {
        	transcriptDetails = getSession().getNamedQuery("getTranscriptDetails")
    				.setParameter("userId", userId).setParameter("testYear", testYear)
    				.setResultTransformer(Transformers.aliasToBean(UserModuleTestTranscriptDetail.class)).list();
        } catch (Exception ex) {
            logger.error("Error occurred::", ex);
        }
        return transcriptDetails;
    }
	
	@Override
    @SuppressWarnings("unchecked")
    public List<UserModuleTestTranscriptTitle> getTranscriptTitles(int userId) {
		List<UserModuleTestTranscriptTitle> transcriptTitles = null;
        try {
        	transcriptTitles = getSession().getNamedQuery("getTranscriptTitles")
    				.setParameter("userId", userId)
    				.setResultTransformer(Transformers.aliasToBean(UserModuleTestTranscriptTitle.class))
    				.list();
        } catch (Exception ex) {
            logger.error("Error occurred::", ex);
        }
        return transcriptTitles;
    }
	
	@Override
	@SuppressWarnings("unchecked")
	public List<UserModuleTest> getUserModuleTests(int userId, int moduleId) {
	  	List<UserModuleTest> tests = null;
	  	try {
	  		Calendar now = Calendar.getInstance();
	  		int month = now.get(Calendar.MONTH)+1;
	  		int year = now.get(Calendar.YEAR);
	  		if (month <= 6) {
	  			year = year - 1;
	  		}
	  		String sql = "select id, user_id as userId, module_id as moduleId, is_completed as isCompleted, "
	      			+ " is_passed as isPassed, correct_answers_count as correctAnswersCount, total_question_count as totalQuestionCount, "
	  				+ " started_on as startedOn, completed_on as completedOn from user_module_test "
	      			+ " where user_id=" + userId + " and module_id= " + moduleId + " and date(started_on) > date('" + year + "-06-30') ;";
	      	tests = getSession().createSQLQuery(sql).setResultTransformer(Transformers.aliasToBean(UserModuleTest.class)).list();
		} catch (Exception ex) {
			logger.error("Error occurred::", ex);
		}
		return tests;
	 }
}
