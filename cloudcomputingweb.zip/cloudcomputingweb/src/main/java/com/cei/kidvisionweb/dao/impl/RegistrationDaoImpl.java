

package com.cei.kidvisionweb.dao.impl;

import java.util.Date;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import com.cei.kidvisionweb.dao.RegistrationDao;
import com.cei.kidvisionweb.db.model.Registration;

public class RegistrationDaoImpl extends GenericDaoImpl<Registration, Long> implements RegistrationDao{
	
	@Override
	@SuppressWarnings("unchecked")
    public Registration getRegistrationByConfig(int userId, Date fromDate) {
    	try {
    		List<Registration> registrations = getSession().createCriteria(Registration.class)
					.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY)
					.add( Restrictions.eq("userId", userId) )
		            .add( Restrictions.eq("fromDatetime", fromDate) )
		            .addOrder(Order.desc("fromDatetime"))
		            .list();
    		
    		if (registrations != null && registrations.size() != 0) {
	            return registrations.get(0);
	        } else {
	            return null;
	        }
    		
		} catch (Exception ex) {
			logger.error("Error occurred::", ex);
		}
		return null;
    }
	
	@Override
	@SuppressWarnings("unchecked")
    public Registration getUserRegistration(int userId) {
    	try {
    		List<Registration> registrations = getSession().createCriteria(Registration.class)
					.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY)
					.add( Restrictions.eq("userId", userId) )
		            .addOrder(Order.desc("fromDatetime"))
		            .list();
    		
    		if (registrations != null && registrations.size() != 0) {
	            return registrations.get(0);
	        } else {
	            return null;
	        }
    		
		} catch (Exception ex) {
			logger.error("Error occurred::", ex);
		}
		return null;
    }
	
	@Override
	@SuppressWarnings("unchecked")
    public List<Registration> getUserPaidRegistrations(int userId) {
    	try {
    		List<Registration> registrations = getSession().createCriteria(Registration.class)
					.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY)
					.add( Restrictions.eq("userId", userId) )
					.add( Restrictions.eq("isPaid", (short)1) )
		            .addOrder(Order.desc("fromDatetime"))
		            .list();
    		
    		if (registrations != null && registrations.size() != 0) {
	            return registrations;
	        } else {
	            return null;
	        }
    		
		} catch (Exception ex) {
			logger.error("Error occurred::", ex);
		}
		return null;
    }
}
