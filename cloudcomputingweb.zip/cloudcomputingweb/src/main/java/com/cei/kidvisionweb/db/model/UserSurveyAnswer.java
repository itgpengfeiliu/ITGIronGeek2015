package com.cei.kidvisionweb.db.model;

import java.util.Date;

import org.apache.commons.lang3.builder.ToStringBuilder;

public class UserSurveyAnswer implements java.io.Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private Integer id;
    private Integer userId;
    private Integer moduleId;
    private Integer surveyQuestionId;
    private byte surveyAnswerYesNo;
    private Date createdOn;
    
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getUserId() {
		return userId;
	}
	public void setUserId(Integer userId) {
		this.userId = userId;
	}
	public Integer getSurveyQuestionId() {
		return surveyQuestionId;
	}
	public void setSurveyQuestionId(Integer surveyQuestionId) {
		this.surveyQuestionId = surveyQuestionId;
	}
	public byte getSurveyAnswerYesNo() {
		return surveyAnswerYesNo;
	}
	public void setSurveyAnswerYesNo(byte surveyAnswerYesNo) {
		this.surveyAnswerYesNo = surveyAnswerYesNo;
	}
	public Date getCreatedOn() {
		return createdOn;
	}
	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public Integer getModuleId() {
		return moduleId;
	}
	public void setModuleId(Integer moduleId) {
		this.moduleId = moduleId;
	}
	@Override
    public String toString() {
        return new ToStringBuilder(this).append("id", id).
                append("userId", userId).
                append("moduleId", moduleId).
                append("surveyQuestionId", surveyQuestionId).
                append("surveyAnswerYesNo", surveyAnswerYesNo).
                append("createdOn", createdOn).
                toString();
    }
	
}
