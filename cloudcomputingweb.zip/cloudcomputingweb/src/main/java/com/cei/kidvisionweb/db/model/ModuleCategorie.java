package com.cei.kidvisionweb.db.model;

import org.apache.commons.lang3.builder.ToStringBuilder;

public class ModuleCategorie  implements java.io.Serializable {

     /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private Integer id;
    private Integer moduleId;
    private Integer categoryId;
    private Byte deleted;

    public ModuleCategorie() {
    }

    public ModuleCategorie(Integer moduleId, Integer categoryId, Byte deleted) {
       this.moduleId = moduleId;
       this.categoryId = categoryId;
       this.deleted = deleted;
    }
   
    public Integer getId() {
        return this.id;
    }
    
    public void setId(Integer id) {
        this.id = id;
    }
    public Integer getModuleId() {
        return this.moduleId;
    }
    
    public void setModuleId(Integer moduleId) {
        this.moduleId = moduleId;
    }
    public Integer getCategoryId() {
        return this.categoryId;
    }
    
    public void setCategoryId(Integer categoryId) {
        this.categoryId = categoryId;
    }
    public Byte getDeleted() {
        return this.deleted;
    }
    
    public void setDeleted(Byte deleted) {
        this.deleted = deleted;
    }


    @Override
    public String toString() {
        return new ToStringBuilder(this).append("id", id).
                append("moduleId", moduleId).
                append("categoryId", categoryId).
                append("deleted", deleted).
                toString();
    }

}


