package com.cei.kidvisionweb.dao.impl;

import com.cei.kidvisionweb.dao.SurveyQuestionDao;
import com.cei.kidvisionweb.db.model.SurveyQuestion;

public class SurveyQuestionDaoImpl extends GenericDaoImpl<SurveyQuestion, Long> implements SurveyQuestionDao {

}
