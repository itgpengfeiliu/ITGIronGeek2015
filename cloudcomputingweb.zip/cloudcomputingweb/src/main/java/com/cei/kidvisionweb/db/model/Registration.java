package com.cei.kidvisionweb.db.model;



import java.util.Date;
import org.apache.commons.lang3.builder.ToStringBuilder;

public class Registration  implements java.io.Serializable {

    private Integer id;
    private Integer userId;
    private Byte orderDvd;
    private Date fromDatetime;
    private Date toDatetime;
    private Date createdonDatetime;
    private Integer createdbyId;
    private Date modifiedonDatetime;
    private Integer modifiedbyId;
    private Boolean isActive;
    private String cardFullName;
    private String cardLastFour;
    private String cardExp;
    private String sagePaymentOrderNumber;
    private String sagePaymentReference;
    private short isPaid; // 0 unpaid, 1 paid, 2 ..?
    private Date sagePaymentDatetime;

    private static final long serialVersionUID = 1L;

    public static long getSerialversionuid() {
        return serialVersionUID;
    }

    public Registration() {
    }

    public Registration(Integer userId, Byte orderDvd, Date fromDatetime, Date toDatetime, Date createdonDatetime, Integer createdbyId, Date modifiedonDatetime, Integer modifiedbyId, Boolean isActive) {
        this.userId = userId;
        this.orderDvd = orderDvd;
        this.fromDatetime = fromDatetime;
        this.toDatetime = toDatetime;
        this.createdonDatetime = createdonDatetime;
        this.createdbyId = createdbyId;
        this.modifiedonDatetime = modifiedonDatetime;
        this.modifiedbyId = modifiedbyId;
        this.isActive = isActive;
    }

    public Integer getId() {
        return this.id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getUserId() {
        return this.userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public Byte getOrderDvd() {
        return this.orderDvd;
    }

    public void setOrderDvd(Byte orderDvd) {
        this.orderDvd = orderDvd;
    }

    public Date getFromDatetime() {
        return this.fromDatetime;
    }

    public void setFromDatetime(Date fromDatetime) {
        this.fromDatetime = fromDatetime;
    }

    public Date getToDatetime() {
        return this.toDatetime;
    }

    public void setToDatetime(Date toDatetime) {
        this.toDatetime = toDatetime;
    }

    public Date getCreatedonDatetime() {
        return this.createdonDatetime;
    }

    public void setCreatedonDatetime(Date createdonDatetime) {
        this.createdonDatetime = createdonDatetime;
    }

    public Integer getCreatedbyId() {
        return this.createdbyId;
    }

    public void setCreatedbyId(Integer createdbyId) {
        this.createdbyId = createdbyId;
    }

    public Date getModifiedonDatetime() {
        return this.modifiedonDatetime;
    }

    public void setModifiedonDatetime(Date modifiedonDatetime) {
        this.modifiedonDatetime = modifiedonDatetime;
    }

    public Integer getModifiedbyId() {
        return this.modifiedbyId;
    }

    public void setModifiedbyId(Integer modifiedbyId) {
        this.modifiedbyId = modifiedbyId;
    }

    public Boolean getIsActive() {
        return this.isActive;
    }

    public void setIsActive(Boolean isActive) {
        this.isActive = isActive;
    }
      
    public short getIsPaid() {
		return isPaid;
	}

	public void setIsPaid(short isPaid) {
		this.isPaid = isPaid;
	}
		
	public String getCardFullName() {
		return cardFullName;
	}

	public void setCardFullName(String cardFullName) {
		this.cardFullName = cardFullName;
	}

	public String getCardLastFour() {
		return cardLastFour;
	}

	public void setCardLastFour(String cardLastFour) {
		this.cardLastFour = cardLastFour;
	}

	public String getCardExp() {
		return cardExp;
	}

	public void setCardExp(String cardExp) {
		this.cardExp = cardExp;
	}

	public String getSagePaymentOrderNumber() {
		return sagePaymentOrderNumber;
	}

	public void setSagePaymentOrderNumber(String sagePaymentOrderNumber) {
		this.sagePaymentOrderNumber = sagePaymentOrderNumber;
	}

	public String getSagePaymentReference() {
		return sagePaymentReference;
	}

	public void setSagePaymentReference(String sagePaymentReference) {
		this.sagePaymentReference = sagePaymentReference;
	}

	public Date getSagePaymentDatetime() {
		return sagePaymentDatetime;
	}

	public void setSagePaymentDatetime(Date sagePaymentDatetime) {
		this.sagePaymentDatetime = sagePaymentDatetime;
	}

	@Override
    public String toString() {
        return new ToStringBuilder(this).append("id", id).
                append("userId", userId).
                append("orderDvd", orderDvd).
                append("fromDatetime", fromDatetime).
                append("toDatetime", toDatetime).
                append("createdonDatetime", createdonDatetime).
                append("createdbyId", createdbyId).
                append("modifiedonDatetime", modifiedonDatetime).
                append("modifiedbyId", modifiedbyId).
                append("isActive", isActive).
                append("isPaid", isPaid).
                append("cardFullName", cardFullName).
                append("cardLastFour", cardFullName).
                append("cardExp", cardFullName).
                append("sagePaymentOrderNumber", sagePaymentOrderNumber).
                append("sagePaymentReference", sagePaymentOrderNumber).
                append("sagePaymentDatetime", sagePaymentDatetime).
                toString();
    }


}


