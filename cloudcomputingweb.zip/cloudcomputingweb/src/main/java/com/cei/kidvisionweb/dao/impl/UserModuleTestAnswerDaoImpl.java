

package com.cei.kidvisionweb.dao.impl;

import com.cei.kidvisionweb.dao.UserModuleTestAnswerDao;
import com.cei.kidvisionweb.db.model.UserModuleTestAnswer;

/**
 *
 * @author Shrikant
 */
public class UserModuleTestAnswerDaoImpl extends GenericDaoImpl<UserModuleTestAnswer, Long> implements UserModuleTestAnswerDao{
    
}
