package com.cei.kidvisionweb.dao;

import com.cei.kidvisionweb.db.model.ModuleCategorie;

public interface ModuleCategoryDao extends GenericDao<ModuleCategorie, Long> {

}
