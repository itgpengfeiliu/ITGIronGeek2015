package com.cei.kidvisionweb.dao;

import com.cei.kidvisionweb.db.model.ResourceType;

public interface ResourceTypeDao extends GenericDao<ResourceType, Long> {

}
