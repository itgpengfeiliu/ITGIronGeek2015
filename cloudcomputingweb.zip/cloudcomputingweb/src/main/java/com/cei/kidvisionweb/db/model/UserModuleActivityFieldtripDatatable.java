package com.cei.kidvisionweb.db.model;

import java.util.Date;

import org.apache.commons.lang3.builder.ToStringBuilder;

public class UserModuleActivityFieldtripDatatable implements java.io.Serializable {

	private Integer id;
	private Integer userId;
    private Integer moduleId;
    private String title;
    private String activityType;
    private byte isCompleted;
    private Date startDatetime;
    private Date endDatetime;
    
    private String firstName;
    private String lastName;
    private String email;
    private short isActive;
    private String schoolName;
    private String phone;
    private Integer primaryAddressId;
    
    private String streetAddress;
    private String country;
    private String state;
    private String city;
    private String zipCode;
	private String county;
    private static final long serialVersionUID = 1L;

    public static long getSerialversionuid() {
        return serialVersionUID;
    }

    public UserModuleActivityFieldtripDatatable() {
    }  
    
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	public Integer getModuleId() {
		return moduleId;
	}

	public void setModuleId(Integer moduleId) {
		this.moduleId = moduleId;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getActivityType() {
		return activityType;
	}

	public void setActivityType(String activityType) {
		this.activityType = activityType;
	}

	public byte getIsCompleted() {
		return isCompleted;
	}

	public void setIsCompleted(byte isCompleted) {
		this.isCompleted = isCompleted;
	}

	public Date getStartDatetime() {
		return startDatetime;
	}

	public void setStartDatetime(Date startDatetime) {
		this.startDatetime = startDatetime;
	}

	public Date getEndDatetime() {
		return endDatetime;
	}

	public void setEndDatetime(Date endDatetime) {
		this.endDatetime = endDatetime;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public short getIsActive() {
		return isActive;
	}

	public void setIsActive(short isActive) {
		this.isActive = isActive;
	}

	public String getSchoolName() {
		return schoolName;
	}

	public void setSchoolName(String schoolName) {
		this.schoolName = schoolName;
	}

	public String getStreetAddress() {
		return streetAddress;
	}

	public void setStreetAddress(String streetAddress) {
		this.streetAddress = streetAddress;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getZipCode() {
		return zipCode;
	}

	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}

	public String getCounty() {
		return county;
	}

	public void setCounty(String county) {
		this.county = county;
	}
	
	public Integer getPrimaryAddressId() {
		return primaryAddressId;
	}

	public void setPrimaryAddressId(Integer primaryAddressId) {
		this.primaryAddressId = primaryAddressId;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	@Override
    public String toString() {
        return new ToStringBuilder(this).append("id", id).
        		append("userId", userId).
        		append("moduleId", moduleId).
        		append("title", title).
        		append("activityType", activityType).
        		append("isCompleted", isCompleted).
        		append("startDatetime", startDatetime).
        		append("endDatetime", endDatetime).
                append("firstName", firstName).
                append("lastName", lastName).
                append("email", email).
                append("isActive", isActive).
                append("schoolName", schoolName).
                append("primaryAddressId", primaryAddressId).
                append("streetAddress", streetAddress).
                append("state", state).
                append("city", city).
                append("zipCode", zipCode).
                append("county", county).
                append("country", country).
                append("phone", phone).
                toString();
    }
}


