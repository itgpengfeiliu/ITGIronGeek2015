

package com.cei.kidvisionweb.dao.impl;

import java.util.List;
import com.cei.kidvisionweb.dao.QuestionDao;
import com.cei.kidvisionweb.db.model.Question;
import org.hibernate.Criteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author Shrikant
 */
public class QuestionDaoImpl extends GenericDaoImpl<Question, Long> implements QuestionDao{
    
	private static Logger logger = LoggerFactory.getLogger(QuestionDaoImpl.class);
    
    @Override
	@SuppressWarnings("unchecked")
	public List<Question> getQuestionsAndAnswersByModule(int moduleId) {
		List<Question> questions = null;
		try {
//			questions = getSession().createQuery("from "
//	      			+ getPersistentClass().getName()
//	      			+ " where moduleId=" + moduleId + " order by sequence").list();
			questions = getSession().createCriteria(Question.class, "q")
					.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY)
		            .add( Restrictions.eq("q.moduleId", moduleId) )
		            .add(Restrictions.sqlRestriction("deleted=0"))
		            .addOrder(Order.asc("q.sequence"))
		            .list();
		} catch (Exception ex) {
			logger.error("Error occurred::", ex);
		}
		return questions;
	}
    
    @Override
	@SuppressWarnings("unchecked")
	public List<Question> getRandomQuestionsAndAnswers(int count) {
    	if (count > 20) {
    		count = 4;
    	}
		List<Question> questions = null;
		try {
			//questions = getSession().createQuery("from "
			//				+ getPersistentClass().getName()
			//				+ " where deleted=0 order by rand()").setMaxResults(count).list();
			questions = getSession().createCriteria(Question.class)
						.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY)
			            .add(Restrictions.sqlRestriction("deleted=0 order by rand()"))
			            .list().subList(0, count); 
						//.add(Restrictions.eq("q.deleted", (short)0))
		} catch (Exception ex) {
			logger.error("Error occurred::", ex);
		}
		return questions;
	}
}
