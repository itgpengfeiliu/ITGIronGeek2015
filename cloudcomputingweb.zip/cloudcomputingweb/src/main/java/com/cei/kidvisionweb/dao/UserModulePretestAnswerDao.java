package com.cei.kidvisionweb.dao;

import com.cei.kidvisionweb.db.model.UserModulePretestAnswer;

/**
 *
 * @author Shrikant
 */
public interface UserModulePretestAnswerDao extends GenericDao<UserModulePretestAnswer, Long> {
	
}
