package com.cei.kidvisionweb.dao.impl;

import com.cei.kidvisionweb.dao.ResourceTypeDao;
import com.cei.kidvisionweb.db.model.ResourceType;

public class ResourceTypeDaoImpl extends GenericDaoImpl<ResourceType, Long> implements ResourceTypeDao {

}
