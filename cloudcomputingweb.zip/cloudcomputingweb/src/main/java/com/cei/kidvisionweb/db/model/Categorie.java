package com.cei.kidvisionweb.db.model;


import java.util.Date;

import org.apache.commons.lang3.builder.ToStringBuilder;

public class Categorie  implements java.io.Serializable {

     /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private Integer id;
    private String category;
    private Date createdOn;
    private Byte deleted;

    public Categorie() {
    }

    public Categorie(String category, Date createdOn, Byte deleted) {
       this.category = category;
       this.createdOn = createdOn;
       this.deleted = deleted;
    }
   
    public Integer getId() {
        return this.id;
    }
    
    public void setId(Integer id) {
        this.id = id;
    }
    public String getCategory() {
        return this.category;
    }
    
    public void setCategory(String category) {
        this.category = category;
    }
    public Date getCreatedOn() {
        return this.createdOn;
    }
    
    public void setCreatedOn(Date createdOn) {
        this.createdOn = createdOn;
    }
    public Byte getDeleted() {
        return this.deleted;
    }
    
    public void setDeleted(Byte deleted) {
        this.deleted = deleted;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("id", id).
                append("category", category).
                append("createdOn", createdOn).
                append("deleted", deleted).
                toString();
    }


}


