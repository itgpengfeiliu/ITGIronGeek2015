package com.cei.kidvisionweb.dao;

import com.cei.kidvisionweb.db.model.OccupationalTitle;

public interface OccupationalTitleDao extends GenericDao<OccupationalTitle, Long> {

}
