package com.cei.kidvisionweb.service;

import java.util.List;

import com.google.api.services.youtube.model.PlaylistItem;

public interface AdminService {

	String getModule(int moduleId);
	
	String getModuleVideos(int moduleId);
	
	String getQuestionAndAnsers(int questionId);
	
	String getAllModules();
	
	String getAllVideos();
	
	//Integer getUserPrimaryAddressId(int userId);
	//String getUnmappingVideos();
	
	String mappingYoutubeMP4VideosAndTableVideos(List<PlaylistItem> streams);
	
	String getAllUsers();
	
	String getAllUsersPagination(int length, int start, int orderIndex, String order, String search);
	
	String countUsersByCountyStatePagination(int length, int start, int orderIndex, String order, String search);
	
	String getSurveyResults();
	
	String getUserSurveyAnswers();
	
	String getAllUserModuleSurveyAnswers();
	
	String getSurveyQuestions();
	
	String getUserModuleActivityFieldtripCVS(String title);
	
	String getStandardsByModule(int moduleId);
	
	String createModule(int userId, int moduleId, String title);
	
	int createModuleQuestion(int moduleId, String question, int sequence, int standardId);
	
	String createModuleQuestionAnswer(int questionId, String answer, short correct, Integer sequence);
	
	int createVideo(int userId, int moduleId, String fileName, String streamId, short isOverview, Byte sequence);
	
	String triggerModule(int userId, int moduleIde);
	
	String triggerUser(int adminUserId, int userId);
	
	String triggerUserPaid(int adminUserId, int userId, short isPaid);
	
	String createOrUpdateModuleStandard(int standardId, int moduleId, String title, String description, int number);
	
	String updateModule(int userId, int moduleId, String title, String shortDescription, String longDescription, String imageFileName, String iconFileName);
	
	String createOrUpdateModuleResource(int userId, int moduleId, int resourceId, String title, String shortDescription, String link, String imageFileName);
	
	String updateModuleClassroomMaterials(int userId, int moduleId,
    		String lessionPlanFileName, String assessmentFileName, String takeHomeFileName);
	
	int updateModuleQuestion(int questionId, String question, int sequence, int standardId);
	
	String updateModuleQuestionAnswer(int questionId, String answer, short correct, Integer sequence);
	
	//String updateVideo(int videoId, int userId, int moduleId, String fileName, String streamId, short isOverview, Byte sequence);

	String createOrUpdateVideo(int userId, int moduleId, int videoId);
	
	String createOrUpdateUploadedVideo(int userId, int moduleId, short isOverview, String fileName);
	
	String deleteModuleQuestion(int moduleId, int sequence);
	
	String deleteModuleQuestionAndAnswers(int questionId);
	
	//List<Video> getAllVideosList();
	
	//String mappingVideo(int id, String stream_id);
	
	String createSurveyQuestion(int userId, String question, int sequence);
	
	String updateSurveyQuestion(int userId, int questionId, String question, int sequence);
	
	String triggerSurveyQuestion(int userId, int questionId);
	
	String addOrUpdateAddress(Integer userId, Integer addressId, String streetAddress, String city, String county, 
    		String state, String country, String zipCode);
	
	String updateUser(int userId, String prefix, String firstName, String middleName, String lastName,
    		String email, String userName, String educationLevel, int occupationalTitleId, 
    		String otherOccupationalTitle, String phone, boolean emailNotification, byte registrationtypeId, 
    		String schoolName);
	
	String getUser(int userId);
	
	String getUserAddress(int addressId);
	
	String getNewRegistrationUsers(String starttime, String endtime);
	
	String updateUserPassword(int userId, String password);
	
	String checkUserName(String username);
	
	String updateUsername(int userId, String username);
}
