package com.cei.kidvisionweb.db.model;

import org.apache.commons.lang3.builder.ToStringBuilder;

public class Address implements java.io.Serializable {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private Integer id;
    private String streetAddress;
    private String country;
    private String state;
    private String city;
    private String zipCode;
	private String county;

    public Address() {
    }

    public Address(String streetAddress, String country, String state, String city, String zipCode, String county) {
        this.streetAddress = streetAddress;
        this.country = country;
        this.state = state;
        this.city = city;
        this.zipCode = zipCode;
        this.county = county;
    }

    public Integer getId() {
        return this.id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getStreetAddress() {
        return this.streetAddress;
    }

    public void setStreetAddress(String streetAddress) {
        this.streetAddress = streetAddress;
    }

    public String getCountry() {
        return this.country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getState() {
        return this.state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getCity() {
        return this.city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getZipCode() {
		return zipCode;
	}

	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}
	
    public String getCounty() {
        return this.county;
    }

    public void setCounty(String county) {
        this.county = county;
    }
    
    @Override
    public String toString() {
        return new ToStringBuilder(this).append("id", id).
                append("streetAddress", streetAddress).
                append("state", state).
                append("city", city).
                append("zipCode", zipCode).
                append("county", county).
                append("country", country).
                toString();
    }

}


