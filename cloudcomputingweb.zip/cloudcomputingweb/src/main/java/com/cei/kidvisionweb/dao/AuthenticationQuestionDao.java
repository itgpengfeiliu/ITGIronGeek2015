package com.cei.kidvisionweb.dao;

import com.cei.kidvisionweb.db.model.AuthenticationQuestion;

/**
 *
 * @author Shrikant
 */
public interface AuthenticationQuestionDao extends GenericDao<AuthenticationQuestion, Long> {
//    void add(AuthenticationQuestion object);
//
//    void update(AuthenticationQuestion object);
//
//    void delete(AuthenticationQuestion object);

    void deleteById(String id);
}
