package com.cei.kidvisionweb.db.model;

import org.apache.commons.lang3.builder.ToStringBuilder;

public class OccupationalTitle  implements java.io.Serializable {

     /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private Integer id;
    private String occupationalTitle;

    public OccupationalTitle() {
    }

    public OccupationalTitle(String occupationalTitle) {
       this.occupationalTitle = occupationalTitle;
    }
   
    public Integer getId() {
        return this.id;
    }
    
    public void setId(Integer id) {
        this.id = id;
    }
    public String getOccupationalTitle() {
        return this.occupationalTitle;
    }
    
    public void setOccupationalTitle(String occupationalTitle) {
        this.occupationalTitle = occupationalTitle;
    }


    @Override
    public String toString() {
        return new ToStringBuilder(this).append("id", id).
                append("occupationalTitle", occupationalTitle).
                toString();
    }

}


