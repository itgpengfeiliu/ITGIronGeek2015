package com.cei.kidvisionweb.db.model;

import org.apache.commons.lang3.builder.ToStringBuilder;

public class UserModuleTestTranscriptTitle implements java.io.Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private Integer user_id;
	private Integer test_year;
	private String test_title;
		
	public UserModuleTestTranscriptTitle(Integer user_id, Integer test_year, String test_title) {
		this.user_id = user_id;
		this.test_year = test_year;
		this.test_title = test_title;
	}

	public Integer getUser_id() {
		return user_id;
	}

	public void setUser_id(Integer user_id) {
		this.user_id = user_id;
	}

	public Integer getTest_year() {
		return test_year;
	}

	public void setTest_year(Integer test_year) {
		this.test_year = test_year;
	}

	public String getTest_title() {
		return test_title;
	}

	public void setTest_title(String test_title) {
		this.test_title = test_title;
	}

	public UserModuleTestTranscriptTitle() {
		
	}


	 @Override
	 public String toString() {
	     return new ToStringBuilder(this).append("user_id", user_id)
	    		 .append("test_year", test_year)
	    		 .append("test_title", test_title).toString();
	 }
}
