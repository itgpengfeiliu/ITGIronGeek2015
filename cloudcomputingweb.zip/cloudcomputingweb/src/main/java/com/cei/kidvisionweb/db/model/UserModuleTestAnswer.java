package com.cei.kidvisionweb.db.model;


import java.util.Date;
import org.apache.commons.lang3.builder.ToStringBuilder;


public class UserModuleTestAnswer  implements java.io.Serializable {

     /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	private Integer id;
    private Integer userId;
    private Integer userModuleTestId;
    private Integer questionId;
    private Integer answerId;
    private Date createdOn;

    public UserModuleTestAnswer() {
    }

    public UserModuleTestAnswer(Integer userId, Integer userModuleTestId, Integer questionId, Integer answerId, Date createdOn) {
       this.userId = userId;
       this.userModuleTestId = userModuleTestId;
       this.questionId = questionId;
       this.answerId = answerId;
       this.createdOn = createdOn;
    }
   
    public Integer getId() {
        return this.id;
    }
    
    public void setId(Integer id) {
        this.id = id;
    }
    public Integer getUserId() {
        return this.userId;
    }
    
    public void setUserId(Integer userId) {
        this.userId = userId;
    }
    public Integer getUserModuleTestId() {
        return this.userModuleTestId;
    }
    
    public void setUserModuleTestId(Integer userModuleTestId) {
        this.userModuleTestId = userModuleTestId;
    }
    public Integer getQuestionId() {
        return this.questionId;
    }
    
    public void setQuestionId(Integer questionId) {
        this.questionId = questionId;
    }
    public Integer getAnswerId() {
        return this.answerId;
    }
    
    public void setAnswerId(Integer answerId) {
        this.answerId = answerId;
    }
    public Date getCreatedOn() {
        return this.createdOn;
    }
    
    public void setCreatedOn(Date createdOn) {
        this.createdOn = createdOn;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("id", id).
                append("userId", userId).
                append("userModuleTestId", userModuleTestId).
                append("questionId", questionId).
                append("answerId", answerId).
                append("createdOn", createdOn).
                toString();
    }


}


