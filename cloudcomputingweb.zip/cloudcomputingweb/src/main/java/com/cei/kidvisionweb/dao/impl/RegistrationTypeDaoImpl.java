

package com.cei.kidvisionweb.dao.impl;

import com.cei.kidvisionweb.dao.RegistrationTypeDao;
import com.cei.kidvisionweb.db.model.RegistrationType;
import org.hibernate.Query;

/**
 *
 * @author Shrikant
 */
public class RegistrationTypeDaoImpl extends GenericDaoImpl<RegistrationType, Long> implements RegistrationTypeDao{
    
    @Override
    public void deleteById(String id) {
        StringBuffer hql = new StringBuffer(
                "delete from "
                + getPersistentClass().getName() + " as model where id="
                + id);
        Query query = getSession().createQuery(hql.toString());
        query.executeUpdate();
    }
}
