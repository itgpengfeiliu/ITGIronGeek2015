package com.cei.kidvisionweb.api.rest;

import com.cei.kidvisionweb.config.KidvisionWebConfig;
import com.cei.kidvisionweb.db.model.UserModuleActivity;
import com.cei.kidvisionweb.service.ModuleService;
import com.cei.kidvisionweb.service.UserLoginService;
import com.cei.kidvisionweb.service.UserService;
import com.cei.kidvisionweb.service.util.LoggedUser;
import com.cei.kidvisionweb.service.util.RegularExpressionUtil;
import com.cei.kidvisionweb.service.util.SimpleUser;
import com.cei.kidvisionweb.service.util.VideoProcessor;
import com.google.gson.GsonBuilder;
import com.sun.jersey.api.core.InjectParam;

import java.io.File;

import javax.servlet.ServletContext;
import javax.ws.rs.Consumes;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.AccessDeniedException;

/**
 *
 * @author Shrikant
 */
@Path("/vpk")
public class KidvisionResource {

    private static Logger logger = LoggerFactory.getLogger(KidvisionResource.class);
    //private static final String CLASSROOM_MATERIALS_DIRECTORY = "classroom_materials/";
    //private static final String LOGIN_URI = "/kidvisionweb/login.html";
    
    @Context 
	ServletContext context;
    
	@InjectParam
    private UserLoginService userLoginService;
	
    @InjectParam
    private VideoProcessor videoProcessor;
    
    @InjectParam
    private ModuleService moduleService;
    
    @InjectParam
    private UserService userService;
    
        
    @Autowired
    public KidvisionResource() {
    }

//    @Path("/status")
//    @GET
//    @Produces("text/html")
//    public Response status() {
//    	String result = "Wel-Come! ";
//    	try {
//	    	if ( userLoginService.isLoggedIn() ) {
//	    		LoggedUser loggedUser = userLoginService.getLoggedUserUtil();
//	    		result += " , " + loggedUser.toString();
//	    	}
//	        logger.debug("status result = " + result);
//    	} catch (Exception ex) {
//            logger.error("Error occurred:: ", ex);
//        }
//    	return Response.ok().entity(result).build();
//    }
    
//    @Path("/security")
//    @GET
//    @Produces("text/html")
//    public Response securtiy() {
//    	String result = "Security Test! ";
//    	try {
//	    	if ( userLoginService.isLoggedIn() ) {
//	    		LoggedUser loggedUser = userLoginService.getLoggedUserUtil();
//	    		result += " , " + loggedUser.toString();
//	    	}
//	        logger.debug("securtiy result = " + result);
//    	} catch (Exception ex) {
//            logger.error("Error occurred:: ", ex);
//        }
//        return Response.ok().entity(result).build();
//    } 
   

   /* @Path("/uploadvideo")
    @POST
    @Consumes(MediaType.MULTIPART_FORM_DATA)
    public Response uploadVideo(
            @FormDataParam("file") InputStream uploadedInputStream,
            @FormDataParam("file") FormDataContentDisposition fileDetail) {

    	// better to create once when application starts
    	File newUploadedFile = new File(KidvisionWebConfig.UPLOADED_VIDEOS_DIRECTORY);
    	if (!newUploadedFile.exists()) {  // Checks that Directory/Folder Doesn't Exists!  
            if(newUploadedFile.mkdir()) {  
            	logger.debug("create folder " + KidvisionWebConfig.UPLOADED_VIDEOS_DIRECTORY);
            }
        }
    	
    	String output = null;
        FileProcessor fileProcessor=new FileProcessor();
        logger.debug("save file locally.");
    	if ( fileProcessor.writeToFile(uploadedInputStream, fileDetail) )
    	{
    		logger.debug("file saved locally.");
            //output = "File uploaded to youtube video id : " + videoProcessor.uploadVideo(fileDetail);
            logger.debug("start process to upload file to youtube server.");
            videoProcessor.uploadVideo(fileDetail.getFileName());
            logger.debug("video upload process started.");
    	}
    	else
    	{
    		return Response.status(500).entity("Failed to save in server").build();
    	}
        
        return Response.status(200).entity(output).build();
    }*/
    
    @Path("/triggerRegitrationType")
    @POST
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    @Produces(MediaType.APPLICATION_JSON)
    public Response triggerRegitrationType(@FormParam("iscontinue") boolean isContinue) {
    	logger.debug("triggerRegitrationType iscontinue = " + isContinue);
		try {
			if ( userLoginService.isLoggedIn() ) {
				LoggedUser loggedUser = userLoginService.getLoggedUserUtil();
				logger.debug("logged user : " + loggedUser.toString());
				logger.info("change registration type request from username: " + loggedUser.getUsername() + ", userId: " + loggedUser.getId().toString());
				String result = moduleService.triggerRegistrationType(loggedUser.getId(), isContinue);
				logger.info("registration: " + result);
                                
				return Response.ok(result, MediaType.APPLICATION_JSON).build();
			}
        	else {
        		return Response.status(Response.Status.UNAUTHORIZED).entity("").build();
	    	}
		} catch (AccessDeniedException ex) {
        	logger.error("Error occurred::", ex);
        	return Response.status(Response.Status.FORBIDDEN).entity("").build();
        } catch (Exception ex) {
            logger.error("Error occurred:: ", ex);
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("").build();
        }
    }
    
    @Path("/addUserModuleSurvey")
    @POST
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    @Produces(MediaType.TEXT_HTML)
    public Response addUserModuleSurvey(@FormParam("moduleid") int moduleId,
    		@FormParam("a6") int a6, @FormParam("a1") int a1,
    		@FormParam("a2") int a2, @FormParam("a3") int a3,
    		@FormParam("a4") int a4, @FormParam("a7") int a7) {
    	logger.debug("addUserModuleSurvey a6 = " + a6 + " , a1 = " + a1 + " , a1 = " + a1
    			+ " , a2 = " + a2 + " , a3 = " + a3 + " , a4 = " + a4 + " , a7 = " + a7 + " , moduleId = " + moduleId);
		try {
			if ( userLoginService.isLoggedIn() ) {
				LoggedUser loggedUser = userLoginService.getLoggedUserUtil();
				logger.debug("logged user : " + loggedUser.toString());
				
				moduleService.addUserSurveyAnswers(loggedUser.getId(), 6, (byte)a6, moduleId);
				moduleService.addUserSurveyAnswers(loggedUser.getId(), 7, (byte)a7, moduleId);
				moduleService.addUserSurveyAnswers(loggedUser.getId(), 1, (byte)a1, moduleId);
				moduleService.addUserSurveyAnswers(loggedUser.getId(), 2, (byte)a2, moduleId);
				moduleService.addUserSurveyAnswers(loggedUser.getId(), 3, (byte)a3, moduleId);
				moduleService.addUserSurveyAnswers(loggedUser.getId(), 4, (byte)a4, moduleId);
				
				moduleService.addUserSurveyActivity(loggedUser.getId(), moduleId);
				
				return Response.ok().build();
			}
        	else {
        		return Response.status(Response.Status.UNAUTHORIZED).entity("").build();
	    	}
		} catch (AccessDeniedException ex) {
        	logger.error("Error occurred::", ex);
        	return Response.status(Response.Status.FORBIDDEN).entity("").build();
        } catch (Exception ex) {
            logger.error("Error occurred:: ", ex);
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("").build();
        }
    }
    
    @Path("/addUserModulePretestAnswers")
    @POST
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    @Produces(MediaType.TEXT_HTML)
    public Response addUserModulePretestAnswers(@FormParam("moduleid") int moduleId,
    		@FormParam("fieldtripActivityId") int fieldtripActivityId,
    		@FormParam("pqid0") int pqid0, @FormParam("paid0") int paid0,
    		@FormParam("pqid1") int pqid1, @FormParam("paid1") int paid1,
    		@FormParam("pqid2") int pqid2, @FormParam("paid2") int paid2,
    		@FormParam("pqid3") int pqid3, @FormParam("paid3") int paid3) {
    	logger.debug("addUserModulePretestAnswers moduleId = " + moduleId + " , fieldtripActivityId = " + fieldtripActivityId + " , pqid0 = " + pqid0 + " , paid0 = " + paid0
    			+ " , pqid1 = " + pqid1 + " , paid1 = " + paid1 + " , pqid2 = " + pqid2 + " , paid2 = " + paid2
    			+ " , pqid3 = " + pqid3 + " , paid3 = " + paid3);
		try {
			if ( userLoginService.isLoggedIn() ) {
				LoggedUser loggedUser = userLoginService.getLoggedUserUtil();
				logger.debug("logged user : " + loggedUser.toString());
				
				moduleService.addUserModulePretestAnswer(loggedUser.getId(), moduleId, pqid0, paid0, fieldtripActivityId);
				moduleService.addUserModulePretestAnswer(loggedUser.getId(), moduleId, pqid1, paid1, fieldtripActivityId);
				moduleService.addUserModulePretestAnswer(loggedUser.getId(), moduleId, pqid2, paid2, fieldtripActivityId);
				moduleService.addUserModulePretestAnswer(loggedUser.getId(), moduleId, pqid3, paid3, fieldtripActivityId);
				
				return Response.ok("true").build();
			}
        	else {
        		return Response.status(Response.Status.UNAUTHORIZED).entity("").build();
	    	}
		} catch (AccessDeniedException ex) {
        	logger.error("Error occurred::", ex);
        	return Response.status(Response.Status.FORBIDDEN).entity("").build();
        } catch (Exception ex) {
            logger.error("Error occurred:: ", ex);
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("").build();
        }
    }
    
    @Path("/addUserModuleSurveyAnswers")
    @POST
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    @Produces(MediaType.TEXT_PLAIN)
    public Response addUserModuleSurveyAnswers(@FormParam("moduleid") int moduleId,
    		@FormParam("fieldtripActivityId") int fieldtripActivityId,
    		@FormParam("userModuleTestId") int userModuleTestId,
    		@FormParam("said10") int said10,
    		@FormParam("said1") int said1,
    		@FormParam("said2") int said2,
    		@FormParam("said3") int said3,
    		@FormParam("said4") int said4,
    		@FormParam("said5") int said5,
    		@FormParam("said6") int said6,
    		@FormParam("said7") int said7,
    		@FormParam("said8") int said8,
    		@FormParam("said9") int said9,
    		@FormParam("said12") int said12,
    		@FormParam("said11") int said11,
    		@FormParam("said13") String said13) {
    	logger.debug("addUserModuleSurveyAnswers moduleId = " + moduleId + " , fieldtripActivityId " + fieldtripActivityId 
    			+ " , userModuleTestId = " + userModuleTestId + " , said10 = " + said10
    			+ " , said1 = " + said1  + " , said2 = " + said2
    			+ " , said3 = " + said3 + " , said4 = " + said4 + " , said5 = " + said5
    			+ " , said6 = " + said6 + " , said7 = " + said7 + " , said8 = " + said8 + " , said9 = " + said9
    			+ " , said12 = " + said12 + " , said11 = " + said11 + " , said13 = " + said13);
		try {
			if ( userLoginService.isLoggedIn() ) {
				LoggedUser loggedUser = userLoginService.getLoggedUserUtil();
				logger.debug("logged user : " + loggedUser.toString());
								
				moduleService.addUserModuleSurveyAnswer(loggedUser.getId(), moduleId, 10, said10, null, fieldtripActivityId);
				moduleService.addUserModuleSurveyAnswer(loggedUser.getId(), moduleId, 1, said1, null, fieldtripActivityId);
				moduleService.addUserModuleSurveyAnswer(loggedUser.getId(), moduleId, 2, said2, null, fieldtripActivityId);
				moduleService.addUserModuleSurveyAnswer(loggedUser.getId(), moduleId, 3, said3, null, fieldtripActivityId);
				moduleService.addUserModuleSurveyAnswer(loggedUser.getId(), moduleId, 4, said4, null, fieldtripActivityId);
				moduleService.addUserModuleSurveyAnswer(loggedUser.getId(), moduleId, 5, said5, null, fieldtripActivityId);
				moduleService.addUserModuleSurveyAnswer(loggedUser.getId(), moduleId, 6, said6, null, fieldtripActivityId);
				moduleService.addUserModuleSurveyAnswer(loggedUser.getId(), moduleId, 7, said7, null, fieldtripActivityId);
				moduleService.addUserModuleSurveyAnswer(loggedUser.getId(), moduleId, 8, said8, null, fieldtripActivityId);
				moduleService.addUserModuleSurveyAnswer(loggedUser.getId(), moduleId, 9, said9, null, fieldtripActivityId);
				
				moduleService.addUserModuleSurveyAnswer(loggedUser.getId(), moduleId, 11, said11, null, fieldtripActivityId);
				moduleService.addUserModuleSurveyAnswer(loggedUser.getId(), moduleId, 12, said12, null, fieldtripActivityId);
				
				moduleService.addUserModuleSurveyAnswer(loggedUser.getId(), moduleId, 13, 0, said13, fieldtripActivityId);
				
				moduleService.completeUserModuleTestE(userModuleTestId);
				
				moduleService.completeFieldTripModuleActivity(fieldtripActivityId);
				
				return Response.ok("true", MediaType.TEXT_PLAIN).build();
			}
        	else {
        		return Response.status(Response.Status.UNAUTHORIZED).entity("").build();
	    	}
		} catch (AccessDeniedException ex) {
        	logger.error("Error occurred::", ex);
        	return Response.status(Response.Status.FORBIDDEN).entity("").build();
        } catch (Exception ex) {
            logger.error("Error occurred:: ", ex);
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("").build();
        }
    }
    
    @Path("/addUserModuleTestAnswers")
    @POST
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    @Produces(MediaType.APPLICATION_JSON)
    public Response addUserModuleTestAnswers(@FormParam("moduleid") int moduleId,
    		@FormParam("fieldtripActivityId") int fieldtripActivityId,
    		@FormParam("qid0") int qid0, @FormParam("aid0") int aid0,
    		@FormParam("qid1") int qid1, @FormParam("aid1") int aid1,
    		@FormParam("qid2") int qid2, @FormParam("aid2") int aid2,
    		@FormParam("qid3") int qid3, @FormParam("aid3") int aid3) {
    	logger.debug("addUserModuleTestAnswers moduleId = " + moduleId + " , pqid0 = " + qid0 + " , paid0 = " + aid0
    			+ " , pqid1 = " + qid1 + " , paid1 = " + aid1 + " , pqid2 = " + qid2 + " , paid2 = " + aid2
    			+ " , pqid3 = " + qid3 + " , paid3 = " + aid3);
		try {
			if ( userLoginService.isLoggedIn() ) {
				LoggedUser loggedUser = userLoginService.getLoggedUserUtil();
				logger.debug("logged user : " + loggedUser.toString());
				
				int score = moduleService.scoreUserModuleTest(qid0 + "," + qid1 + "," + qid2 + "," + qid3 + ","
						+ aid0 + "," + aid1 + "," + aid2 + "," + aid3);
				byte isPassed = 0;
				if (score == 4) {
					isPassed = 1;
				}
				Integer userModuleTestId = moduleService.addUserModuleTestE(loggedUser.getId(), moduleId, fieldtripActivityId, (byte)score, isPassed);
				
				moduleService.addOrUpdateUserModuleTestAnswer(loggedUser.getId(), userModuleTestId, qid0, aid0);
				moduleService.addOrUpdateUserModuleTestAnswer(loggedUser.getId(), userModuleTestId, qid1, aid1);
				moduleService.addOrUpdateUserModuleTestAnswer(loggedUser.getId(), userModuleTestId, qid2, aid2);
				moduleService.addOrUpdateUserModuleTestAnswer(loggedUser.getId(), userModuleTestId, qid3, aid3);
				
				String result = moduleService.getUserModuleTestE(userModuleTestId);
				
				return Response.ok(result, MediaType.APPLICATION_JSON).build();
			}
        	else {
        		return Response.status(Response.Status.UNAUTHORIZED).entity("").build();
	    	}
		} catch (AccessDeniedException ex) {
        	logger.error("Error occurred::", ex);
        	return Response.status(Response.Status.FORBIDDEN).entity("").build();
        } catch (Exception ex) {
            logger.error("Error occurred:: ", ex);
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("").build();
        }
    }
    
    @Path("/addUserModuleTestAnswer")
    @POST
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    @Produces(MediaType.TEXT_HTML)
    public Response addUserModuleTestAnswer(@FormParam("userModuleTestId") int userModuleTestId,
    		@FormParam("qid") int qid, @FormParam("aid") int aid) {
    	logger.debug("addUserModuleTestAnswer userModuleTestId = " + userModuleTestId + " , qid = " + qid + " , a1id = " + aid);
		try {
			if ( userLoginService.isLoggedIn() ) {
				LoggedUser loggedUser = userLoginService.getLoggedUserUtil();
				logger.debug("logged user : " + loggedUser.toString());
				
				String userModuleTestAnswerId = "-1";
				if (qid != 0 && aid != 0) {
					// add UserModuleTest if not exist
					userModuleTestAnswerId = moduleService.addOrUpdateUserModuleTestAnswer(loggedUser.getId(), userModuleTestId, qid, aid);
				}
				
				return Response.ok(userModuleTestAnswerId).build();
			}
        	else {
        		return Response.status(Response.Status.UNAUTHORIZED).entity("").build();
	    	}
		} catch (AccessDeniedException ex) {
        	logger.error("Error occurred::", ex);
        	return Response.status(Response.Status.FORBIDDEN).entity("").build();
        } catch (Exception ex) {
            logger.error("Error occurred:: ", ex);
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("").build();
        }
    }
    
    @Path("/scoreUserPretest")
    @POST
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    @Produces(MediaType.TEXT_HTML)
    public Response scoreUserPretest(@FormParam("qaids") String qaids,
    		@FormParam("totalQuestionCount") int totalQuestionCount) {
    	logger.debug("scoreUserPretest qaids = " + qaids + " , totalQuestionCount = " + totalQuestionCount);
		try {
			if ( userLoginService.isLoggedIn() ) {
				LoggedUser loggedUser = userLoginService.getLoggedUserUtil();
				logger.debug("logged user : " + loggedUser.toString());
				
				String[] params = qaids.split(",");
				if (params.length / 2 == totalQuestionCount) {
				
					moduleService.addUserPretestAnswers(loggedUser.getId(), qaids);
					
					int score = moduleService.scoreUserModuleTest(qaids);
					logger.debug("score = " + score);
					
					moduleService.updateUserPretestCompleted(loggedUser.getId());
					
					return Response.ok(Integer.toString(score)).build();
				}
				else {
					return Response.status(Response.Status.BAD_REQUEST).entity("").build();
				}
			}
        	else {
        		return Response.status(Response.Status.UNAUTHORIZED).entity("").build();
	    	}
		} catch (AccessDeniedException ex) {
        	logger.error("Error occurred::", ex);
        	return Response.status(Response.Status.FORBIDDEN).entity("").build();
        } catch (Exception ex) {
            logger.error("Error occurred:: ", ex);
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("").build();
        }
    }
    
    @Path("/scoreUserModelTest")
    @POST
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    @Produces(MediaType.APPLICATION_JSON)
    public Response scoreUserModelTest(@FormParam("moduleid") int moduleId,
    		@FormParam("userModuleTestId") int userModuleTestId,
    		@FormParam("qid") int qid, @FormParam("aid") int aid,
    		@FormParam("testActivityId") int testActivityId, 
    		@FormParam("qaids") String qaids,
    		@FormParam("totalQuestionCount") int totalQuestionCount) {
    	logger.debug("scoreUserModelTest userModuleTestId = " + userModuleTestId
    			+ " , qid = " + qid + " , aid = " + aid
    			+ " , totalQuestionCount = " + totalQuestionCount);
		try {
			if ( userLoginService.isLoggedIn() ) {
				LoggedUser loggedUser = userLoginService.getLoggedUserUtil();
				logger.debug("logged user : " + loggedUser.toString());
				
				String[] params = qaids.split(",");
				if (params.length / 2 == totalQuestionCount) {
					// add UserModuleTest if not exist
					//moduleService.addOrUpdateUserModuleTestAnswer(loggedUser.getId(), userModuleTestId, q1id, a1id);
					//moduleService.addOrUpdateUserModuleTestAnswer(loggedUser.getId(), userModuleTestId, q2id, a2id);
					//moduleService.addOrUpdateUserModuleTestAnswer(loggedUser.getId(), userModuleTestId, q3id, a3id);
					moduleService.addOrUpdateUserModuleTestAnswer(loggedUser.getId(), userModuleTestId, qid, aid);
					
					int score = moduleService.scoreUserModuleTest(qaids);
					logger.debug("score = " + score);
					String result = moduleService.updateUserModuleTest(userModuleTestId, totalQuestionCount, score);
					
					//if (score == totalQuestionCount) {
					//	moduleService.addIfNotExistUserModuleActivity(loggedUser.getId(), moduleId, UserModuleActivity.ACTIVITY_TYPES.survey.name());
					//}
					
					moduleService.updateUserModuleActivityCompleted(testActivityId);
					//moduleService.updateUserModuleActivity(loggedUser.getId(), moduleId, UserModuleActivity.ACTIVITY_TYPES.posttest.name());
					
					return Response.ok(result, MediaType.APPLICATION_JSON).build();
				}
				else {
					return Response.status(Response.Status.BAD_REQUEST).entity("").build();
				}
			}
        	else {
        		return Response.status(Response.Status.UNAUTHORIZED).entity("").build();
	    	}
		} catch (AccessDeniedException ex) {
        	logger.error("Error occurred::", ex);
        	return Response.status(Response.Status.FORBIDDEN).entity("").build();
        } catch (Exception ex) {
            logger.error("Error occurred:: ", ex);
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("").build();
        }
    }
    
    
    @Path("/getUserModuleTests")
    @GET
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    @Produces(MediaType.APPLICATION_JSON)
    public Response getUserModuleTests(@QueryParam("mid") int moduleId) {
    	logger.debug("getUserModuleTests moduleid = " + moduleId);
		try {
			if ( userLoginService.isLoggedIn() ) {
				LoggedUser loggedUser = userLoginService.getLoggedUserUtil();
				logger.debug("logged user : " + loggedUser.toString());
				
				String result = moduleService.getUserModuleTests(loggedUser.getId(), moduleId);
				
				return Response.ok(result, MediaType.APPLICATION_JSON).build();
			}
        	else {
        		return Response.status(Response.Status.UNAUTHORIZED).entity("").build();
	    	}
		} catch (AccessDeniedException ex) {
        	logger.error("Error occurred::", ex);
        	return Response.status(Response.Status.FORBIDDEN).entity("").build();
        } catch (Exception ex) {
            logger.error("Error occurred:: ", ex);
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("").build();
        }
    }
    
    @Path("/userTakeModelTest")
    @POST
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    @Produces(MediaType.TEXT_HTML)
    public Response userTakeModelTest(@FormParam("moduleid") int moduleId) {
    	logger.debug("userTakeModelTest moduleid = " + moduleId);
		try {
			if ( userLoginService.isLoggedIn() ) {
				LoggedUser loggedUser = userLoginService.getLoggedUserUtil();
				logger.debug("logged user : " + loggedUser.toString());
				
				// add UserModuleTest if not exist
				String userModuleTestId = moduleService.addUserModuleTest(loggedUser.getId(), moduleId);
				
				// add UserModuleActivity if not exist
				String activityId = moduleService.addUserModuleActivity(loggedUser.getId(), moduleId, UserModuleActivity.ACTIVITY_TYPES.posttest.name());
				return Response.ok(userModuleTestId + "," + activityId).build();
			}
        	else {
        		return Response.status(Response.Status.UNAUTHORIZED).entity("").build();
	    	}
		} catch (AccessDeniedException ex) {
        	logger.error("Error occurred::", ex);
        	return Response.status(Response.Status.FORBIDDEN).entity("").build();
        } catch (Exception ex) {
            logger.error("Error occurred:: ", ex);
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("").build();
        }
    }
    
    @Path("/getUserSurveyActivities")
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response getUserSurveyActivities(@QueryParam("mid") int moduleId) {
    	logger.debug("getUserModuleSurveyActivity moduleId = " + moduleId);
        try {
        	if ( userLoginService.isLoggedIn() ) {
	    		LoggedUser loggedUser = userLoginService.getLoggedUserUtil();
	    		logger.debug("logged user : " + loggedUser.toString());
	    		
	    		String result = moduleService.getUserSurveyActivities(loggedUser.getId(), moduleId);
	    		
	    		return Response.ok(result, MediaType.APPLICATION_JSON).build();
        	}
        	else {
        		return Response.status(Response.Status.UNAUTHORIZED).entity("").build();
	    	}
        } catch (AccessDeniedException ex) {
        	logger.error("Error occurred::", ex);
        	return Response.status(Response.Status.FORBIDDEN).entity("").build();
        } catch (Exception ex) {
            logger.error("Error occurred:: ", ex);
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("").build();
        }
    }
        
    @Path("/getUserModuleActivities")
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response getUserModuleActivities(@QueryParam("mid") int moduleId) {
    	logger.debug("getUserModuleActivities param moduleId = " + moduleId);
        try {
        	if ( userLoginService.isLoggedIn() ) {
	    		LoggedUser loggedUser = userLoginService.getLoggedUserUtil();
	    		logger.debug("logged user : " + loggedUser.toString());
	    		
	    		String result = moduleService.getUserModuleActivities(loggedUser.getId(), moduleId);
	    		
	    		return Response.ok(result, MediaType.APPLICATION_JSON).build();
        	}
        	else {
        		return Response.status(Response.Status.UNAUTHORIZED).entity("").build();
	    	}
        } catch (AccessDeniedException ex) {
        	logger.error("Error occurred::", ex);
        	return Response.status(Response.Status.FORBIDDEN).entity("").build();
        } catch (Exception ex) {
            logger.error("Error occurred:: ", ex);
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("").build();
        }
    }
    
    @Path("/updateUserModuleActivityVideos")
    @POST
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    @Produces(MediaType.TEXT_HTML)
    public Response updateUserModuleActivityVideos(@FormParam("videoActivityId") int videoActivityId) {
    	logger.debug("updateUserModuleActivity params videoActivityId = " + videoActivityId);
    	try {
    		if ( userLoginService.isLoggedIn() ) {
				LoggedUser loggedUser = userLoginService.getLoggedUserUtil();
				logger.debug("logged user : " + loggedUser.toString());
				
				String result = moduleService.updateUserModuleActivityCompleted(videoActivityId);
				return Response.ok(result).build();
			}
        	else {
        		return Response.status(Response.Status.UNAUTHORIZED).entity("").build();
	    	}
		} catch (AccessDeniedException ex) {
        	logger.error("Error occurred::", ex);
        	return Response.status(Response.Status.FORBIDDEN).entity("").build();
        } catch (Exception ex) {
            logger.error("Error occurred:: ", ex);
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("").build();
        }
    }
    
//    @Path("/updateUserModuleActivity")
//    @POST
//    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
//    @Produces(MediaType.TEXT_HTML)
//    public Response updateUserModuleActivity(@FormParam("moduleid") int moduleId, @FormParam("activitytype") String activityType) {
//    	logger.debug("updateUserModuleActivity params moduleid = " + moduleId
//				+ " , activitytype = " + activityType);
//    	try {
//    		if ( userLoginService.isLoggedIn() ) {
//				LoggedUser loggedUser = userLoginService.getLoggedUserUtil();
//				logger.debug("logged user : " + loggedUser.toString());
//				
//				String result = moduleService.updateUserModuleActivity(loggedUser.getId(), moduleId, activityType);
//				return Response.ok(result).build();
//			}
//        	else {
//        		return Response.status(Response.Status.UNAUTHORIZED).entity("").build();
//	    	}
//		} catch (AccessDeniedException ex) {
//        	logger.error("Error occurred::", ex);
//        	return Response.status(Response.Status.FORBIDDEN).entity("").build();
//        } catch (Exception ex) {
//            logger.error("Error occurred:: ", ex);
//            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("").build();
//        }
//    }
    
    @Path("/addUserModuleActivityVideos")
    @POST
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    @Produces(MediaType.TEXT_HTML)
    public Response addUserModuleActivityVideos(@FormParam("moduleid") int moduleId) {
    	logger.debug("addUserModuleActivity params moduleid = " + moduleId); // + " , activitytype = " + activityType  + " , activityname = " + activityName
		try {
			if ( userLoginService.isLoggedIn() ) {
				LoggedUser loggedUser = userLoginService.getLoggedUserUtil();
				logger.debug("logged user : " + loggedUser.toString());
				
				String result = moduleService.addUserModuleActivity(loggedUser.getId(), moduleId, UserModuleActivity.ACTIVITY_TYPES.videos.name());
				return Response.ok(result).build();
			}
        	else {
        		return Response.status(Response.Status.UNAUTHORIZED).entity("").build();
	    	}
		} catch (AccessDeniedException ex) {
        	logger.error("Error occurred::", ex);
        	return Response.status(Response.Status.FORBIDDEN).entity("").build();
        } catch (Exception ex) {
            logger.error("Error occurred:: ", ex);
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("").build();
        }
    }
    
    @Path("/addUserModuleActivityFieldtrip")
    @POST
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    @Produces(MediaType.TEXT_HTML)
    public Response addUserModuleActivityFieldtrip(@FormParam("moduleid") int moduleId) {
    	logger.debug("addUserModuleActivity params moduleid = " + moduleId);
		try {
			if ( userLoginService.isLoggedIn() ) {
				LoggedUser loggedUser = userLoginService.getLoggedUserUtil();
				logger.debug("logged user : " + loggedUser.toString());
				
				String result = moduleService.addUserModuleActivity(loggedUser.getId(), moduleId, UserModuleActivity.ACTIVITY_TYPES.fieldtrip.name());
				return Response.ok(result).build();
			}
        	else {
        		return Response.status(Response.Status.UNAUTHORIZED).entity("").build();
	    	}
		} catch (AccessDeniedException ex) {
        	logger.error("Error occurred::", ex);
        	return Response.status(Response.Status.FORBIDDEN).entity("").build();
        } catch (Exception ex) {
            logger.error("Error occurred:: ", ex);
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("").build();
        }
    }
    
    
//    @Path("/addUserModuleActivity")
//    @POST
//    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
//    @Produces(MediaType.TEXT_HTML)
//    public Response addUserModuleActivity(@FormParam("moduleid") int moduleId, @FormParam("activitytype") String activityType) {
//    									  //@FormParam("activityname") String activityName) {
//    	logger.debug("addUserModuleActivity params moduleid = " + moduleId
//				+ " , activitytype = " + activityType); //  + " , activityname = " + activityName
//		try {
//			if ( userLoginService.isLoggedIn() ) {
//				LoggedUser loggedUser = userLoginService.getLoggedUserUtil();
//				logger.debug("logged user : " + loggedUser.toString());
//				
//				//String result = moduleService.addIfNotExistUserModuleActivity(loggedUser.getId(), moduleId, activityType);
//				String result = moduleService.addUserModuleActivity(loggedUser.getId(), moduleId, activityType);
//				return Response.ok(result).build();
//			}
//        	else {
//        		return Response.status(Response.Status.UNAUTHORIZED).entity("").build();
//	    	}
//		} catch (AccessDeniedException ex) {
//        	logger.error("Error occurred::", ex);
//        	return Response.status(Response.Status.FORBIDDEN).entity("").build();
//        } catch (Exception ex) {
//            logger.error("Error occurred:: ", ex);
//            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("").build();
//        }
//    }
    
//    @Path("/showModuleImage")
//    @GET
//    @Produces("image/png")
//    public Response getFullImage(@QueryParam("folder") String folder, 
//    		@QueryParam("filename") String filename) {
//
//    	logger.debug("getFullImage params folder = " + folder + " , filename = " + filename);
//		try {
//			if ( userLoginService.isLoggedIn() ) {
//				LoggedUser loggedUser = userLoginService.getLoggedUserUtil();
//				logger.debug("logged user : " + loggedUser.toString());
//				
//				String pathname = "";
//				if ( folder.equalsIgnoreCase("image") ) {
//					pathname = KidvisionWebConfig.MODULE_IMAGE_DIRECTORY + filename;
//				}
//				else if ( folder.equalsIgnoreCase("icon") ) {
//					pathname = KidvisionWebConfig.MODULE_ICON_DIRECTORY + filename;
//				}
//				else if ( folder.equalsIgnoreCase("resource") ) {
//					pathname = KidvisionWebConfig.MODULE_RESOURCE_IMAGE_DIRECTORY + filename;
//				}
//				
//				File file = new File(pathname);
//				logger.debug("file fullpath = " + pathname);
//				
//				if(file.exists()){
//					
//					ResponseBuilder responseBuilder = Response.ok(file);
//					//responseBuilder.header("Content-Disposition", "attachment; filename=" + filename + "." + fileextension);
//		    		return responseBuilder.build();
//				}
//				else {
//					return Response.status(Response.Status.NOT_FOUND).entity("").build();
//				}
//			}
//			else {
//				return Response.status(Response.Status.UNAUTHORIZED).entity("").build();
//			}
//		} catch (Exception ex) {
//		    logger.error("Error occurred:: ", ex);
//		    return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("").build();
//		}
//    }
    
    @Path("/loadModuleClassroomMaterial")
    @GET
    @Produces(MediaType.APPLICATION_OCTET_STREAM)
    public Response loadModuleClassroomMaterial(@QueryParam("filename") String filename,
				@QueryParam("fileextension") String fileextension,
				@QueryParam("moduleid") int moduleId,
				@QueryParam("activityname") String activityName) {
    	logger.debug("loadModuleClassroomMaterial params filename = " + filename + "." + fileextension
    					+ " , moduleid = " + moduleId + " , activityname = " + activityName);
    	try {
    		if ( userLoginService.isLoggedIn() ) {
	    		LoggedUser loggedUser = userLoginService.getLoggedUserUtil();
	    		logger.debug("logged user : " + loggedUser.toString());
	    		
	    		String pathname = KidvisionWebConfig.CLASSROOM_MATERIALS_DIRECTORY + filename + "." + fileextension;
	    		File file = new File(pathname);
	    		logger.debug("file fullpath = " + pathname);
	    		
	    		if(file.exists()){
	    			
	    			try {
	    				activityName = UserModuleActivity.getActivityNameFiles(activityName);
	    				moduleService.addUserModuleActivityFiles(loggedUser.getId(), moduleId, activityName);
	    			} catch (AccessDeniedException ex) {
	    		    	logger.error("Error occurred::", ex);
	    		    } catch (Exception ex) {
	    		        logger.error("Error occurred:: ", ex);
	    		    }
	    			
	    			ResponseBuilder responseBuilder = Response.ok(file);
	    			responseBuilder.header("Content-Disposition", "inline; filename=" + filename + "." + fileextension);
	    			responseBuilder.header("Content-Type", "application/pdf");
		    		return responseBuilder.build();
	    		}
	    		else {
	    			return Response.status(Response.Status.NOT_FOUND).entity("").build();
	    		}
	    	}
	    	else {
	    		return Response.status(Response.Status.UNAUTHORIZED).entity("").build();
	    	}
	    } catch (Exception ex) {
	        logger.error("Error occurred:: ", ex);
	        return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("").build();
	    }
    }  
    
    @Path("/downloadModuleClassroomMaterial")
    @GET
    @Produces(MediaType.APPLICATION_OCTET_STREAM)
    public Response downloadModuleClassroomMaterial(@QueryParam("filename") String filename,
    												@QueryParam("fileextension") String fileextension,
    												@QueryParam("moduleid") int moduleId,
    												@QueryParam("activityname") String activityName) {
    	logger.debug("downloadModuleClassroomMaterial params filename = " + filename + "." + fileextension
    					+ " , moduleid = " + moduleId + " , activityname = " + activityName);
    	try {
    		if ( userLoginService.isLoggedIn() ) {
	    		LoggedUser loggedUser = userLoginService.getLoggedUserUtil();
	    		logger.debug("logged user : " + loggedUser.toString());
	    		
	    		String pathname = KidvisionWebConfig.CLASSROOM_MATERIALS_DIRECTORY + filename + "." + fileextension;
	    		File file = new File(pathname);
	    		logger.debug("file fullpath = " + pathname);
	    		
	    		if(file.exists()){
	    			
	    			try {
	    				activityName = UserModuleActivity.getActivityNameFiles(activityName);
	    				moduleService.addUserModuleActivityFiles(loggedUser.getId(), moduleId, activityName);
	    			} catch (AccessDeniedException ex) {
	    		    	logger.error("Error occurred::", ex);
	    		    } catch (Exception ex) {
	    		        logger.error("Error occurred:: ", ex);
	    		    }
	    			
	    			ResponseBuilder responseBuilder = Response.ok(file);
	    			responseBuilder.header("Content-Disposition", "attachment; filename=" + filename + "." + fileextension);
		    		return responseBuilder.build();
	    		}
	    		else {
	    			return Response.status(Response.Status.NOT_FOUND).entity("").build();
	    		}
	    	}
	    	else {
	    		return Response.status(Response.Status.UNAUTHORIZED).entity("").build();
	    	}
	    } catch (Exception ex) {
	        logger.error("Error occurred:: ", ex);
	        return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("").build();
	    }
    }  
    
    @Path("/getUserModuleTestAnswers")
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response getUserModuleTestAnswers(@QueryParam("userModuleTestId") int userModuleTestId) {
    	logger.debug("getUserModuleTestAnswers param userModuleTestId = " + userModuleTestId);
        try {
        	if ( userLoginService.isLoggedIn() ) {
	    		LoggedUser loggedUser = userLoginService.getLoggedUserUtil();
	    		logger.debug("logged user : " + loggedUser.toString());
	    		
	    		String result = moduleService.getUserModuleTestAnswers(loggedUser.getId(), userModuleTestId);
	    		
	    		return Response.ok(result, MediaType.APPLICATION_JSON).build();
        	}
        	else {
        		return Response.status(Response.Status.UNAUTHORIZED).entity("").build();
	    	}
        } catch (AccessDeniedException ex) {
        	logger.error("Error occurred::", ex);
        	return Response.status(Response.Status.FORBIDDEN).entity("").build();
        } catch (Exception ex) {
            logger.error("Error occurred:: ", ex);
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("").build();
        }
    }
    
    
    @Path("/getUserModuleTest")
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response getUserModuleTest(@QueryParam("mid") int moduleId) {
    	logger.debug("getUserModuleTest param moduleId = " + moduleId);
        try {
        	if ( userLoginService.isLoggedIn() ) {
	    		LoggedUser loggedUser = userLoginService.getLoggedUserUtil();
	    		logger.debug("logged user : " + loggedUser.toString());
	    		
	    		String result = moduleService.getUserModuleTest(loggedUser.getId(), moduleId);
	    		
	    		return Response.ok(result, MediaType.APPLICATION_JSON).build();
        	}
        	else {
        		return Response.status(Response.Status.UNAUTHORIZED).entity("").build();
	    	}
        } catch (AccessDeniedException ex) {
        	logger.error("Error occurred::", ex);
        	return Response.status(Response.Status.FORBIDDEN).entity("").build();
        } catch (Exception ex) {
            logger.error("Error occurred:: ", ex);
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("").build();
        }
    }
    
    @Path("/getModuleSurveyQuestions")
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response getModuleSurveyQuestions() {
    	logger.debug("getModuleSurveyQuestions");
        try {
        	if ( userLoginService.isLoggedIn() ) {
	    		LoggedUser loggedUser = userLoginService.getLoggedUserUtil();
	    		logger.debug("logged user : " + loggedUser.toString());
	    		
	    		String result = moduleService.getModuleSurveyQuestions();
	    		
	    		return Response.ok(result, MediaType.APPLICATION_JSON).build();
        	}
        	else {
        		return Response.status(Response.Status.UNAUTHORIZED).entity("").build();
	    	}
        } catch (AccessDeniedException ex) {
        	logger.error("Error occurred::", ex);
        	return Response.status(Response.Status.FORBIDDEN).entity("").build();
        } catch (Exception ex) {
            logger.error("Error occurred:: ", ex);
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("").build();
        }
    }
        
    @Path("/getQuestionsAndAnswersByModule")
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response getQuestionsAndAnswersByModule(@QueryParam("mid") int moduleId) {
    	logger.debug("getQuestionsAndAnswersByModule param moduleId = " + moduleId);
        try {
        	if ( userLoginService.isLoggedIn() ) {
	    		LoggedUser loggedUser = userLoginService.getLoggedUserUtil();
	    		logger.debug("logged user : " + loggedUser.toString());
	    		
	    		String result = moduleService.getQuestionsAndAnswersByModule(moduleId);
	    		
	    		return Response.ok(result, MediaType.APPLICATION_JSON).build();
        	}
        	else {
        		return Response.status(Response.Status.UNAUTHORIZED).entity("").build();
	    	}
        } catch (AccessDeniedException ex) {
        	logger.error("Error occurred::", ex);
        	return Response.status(Response.Status.FORBIDDEN).entity("").build();
        } catch (Exception ex) {
            logger.error("Error occurred:: ", ex);
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("").build();
        }
    }
    
    @Path("/getPretestQuestionsAndAnswers")
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response getPretestQuestionsAndAnswers(@QueryParam("count") int count) {
    	logger.debug("getPretestQuestionsAndAnswers count = " + count);
        try {
        	if ( userLoginService.isLoggedIn() ) {
	    		LoggedUser loggedUser = userLoginService.getLoggedUserUtil();
	    		logger.debug("logged user : " + loggedUser.toString());
	    		
	    		//if (loggedUser.getPretestCompleted() == (byte)1) {
	    		//	return Response.ok(new GsonBuilder().serializeNulls().create().toJson(loggedUser), MediaType.APPLICATION_JSON).build();
	    		//}
	    		String result = moduleService.getPretestRandomQuestionsAndAnswers(count);
	    		
	    		return Response.ok(result, MediaType.APPLICATION_JSON).build();
        	}
        	else {
        		return Response.status(Response.Status.UNAUTHORIZED).entity("").build();
	    	}
        } catch (AccessDeniedException ex) {
        	logger.error("Error occurred::", ex);
        	return Response.status(Response.Status.FORBIDDEN).entity("").build();
        } catch (Exception ex) {
            logger.error("Error occurred:: ", ex);
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("").build();
        }
    }
    
    
    @Path("/getStandardsByModule")
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response getStandardsByModule(@QueryParam("mid") int moduleId) {
    	logger.debug("getStandardsByModule param moduleId = " + moduleId);
    	try {
        	if ( userLoginService.isLoggedIn() ) {
	    		LoggedUser loggedUser = userLoginService.getLoggedUserUtil();
	    		logger.debug("logged user : " + loggedUser.toString());
	    		
	    		String result = moduleService.getStandardsByModule(moduleId);
	    		
	    		return Response.ok(result, MediaType.APPLICATION_JSON).build();
        	}
        	else {
        		return Response.status(Response.Status.UNAUTHORIZED).entity("").build();
	    	}
        } catch (AccessDeniedException ex) {
        	logger.error("Error occurred::", ex);
        	return Response.status(Response.Status.FORBIDDEN).entity("").build();
        } catch (Exception ex) {
            logger.error("Error occurred:: ", ex);
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("").build();
        }
    }
    
    @Path("/getModuleResources")
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response getModuleResources(@QueryParam("mid") int moduleId) {
    	logger.debug("getModuleResources param moduleId = " + moduleId);
    	try {        	
        	if ( userLoginService.isLoggedIn() ) {
        		LoggedUser loggedUser = userLoginService.getLoggedUserUtil();
	    		logger.debug("logged user : " + loggedUser.toString());
	    		
            	String result = moduleService.getModuleResources(moduleId);
            	
            	return Response.ok(result, MediaType.APPLICATION_JSON).build();
        	}
        	else {
        		return Response.status(Response.Status.UNAUTHORIZED).entity("").build();
	    	}
        } catch (AccessDeniedException ex) {
        	logger.error("Error occurred::", ex);
        	return Response.status(Response.Status.FORBIDDEN).entity("").build();
        } catch (Exception ex) {
            logger.error("Error occurred:: ", ex);
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("").build();
        }
    }
    
    @Path("/getModuleAndVideos")
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response getModuleAndVideos(@QueryParam("mid") int moduleId) {
    	logger.debug("getModuleAndVideos param moduleId = " + moduleId);
    	try {        	
        	if ( userLoginService.isLoggedIn() ) {
        		LoggedUser loggedUser = userLoginService.getLoggedUserUtil();
	    		logger.debug("logged user : " + loggedUser.toString());
	    		
            	String result = moduleService.getModuleAndVideos(moduleId);
            	
            	return Response.ok(result, MediaType.APPLICATION_JSON).build();
        	}
        	else {
        		return Response.status(Response.Status.UNAUTHORIZED).entity("").build();
	    	}
        } catch (AccessDeniedException ex) {
        	logger.error("Error occurred::", ex);
        	return Response.status(Response.Status.FORBIDDEN).entity("").build();
        } catch (Exception ex) {
            logger.error("Error occurred:: ", ex);
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("").build();
        }
    }
    
    @Path("/resetpassword")
    @POST
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    @Produces(MediaType.TEXT_HTML)
    public Response resetPassword(@FormParam("username") String username,
    		@FormParam("password") String password, @FormParam("oldpassword") String oldpassword) {
    	logger.debug("resetPassword username = " + username + " , password = " + password + " , oldpassword = " + oldpassword);
		try {
			if ( userLoginService.isLoggedIn() ) {
				LoggedUser loggedUser = userLoginService.getLoggedUserUtil();
				logger.debug("logged user : " + loggedUser.toString());
				
				if (oldpassword.equals(password)) {
					return Response.ok("same").build();
				}
				else if (oldpassword != "") {
					if (loggedUser.getPassword().equals(oldpassword)) {
						moduleService.updateUserPassword(loggedUser.getId(), password);
						userLoginService.logout();
					
						return Response.ok("logout").build();
					}
					else {
						return Response.ok("wrong").build();
					}
				}
				//else if (username != "" && loggedUser.getUsername().equals(username)){
				//	moduleService.updateUserPassword(loggedUser.getId(), password);
				//	userLoginService.logout();
					
				//	return Response.ok("logout").build();
				//}
				return Response.ok("unreset").build();
			}
        	else {
        		return Response.status(Response.Status.UNAUTHORIZED).entity("").build();
	    	}
		} catch (AccessDeniedException ex) {
        	logger.error("Error occurred::", ex);
        	return Response.status(Response.Status.FORBIDDEN).entity("").build();
        } catch (Exception ex) {
            logger.error("Error occurred:: ", ex);
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("").build();
        }
    }
    
    @Path("/getLoginUser")
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response getLoginUser() {
    	logger.debug("getLoginUser");
    	try {        	
        	if ( userLoginService.isLoggedIn() ) {
        		LoggedUser loggedUser = userLoginService.getLoggedUserUtil();
	    		logger.debug("logged user : " + loggedUser.toString());
	    		
	    		int processPayment = moduleService.getProcessPayment();
	    		
	    		SimpleUser sUser = new SimpleUser(loggedUser, true, processPayment);
            	return Response.ok(new GsonBuilder().serializeNulls().create().toJson(sUser), MediaType.APPLICATION_JSON).build();
        	}
        	else {
        		return Response.status(Response.Status.UNAUTHORIZED).entity("").build();
	    	}
        } catch (AccessDeniedException ex) {
        	logger.error("Error occurred::", ex);
        	return Response.status(Response.Status.FORBIDDEN).entity("").build();
        } catch (Exception ex) {
            logger.error("Error occurred:: ", ex);
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("").build();
        }
    }
    
    @Path("/getUser")
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response getUser() {
    	logger.debug("getUser");
    	try {        	
        	if ( userLoginService.isLoggedIn() ) {
        		LoggedUser loggedUser = userLoginService.getLoggedUserUtil();
	    		logger.debug("logged user : " + loggedUser.toString());
	    		            	
	    		String result = moduleService.getUser(loggedUser.getId());
	    		
            	return Response.ok(result, MediaType.APPLICATION_JSON).build();
        	}
        	else {
        		return Response.status(Response.Status.UNAUTHORIZED).entity("").build();
	    	}
        } catch (AccessDeniedException ex) {
        	logger.error("Error occurred::", ex);
        	return Response.status(Response.Status.FORBIDDEN).entity("").build();
        } catch (Exception ex) {
            logger.error("Error occurred:: ", ex);
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("").build();
        }
    }
        
    
    @Path("/getUserAddress")
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response getUserAddress() {
    	logger.debug("getUserAddress");
    	try {        	
        	if ( userLoginService.isLoggedIn() ) {
        		LoggedUser loggedUser = userLoginService.getLoggedUserUtil();
	    		logger.debug("logged user : " + loggedUser.toString());
	    		
	    		Integer primaryAddressId = moduleService.getUserPrimaryAddressId(loggedUser.getId());
	    		if (primaryAddressId != null) {
	    			String result = moduleService.getUserAddress(primaryAddressId);
	    			return Response.ok(result, MediaType.APPLICATION_JSON).build();
	    		}     	
	    		return Response.status(Response.Status.NOT_FOUND).entity("").build();
        	}
        	else {
        		return Response.status(Response.Status.UNAUTHORIZED).entity("").build();
	    	}
        } catch (AccessDeniedException ex) {
        	logger.error("Error occurred::", ex);
        	return Response.status(Response.Status.FORBIDDEN).entity("").build();
        } catch (Exception ex) {
            logger.error("Error occurred:: ", ex);
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("").build();
        }
    }
    
    @Path("/getUserBillingAddress")
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response getUserBillingAddress() {
    	logger.debug("getUserBillingAddress");
    	try {        	
        	if ( userLoginService.isLoggedIn() ) {
        		LoggedUser loggedUser = userLoginService.getLoggedUserUtil();
	    		logger.debug("logged user : " + loggedUser.toString());
	    		
	    		Integer billingAddressId = moduleService.getUserBillingAddressId(loggedUser.getId());
	    		if (billingAddressId != null) {
	    			String result = moduleService.getUserAddress(billingAddressId);
	    			return Response.ok(result, MediaType.APPLICATION_JSON).build();
	    		}     	
	    		return Response.status(Response.Status.NOT_FOUND).entity("").build();
        	}
        	else {
        		return Response.status(Response.Status.UNAUTHORIZED).entity("").build();
	    	}
        } catch (AccessDeniedException ex) {
        	logger.error("Error occurred::", ex);
        	return Response.status(Response.Status.FORBIDDEN).entity("").build();
        } catch (Exception ex) {
            logger.error("Error occurred:: ", ex);
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("").build();
        }
    }
    
    @Path("/getUserShippingAddress")
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response getUserShippingAddress() {
    	logger.debug("getUserShippingAddress");
    	try {        	
        	if ( userLoginService.isLoggedIn() ) {
        		LoggedUser loggedUser = userLoginService.getLoggedUserUtil();
	    		logger.debug("logged user : " + loggedUser.toString());
	    		
	    		Integer shippingAddressId = moduleService.getUserShippingAddressId(loggedUser.getId());
	    		if (shippingAddressId != null) {
	    			String result = moduleService.getUserAddress(shippingAddressId);
	    			return Response.ok(result, MediaType.APPLICATION_JSON).build();
	    		}     	
	    		return Response.status(Response.Status.NOT_FOUND).entity("").build();
        	}
        	else {
        		return Response.status(Response.Status.UNAUTHORIZED).entity("").build();
	    	}
        } catch (AccessDeniedException ex) {
        	logger.error("Error occurred::", ex);
        	return Response.status(Response.Status.FORBIDDEN).entity("").build();
        } catch (Exception ex) {
            logger.error("Error occurred:: ", ex);
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("").build();
        }
    }
    
    /*
    @Path("/updateUserAddress")
    @POST
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    @Produces(MediaType.TEXT_HTML)
    public Response updateUserAddress(@DefaultValue("") @FormParam("streetAddress") String streetAddress,
    		@DefaultValue("") @FormParam("city") String city,
    		@DefaultValue("") @FormParam("state") String state,
    		@DefaultValue("") @FormParam("county") String county,
    		@DefaultValue("") @FormParam("country") String country,
    		@DefaultValue("") @FormParam("zipCode") String zipCode) {
    	logger.debug("updateUserAddress params streetAddress = " + streetAddress 
    			+ " , city = " + city + " , state = " + state + " , county = " 
    			+ county + " , country = " + country + " , zipCode = " + zipCode);
		try {
			if ( userLoginService.isLoggedIn() ) {
				LoggedUser loggedUser = userLoginService.getLoggedUserUtil();
				logger.debug("logged user : " + loggedUser.toString());
				
				String result = null;
				result = moduleService.addOrUpdateAddress(loggedUser.getId(), loggedUser.getPrimaryAddressId(), streetAddress, 
							city, county, state, country, zipCode);
				
				return Response.ok(result, MediaType.APPLICATION_JSON).build();
			}
        	else {
        		return Response.status(Response.Status.UNAUTHORIZED).entity("").build();
	    	}
		} catch (AccessDeniedException ex) {
        	logger.error("Error occurred::", ex);
        	return Response.status(Response.Status.FORBIDDEN).entity("").build();
        } catch (Exception ex) {
            logger.error("Error occurred:: ", ex);
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("").build();
        }
    }*/
    
    @Path("/updateSecurityQuestionsAndAnswers")
    @POST
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	@Produces(MediaType.TEXT_HTML)
    public Response updateSecurityQuestionsAndAnswers(
    		@DefaultValue("1") @FormParam("recovery1") int recovery1,
    		@DefaultValue("1") @FormParam("recovery2") int recovery2,
    		@DefaultValue("") @FormParam("answer1") String answer1,
    		@DefaultValue("") @FormParam("answer2") String answer2) {
    	
    	try {
			if ( userLoginService.isLoggedIn() ) {
				LoggedUser loggedUser = userLoginService.getLoggedUserUtil();
				logger.debug("logged user : " + loggedUser.toString());
			
				String result = moduleService.addOrUpdateSecurityQuestionsAndAnsers(loggedUser.getId(), recovery1, recovery2, answer1, answer2);
				return Response.ok(result, MediaType.APPLICATION_JSON).build();
			}
			else {
				return Response.status(Response.Status.UNAUTHORIZED).entity("").build();
			}
		} catch (AccessDeniedException ex) {
			logger.error("Error occurred::", ex);
			return Response.status(Response.Status.FORBIDDEN).entity("").build();
		} catch (Exception ex) {
		    logger.error("Error occurred:: ", ex);
		    return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("").build();
		}
    }
    
    @Path("/updateProfile")
    @POST
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	@Produces(MediaType.APPLICATION_JSON)
    public Response updateProfile(
    		@DefaultValue("") @FormParam("prefix") String prefix,
    		@DefaultValue("") @FormParam("firstName") String firstName,
    		@DefaultValue("") @FormParam("middleName") String middleName,
    		@DefaultValue("") @FormParam("lastName") String lastName,
    		@DefaultValue("") @FormParam("educationLevel") String educationLevel,
    		@DefaultValue("") @FormParam("email") String email,
    		@DefaultValue("") @FormParam("userName") String userName,
    		@DefaultValue("6") @FormParam("occupationalTitleId") int occupationalTitleId,
    		@DefaultValue("") @FormParam("otherOccupationalTitle") String otherOccupationalTitle,
    		@DefaultValue("1") @FormParam("registrationtypeId") byte registrationtypeId,
    		@DefaultValue("") @FormParam("phone") String phone,
    		@DefaultValue("") @FormParam("schoolName") String schoolName,
    		@DefaultValue("true") @FormParam("emailNotification") boolean emailNotification,
    		@DefaultValue("") @FormParam("streetAddress") String streetAddress,
    		@DefaultValue("") @FormParam("city") String city,
    		@DefaultValue("") @FormParam("state") String state,
    		@DefaultValue("") @FormParam("county") String county,
    		@DefaultValue("") @FormParam("country") String country,
    		@DefaultValue("") @FormParam("zipCode") String zipCode) {
    	logger.debug("updateProfile params firstName = " + firstName + " , lastName = " + lastName + " , prefix = " + prefix
    			+ " , middleName = " + middleName + " , educationLevel = " + educationLevel + " , email = " 
    			+ email + " , userName = " + userName + " , occupationalTitleId = " + occupationalTitleId + " , schoolName = " + schoolName
    			+ " , otherOccupationalTitle = " + otherOccupationalTitle + " , phone = " + phone + " , emailNotification = " + emailNotification);
		
    	logger.debug("updateProfile params streetAddress = " + streetAddress 
    			+ " , city = " + city + " , state = " + state + " , county = " 
    			+ county + " , country = " + country + " , zipCode = " + zipCode);
    	try {
			if ( userLoginService.isLoggedIn() ) {
				LoggedUser loggedUser = userLoginService.getLoggedUserUtil();
				logger.debug("logged user : " + loggedUser.toString());
				
				if ( !RegularExpressionUtil.checkEmailPattern(email) ) {
	        		return Response.status(Response.Status.BAD_REQUEST).entity("email pattern").build();
	        	}
	        	
	        	if ( !RegularExpressionUtil.checkUsernamePattern(userName) ) {
	        		return Response.status(Response.Status.BAD_REQUEST).entity("username pattern").build();
	        	}
	        	
	        	if (!loggedUser.getEmail().equalsIgnoreCase(email)) {
	        		if ( userService.checkEmail(email).equalsIgnoreCase("false")) {
	        			return Response.status(Response.Status.BAD_REQUEST).entity("email duplicate").build();
	        		}
	        	}
	        	
	        	if (!loggedUser.getUsername().equalsIgnoreCase(userName)) {
	        		if ( userService.checkUserName(userName).equalsIgnoreCase("false")) {
	        			return Response.status(Response.Status.BAD_REQUEST).entity("username duplicate").build();
	        		}
	        	}
	    		
	        	Integer primaryAddressId = moduleService.getUserPrimaryAddressId(loggedUser.getId());
	        	moduleService.addOrUpdateAddress(loggedUser.getId(), primaryAddressId, streetAddress, 
						city, county, state, country, zipCode);
	        	
	        	String result = moduleService.updateUser(loggedUser.getId(), prefix, firstName.trim(), middleName.trim(), lastName.trim(),
						email.trim(), userName.trim(), educationLevel, occupationalTitleId, otherOccupationalTitle, phone, emailNotification, registrationtypeId, 
						schoolName);
				
				userLoginService.login(userName, loggedUser.getPassword());
	        	
				return Response.ok(result, MediaType.APPLICATION_JSON).build();
			}
        	else {
        		return Response.status(Response.Status.UNAUTHORIZED).entity("").build();
	    	}
		} catch (AccessDeniedException ex) {
        	logger.error("Error occurred::", ex);
        	return Response.status(Response.Status.FORBIDDEN).entity("").build();
        } catch (Exception ex) {
            logger.error("Error occurred:: ", ex);
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("").build();
        }
    }
    
    
    @Path("/getAllModulesAndVideos")
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response getAllModulesAndVideos() {
        try {        	
        	if ( userLoginService.isLoggedIn() ) {
	    		LoggedUser loggedUser = userLoginService.getLoggedUserUtil();
	    		logger.debug("getAllModulesAndVideos logged user : " + loggedUser.toString());
	    		
	    		String result = moduleService.getAllModulesOrderBySequenceAndVideos();
	    		
	    		return Response.ok(result, MediaType.APPLICATION_JSON).build();
	    	}
        	else {
        		return Response.status(Response.Status.UNAUTHORIZED).entity("").build();
	    	}
        } catch (AccessDeniedException ex) {
        	logger.error("Error occurred::", ex);
        	return Response.status(Response.Status.FORBIDDEN).entity("").build();
        } catch (Exception ex) {
            logger.error("Error occurred:: ", ex);
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("").build();
        }
    }
    
    
    @Path("/allmodules")
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response getAllModules() {
        try {        	
        	if ( userLoginService.isLoggedIn() ) {
	    		LoggedUser loggedUser = userLoginService.getLoggedUserUtil();
	    		logger.debug("getAllModules logged user : " + loggedUser.toString());
	            
	    		String result = moduleService.getAllModules();
	
	    		return Response.ok(result, MediaType.APPLICATION_JSON).build();
	    	}
	    	else {
	    		return Response.status(Response.Status.UNAUTHORIZED).entity("").build();
	    	}
	    } catch (AccessDeniedException ex) {
	    	logger.error("Error occurred::", ex);
	    	return Response.status(Response.Status.FORBIDDEN).entity("").build();
	    } catch (Exception ex) {
	        logger.error("Error occurred:: ", ex);
	        return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("").build();
	    }
    }
    
    @Path("/surveyquestions")
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response getSurveyQuestions() {
        try {        	
        	if ( userLoginService.isLoggedIn() ) {
	    		LoggedUser loggedUser = userLoginService.getLoggedUserUtil();
	    		logger.debug("getSurveyQuestions logged user : " + loggedUser.toString());
	            
	    		String result = moduleService.getSurveyQuestions();
	
	    		return Response.ok(result, MediaType.APPLICATION_JSON).build();
	    	}
	    	else {
	    		return Response.status(Response.Status.UNAUTHORIZED).entity("").build();
	    	}
	    } catch (AccessDeniedException ex) {
	    	logger.error("Error occurred::", ex);
	    	return Response.status(Response.Status.FORBIDDEN).entity("").build();
	    } catch (Exception ex) {
	        logger.error("Error occurred:: ", ex);
	        return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("").build();
	    }
    }
    
    @Path("/getusercertificatetitles")
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response getUserCertificateTitles() {
        try {        	
        	if ( userLoginService.isLoggedIn() ) {
	    		LoggedUser loggedUser = userLoginService.getLoggedUserUtil();
	    		logger.debug("getUserCertificatesTitles logged user : " + loggedUser.toString());
	            
	    		String result = moduleService.getUserCertificateTitles(loggedUser.getId());
	
	    		return Response.ok(result, MediaType.APPLICATION_JSON).build();
	    	}
	    	else {
	    		return Response.status(Response.Status.UNAUTHORIZED).entity("").build();
	    	}
	    } catch (AccessDeniedException ex) {
	    	logger.error("Error occurred::", ex);
	    	return Response.status(Response.Status.FORBIDDEN).entity("").build();
	    } catch (Exception ex) {
	        logger.error("Error occurred:: ", ex);
	        return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("").build();
	    }
    }
    
    @Path("/getusermoduletesttranscripttitles")
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response getUserModuleTestTranscriptTitles() {
        try {        	
        	if ( userLoginService.isLoggedIn() ) {
	    		LoggedUser loggedUser = userLoginService.getLoggedUserUtil();
	    		logger.debug("getUserModuleTestTranscriptTitles logged user : " + loggedUser.toString());
	            
	    		String result = moduleService.getUserModuleTestTranscriptTitles(loggedUser.getId());
	
	    		return Response.ok(result, MediaType.APPLICATION_JSON).build();
	    	}
	    	else {
	    		return Response.status(Response.Status.UNAUTHORIZED).entity("").build();
	    	}
	    } catch (AccessDeniedException ex) {
	    	logger.error("Error occurred::", ex);
	    	return Response.status(Response.Status.FORBIDDEN).entity("").build();
	    } catch (Exception ex) {
	        logger.error("Error occurred:: ", ex);
	        return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("").build();
	    }
    }
    
    @Path("/getusermoduletestcertficatedetails")
    @GET
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    @Produces(MediaType.APPLICATION_OCTET_STREAM)
    public Response getUserModuleTestCertficateDetails(@QueryParam("testyear") String testyear,
    		@QueryParam("title") String title) {
    	logger.debug("getUserModuleTestCertficateDetails testyear = " + testyear + " , title = " + title);
        try {        	
        	if ( userLoginService.isLoggedIn() ) {
	    		LoggedUser loggedUser = userLoginService.getLoggedUserUtil();
	    		logger.debug("getUserModuleTestCertficateDetails logged user : " + loggedUser.toString());
	            
	    		String imagesPath = context.getRealPath("/images/"); // transcript-report-logo.png
	    		logger.debug("imagePath = " + imagesPath);
	    		String pathname = moduleService.getUserModuleTestCertificateDetails(loggedUser.getId(), loggedUser.getFirstName() + " " + loggedUser.getLastName(), title, testyear, imagesPath);
	    		
	    		File file = new File(pathname);
	    		logger.debug("file fullpath = " + pathname);
	    		
	    		if(file.exists()){
	    			ResponseBuilder responseBuilder = Response.ok(file);
	    			responseBuilder.header("Content-Disposition", "attachment; filename=\"" + title + " " + loggedUser.getId() + ".pdf\"");
		    		return responseBuilder.build();
	    		}
	    		else {
	    			return Response.status(Response.Status.NOT_FOUND).entity("").build();
	    		}
	    	}
	    	else {
	    		return Response.status(Response.Status.UNAUTHORIZED).entity("").build();
	    	}
	    } catch (AccessDeniedException ex) {
	    	logger.error("Error occurred::", ex);
	    	return Response.status(Response.Status.FORBIDDEN).entity("").build();
	    } catch (Exception ex) {
	        logger.error("Error occurred:: ", ex);
	        return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("").build();
	    }
    }
    
    @Path("/getusermoduletesttranscriptdetails")
    @GET
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    @Produces(MediaType.APPLICATION_OCTET_STREAM)
    public Response getUserModuleTestTranscriptDetails(@QueryParam("testyear") int testyear,
    		@QueryParam("title") String title) {
    	logger.debug("getUserModuleTestTranscriptDetails testyear = " + testyear + " , title = " + title);
        try {        	
        	if ( userLoginService.isLoggedIn() ) {
	    		LoggedUser loggedUser = userLoginService.getLoggedUserUtil();
	    		logger.debug("getUserModuleTestTranscriptDetails logged user : " + loggedUser.toString());
	            
	    		String imagesPath = context.getRealPath("/images/"); // transcript-report-logo.png
	    		logger.debug("imagePath = " + imagesPath);
	    		String pathname = moduleService.getUserModuleTestTranscriptDetails(loggedUser.getId(), loggedUser.getFirstName() + " " + loggedUser.getLastName(), title, testyear, imagesPath);
	    		
	    		File file = new File(pathname);
	    		logger.debug("file fullpath = " + pathname);
	    		
	    		if(file.exists()){
	    			ResponseBuilder responseBuilder = Response.ok(file);
	    			responseBuilder.header("Content-Disposition", "attachment; filename=\"" + title + " " + loggedUser.getId() + ".pdf\"");
		    		return responseBuilder.build();
	    		}
	    		else {
	    			return Response.status(Response.Status.NOT_FOUND).entity("").build();
	    		}
	    	}
	    	else {
	    		return Response.status(Response.Status.UNAUTHORIZED).entity("").build();
	    	}
	    } catch (AccessDeniedException ex) {
	    	logger.error("Error occurred::", ex);
	    	return Response.status(Response.Status.FORBIDDEN).entity("").build();
	    } catch (Exception ex) {
	        logger.error("Error occurred:: ", ex);
	        return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("").build();
	    }
    }
    
    @Path("/paymentProfile")
    @POST
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	@Produces(MediaType.APPLICATION_JSON)
    public Response paymentProfile(
    		@DefaultValue("") @FormParam("billingFullName") String billingFullName,
    		//@DefaultValue("") @FormParam("shippingFullName") String shippingFullName,
    		@DefaultValue("") @FormParam("cardNumber") String cardNumber,
    		@DefaultValue("1") @FormParam("expMonth") String expMonth,
    		@DefaultValue("2014") @FormParam("expYear") String expYear,
    		//@DefaultValue("") @FormParam("email") String email,
    		@DefaultValue("") @FormParam("cardSecurityCode") String cardSecurityCode,
    		//@DefaultValue("1") @FormParam("price") String price,
    		//@DefaultValue("1") @FormParam("tax") String tax,
    		//@DefaultValue("") @FormParam("phone") String phone,
    		@DefaultValue("") @FormParam("billingStreetAddress") String billingStreetAddress,
    		@DefaultValue("") @FormParam("billingCity") String billingCity,
    		@DefaultValue("") @FormParam("billingState") String billingState,
    		@DefaultValue("") @FormParam("billingCounty") String billingCounty,
    		@DefaultValue("") @FormParam("billingCountry") String billingCountry,
    		@DefaultValue("") @FormParam("billingZipCode") String billingZipCode) {
    		//@DefaultValue("") @FormParam("shippingStreetAddress") String shippingStreetAddress,
    		//@DefaultValue("") @FormParam("shippingCity") String shippingCity,
    		//@DefaultValue("") @FormParam("shippingState") String shippingState,
    		//@DefaultValue("") @FormParam("shippingCounty") String shippingCounty,
    		//@DefaultValue("") @FormParam("shippingCountry") String shippingCountry,
    		//@DefaultValue("") @FormParam("shippingZipCode") String shippingZipCode) {
    	logger.debug("payment params cardNumber = " + cardNumber + " , expMonth = " + expMonth
    			+ " , expYear = " + expYear + " , cardSecurityCode = " + cardSecurityCode);  
    	        // + " , email = " + email ); // + " , price = " + price + " , tax = " + tax + " , phone = " + phone
		// card number in log
    	logger.debug("payment params billingFullName = " + billingFullName + " , billingStreetAddress = " + billingStreetAddress 
    			+ " , billingCity = " + billingCity + " , billingState = " + billingState + " , billingCounty = " 
    			+ billingCounty + " , billingCountry = " + billingCountry + " , billingZipCode = " + billingZipCode);
    	
    	//logger.debug("payment params shippingFullName = " + shippingFullName + " , shippingStreetAddress = " + shippingStreetAddress 
    	//		+ " , shippingCity = " + shippingCity + " , shippingState = " + shippingState + " , shippingCounty = " 
    	//		+ shippingCounty + " , shippingCountry = " + shippingCountry + " , shippingZipCode = " + shippingZipCode);
    	
    	try {
			if ( userLoginService.isLoggedIn() ) {
				LoggedUser loggedUser = userLoginService.getLoggedUserUtil();
				logger.debug("logged user : " + loggedUser.toString());
				
	        	Integer billingAddressId = moduleService.getUserBillingAddressId(loggedUser.getId());
	        	moduleService.addOrUpdateBillingAddress(loggedUser.getId(), billingAddressId, billingStreetAddress, 
	        			billingCity, billingCounty, billingState, billingCountry, billingZipCode);
	        	
	        	//Integer shippingAddressId = moduleService.getUserShippingAddressId(loggedUser.getId());
	        	//moduleService.addOrUpdateShippingAddress(loggedUser.getId(), shippingAddressId, shippingStreetAddress, 
	        	//		shippingCity, shippingCounty, shippingState, shippingCountry, shippingZipCode);
	        	
	        	String result = moduleService.payRegistration(loggedUser.getId(), billingFullName, billingStreetAddress, 
        			billingCity, billingState, billingZipCode, loggedUser.getEmail(), cardNumber, expMonth + expYear, 
        			cardSecurityCode, billingCountry, "", "", "", "", "", ""); 
	        	// shippingStreetAddress, shippingCity, shippingState, shippingZipCode, shippingCountry phone
	        	
				return Response.ok(result, MediaType.APPLICATION_JSON).build();
			}
        	else {
        		return Response.status(Response.Status.UNAUTHORIZED).entity("").build();
	    	}
		} catch (AccessDeniedException ex) {
        	logger.error("Error occurred::", ex);
        	return Response.status(Response.Status.FORBIDDEN).entity("").build();
        } catch (Exception ex) {
            logger.error("Error occurred:: ", ex);
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("").build();
        }
    }
    
    @Path("/getconfig")
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response getConfig() {
        try {        	
        	if ( userLoginService.isLoggedIn() ) {
	    		LoggedUser loggedUser = userLoginService.getLoggedUserUtil();
	    		logger.debug("getConfig logged user : " + loggedUser.toString());
	            
	    		String result = moduleService.getConfigJson();
	
	    		return Response.ok(result, MediaType.APPLICATION_JSON).build();
	    	}
	    	else {
	    		return Response.status(Response.Status.UNAUTHORIZED).entity("").build();
	    	}
	    } catch (AccessDeniedException ex) {
	    	logger.error("Error occurred::", ex);
	    	return Response.status(Response.Status.FORBIDDEN).entity("").build();
	    } catch (Exception ex) {
	        logger.error("Error occurred:: ", ex);
	        return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("").build();
	    }
    }
    
    @Path("/getfullsimpleuser")
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response getFullSimpleUser() {
        try {        	
        	if ( userLoginService.isLoggedIn() ) {
	    		LoggedUser loggedUser = userLoginService.getLoggedUserUtil();
	    		logger.debug("getfullsimpleuser logged user : " + loggedUser.toString());
	            
	    		String result = moduleService.getFullSimpleUser(loggedUser.getId());
	
	    		return Response.ok(result, MediaType.APPLICATION_JSON).build();
	    	}
	    	else {
	    		return Response.status(Response.Status.UNAUTHORIZED).entity("").build();
	    	}
	    } catch (AccessDeniedException ex) {
	    	logger.error("Error occurred::", ex);
	    	return Response.status(Response.Status.FORBIDDEN).entity("").build();
	    } catch (Exception ex) {
	        logger.error("Error occurred:: ", ex);
	        return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("").build();
	    }
    }

}
