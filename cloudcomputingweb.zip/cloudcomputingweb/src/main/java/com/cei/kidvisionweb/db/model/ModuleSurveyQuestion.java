package com.cei.kidvisionweb.db.model;

import java.util.Date;

import org.apache.commons.lang3.builder.ToStringBuilder;

public class ModuleSurveyQuestion  implements java.io.Serializable {

     /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	private Integer id;
    private String question;
    private String subQuestion;
    private Integer sequence;
    private byte qtype;
    private byte deleted;
    private Date createdOn;
    private Integer createdBy;
    private Date modifiedOn;
    private Integer modifiedBy;

    public ModuleSurveyQuestion() {
    }

    public ModuleSurveyQuestion(String question, String subQuestion, Integer sequence, byte qtype, byte deleted) {
       this.question = question;
       this.subQuestion = subQuestion;
       this.sequence = sequence;
       this.qtype = qtype;
       this.deleted = deleted;
    }
   
    public Integer getId() {
        return this.id;
    }
    
    public void setId(Integer id) {
        this.id = id;
    }
    
    public String getQuestion() {
        return this.question;
    }
    
    public void setQuestion(String question) {
        this.question = question;
    }
    public Integer getSequence() {
        return this.sequence;
    }
    
    public void setSequence(Integer sequence) {
        this.sequence = sequence;
    }
    public byte getDeleted() {
        return this.deleted;
    }
    
    public void setDeleted(byte deleted) {
        this.deleted = deleted;
    }
    
    public String getSubQuestion() {
		return subQuestion;
	}

	public void setSubQuestion(String subQuestion) {
		this.subQuestion = subQuestion;
	}

	public byte getQtype() {
		return qtype;
	}

	public void setQtype(byte qtype) {
		this.qtype = qtype;
	}

	public Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public Integer getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}

	public Date getModifiedOn() {
		return modifiedOn;
	}

	public void setModifiedOn(Date modifiedOn) {
		this.modifiedOn = modifiedOn;
	}

	public Integer getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(Integer modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	@Override
    public String toString() {
        return new ToStringBuilder(this).append("id", id).
                append("question", question).
                append("subQuestion", subQuestion).
                append("sequence", sequence).
                append("qtype", qtype).
                append("deleted", deleted).
                append("createdOn", createdOn).
                append("createdBy", createdBy).
                append("updatedOn", modifiedOn).
                append("modifiedBy", modifiedBy).
                toString();
    }


}


