package com.cei.kidvisionweb.db.model;


import java.util.Date;

import org.apache.commons.lang3.builder.ToStringBuilder;

public class User implements java.io.Serializable {

	private Integer id;
    private String firstName;
    private String lastName;
    private String middleName;
    private String userName;
    private String password;
    private String email;
    private byte roleId;
    private Integer occupationalTitleId;
    private String otherOccupationalTitle;
    private Boolean emailNotification;
    private String phone;
    private String facilityType;
    private Byte registrationtypeId;
    private Integer currentRegistrationId;
    private Integer primaryAddressId;
    private Integer billingAddressId;
    private Integer shippingAddressId;
    private byte pretestCompleted;
    private Date createdOn;
    private Date updatedOn;
    private Integer createdbyId;
    private Integer updatedbyId;
    private short isActive;
    private short passwordReset;
    private String prefix;
    private String schoolName;

    private static final long serialVersionUID = 1L;

    public static long getSerialversionuid() {
        return serialVersionUID;
    }

    public User() {
    }

    public User(String firstName, String lastName, String userName, String password, String email, byte roleId, short isActive) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.userName = userName;
        this.password = password;
        this.email = email;
        this.roleId = roleId;
        this.isActive = isActive;
    }

    public User(String firstName, String lastName, String middleName, String userName, String password, String email, byte roleId, Integer occupationalTitleId, String otherOccupationalTitle, Boolean emailNotification, String phone, Byte registrationtypeId, Integer currentRegistrationId, Integer primaryAddressId, Integer billingAddressId, Integer shippingAddressId, byte pretestCompleted, Date createdOn, Date updatedOn, Integer createdbyId, Integer updatedbyId, short isActive) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.middleName = middleName;
        this.userName = userName;
        this.password = password;
        this.email = email;
        this.roleId = roleId;
        this.occupationalTitleId = occupationalTitleId;
        this.otherOccupationalTitle = otherOccupationalTitle;
        this.emailNotification = emailNotification;
        this.phone = phone;
        this.registrationtypeId = registrationtypeId;
        this.currentRegistrationId = currentRegistrationId;
        this.primaryAddressId = primaryAddressId;
        this.billingAddressId = billingAddressId;
        this.shippingAddressId = shippingAddressId;
        this.pretestCompleted = pretestCompleted;
        this.createdOn = createdOn;
        this.updatedOn = updatedOn;
        this.createdbyId = createdbyId;
        this.updatedbyId = updatedbyId;
        this.isActive = isActive;
    }

    public Integer getId() {
        return this.id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getFirstName() {
        return this.firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return this.lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getMiddleName() {
        return this.middleName;
    }

    public void setMiddleName(String middleName) {
        this.middleName = middleName;
    }

    public String getUserName() {
        return this.userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPassword() {
        return this.password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getEmail() {
        return this.email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public byte getRoleId() {
        return this.roleId;
    }

    public void setRoleId(byte roleId) {
        this.roleId = roleId;
    }

    public Integer getOccupationalTitleId() {
        return this.occupationalTitleId;
    }

    public void setOccupationalTitleId(Integer occupationalTitleId) {
        this.occupationalTitleId = occupationalTitleId;
    }

    public String getOtherOccupationalTitle() {
        return this.otherOccupationalTitle;
    }

    public void setOtherOccupationalTitle(String otherOccupationalTitle) {
        this.otherOccupationalTitle = otherOccupationalTitle;
    }

    public Boolean getEmailNotification() {
        return this.emailNotification;
    }

    public void setEmailNotification(Boolean emailNotification) {
        this.emailNotification = emailNotification;
    }

    public String getPhone() {
        return this.phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public Byte getRegistrationtypeId() {
        return this.registrationtypeId;
    }

    public void setRegistrationtypeId(Byte registrationtypeId) {
        this.registrationtypeId = registrationtypeId;
    }

    public Integer getCurrentRegistrationId() {
        return this.currentRegistrationId;
    }

    public void setCurrentRegistrationId(Integer currentRegistrationId) {
        this.currentRegistrationId = currentRegistrationId;
    }

    public Integer getPrimaryAddressId() {
        return this.primaryAddressId;
    }

    public void setPrimaryAddressId(Integer primaryAddressId) {
        this.primaryAddressId = primaryAddressId;
    }

    public Integer getBillingAddressId() {
        return this.billingAddressId;
    }

    public void setBillingAddressId(Integer billingAddressId) {
        this.billingAddressId = billingAddressId;
    }

    public Integer getShippingAddressId() {
        return this.shippingAddressId;
    }

    public void setShippingAddressId(Integer shippingAddressId) {
        this.shippingAddressId = shippingAddressId;
    }

    public byte getPretestCompleted() {
		return pretestCompleted;
	}

	public Date getCreatedOn() {
        return this.createdOn;
    }

    public void setCreatedOn(Date createdOn) {
        this.createdOn = createdOn;
    }

    public Date getUpdatedOn() {
        return this.updatedOn;
    }

    public void setUpdatedOn(Date updatedOn) {
        this.updatedOn = updatedOn;
    }

    public Integer getCreatedbyId() {
        return this.createdbyId;
    }

    public void setCreatedbyId(Integer createdbyId) {
        this.createdbyId = createdbyId;
    }

    public Integer getUpdatedbyId() {
        return this.updatedbyId;
    }

    public void setUpdatedbyId(Integer updatedbyId) {
        this.updatedbyId = updatedbyId;
    }

    public String getFacilityType() {
		return facilityType;
	}

	public void setFacilityType(String facilityType) {
		this.facilityType = facilityType;
	}

	public void setPretestCompleted(byte pretestCompleted) {
		this.pretestCompleted = pretestCompleted;
	}

	public short getIsActive() {
        return this.isActive;
    }

    public void setIsActive(short isActive) {
        this.isActive = isActive;
    }
    
    public short getPasswordReset() {
		return passwordReset;
	}

	public void setPasswordReset(short passwordReset) {
		this.passwordReset = passwordReset;
	}

	public String getPrefix() {
		return prefix;
	}

	public void setPrefix(String prefix) {
		this.prefix = prefix;
	}
	
	public String getSchoolName() {
		return schoolName;
	}

	public void setSchoolName(String schoolName) {
		this.schoolName = schoolName;
	}

	@Override
    public String toString() {
        return new ToStringBuilder(this).append("id", id).
                append("firstName", firstName).
                append("lastName", lastName).
                append("middleName", middleName).
                append("userName", userName).
                append("password", password).
                append("email", email).
                append("roleId", Integer.toString(roleId)).
                append("occupationalTitleId", occupationalTitleId).
                append("otherOccupationalTitle", otherOccupationalTitle).
                append("emailNotification", emailNotification).
                append("phone", phone).
                append("isActive", isActive).
                append("facilityType", facilityType).
                append("roleId", roleId).
                append("registrationtypeId", registrationtypeId).
                append("currentRegistrationId", currentRegistrationId).
                append("primaryAddressId", primaryAddressId).
                append("billingAddressId", billingAddressId).
                append("shippingAddressId", shippingAddressId).
                append("pretestCompleted", pretestCompleted).
                append("createdOn", createdOn).
                append("updatedOn", updatedOn).
                append("createdbyId", createdbyId).
                append("updatedbyId", updatedbyId).
                append("passwordReset", passwordReset).
                append("tempPassword", prefix).
                append("schoolName", schoolName).
                toString();
    }
}


