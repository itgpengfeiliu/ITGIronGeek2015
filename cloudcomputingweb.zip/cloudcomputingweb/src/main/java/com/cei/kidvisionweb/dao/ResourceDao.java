package com.cei.kidvisionweb.dao;

import java.util.List;

import com.cei.kidvisionweb.db.model.Resource;

public interface ResourceDao extends GenericDao<Resource, Long> {

	List<Resource> getModuleResources(int moduleId);
	
}
