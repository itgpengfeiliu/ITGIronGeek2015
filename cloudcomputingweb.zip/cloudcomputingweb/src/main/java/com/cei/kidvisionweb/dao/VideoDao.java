package com.cei.kidvisionweb.dao;

import java.util.List;

import com.cei.kidvisionweb.db.model.Video;

/**
 *
 * @author Shrikant
 */
public interface VideoDao extends GenericDao<Video, Long> {

//    void add(Video object);
//
//    void update(Video object);
//
//    void delete(Video object);

	List<Video> getVideoWithoutStreamingId();
}
