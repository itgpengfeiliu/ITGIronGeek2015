

package com.cei.kidvisionweb.dao.impl;

import java.util.List;

import com.cei.kidvisionweb.dao.StandardDao;
import com.cei.kidvisionweb.db.model.Standard;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author Shrikant
 */
public class StandardDaoImpl extends GenericDaoImpl<Standard, Long> implements StandardDao{
    
	private static Logger logger = LoggerFactory.getLogger(StandardDaoImpl.class);
    
    @Override
	@SuppressWarnings("unchecked")
	public List<Standard> getModuleStandsByOrder(int moduleId) {
		List<Standard> standards = null;
		try {
			standards = getSession().createQuery("from "
	      			+ getPersistentClass().getName()
	      			+ " where moduleId=" + moduleId + " order by standardNo").list();
		} catch (Exception ex) {
			logger.error("Error occurred::", ex);
		}
		return standards;
	}
    
}
