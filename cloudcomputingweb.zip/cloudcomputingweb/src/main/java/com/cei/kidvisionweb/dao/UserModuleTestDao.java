package com.cei.kidvisionweb.dao;

import java.util.List;

import com.cei.kidvisionweb.db.model.UserModuleTest;
import com.cei.kidvisionweb.db.model.UserModuleTestTranscriptDetail;
import com.cei.kidvisionweb.db.model.UserModuleTestTranscriptTitle;


public interface UserModuleTestDao extends GenericDao<UserModuleTest, Long> {

	List<UserModuleTestTranscriptDetail> getTranscriptDetails(int userId, int testYear);
	
	List<UserModuleTestTranscriptTitle> getTranscriptTitles(int userId);
	
	List<UserModuleTest> getUserModuleTests(int userId, int moduleId);
}
