package com.cei.kidvisionweb.dao.impl;

import com.cei.kidvisionweb.dao.ModuleCategoryDao;
import com.cei.kidvisionweb.db.model.ModuleCategorie;

public class ModuleCategoryDaoImpl extends GenericDaoImpl<ModuleCategorie, Long> implements ModuleCategoryDao {

}
