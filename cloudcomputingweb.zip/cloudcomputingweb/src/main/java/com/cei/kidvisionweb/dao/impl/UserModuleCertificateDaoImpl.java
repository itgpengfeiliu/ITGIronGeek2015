

package com.cei.kidvisionweb.dao.impl;

import com.cei.kidvisionweb.dao.UserModuleCertificateDao;
import com.cei.kidvisionweb.db.model.UserModuleCertificate;
import org.hibernate.Query;

/**
 *
 * @author Shrikant
 */
public class UserModuleCertificateDaoImpl extends GenericDaoImpl<UserModuleCertificate, Long> implements UserModuleCertificateDao{
    
    @Override
    public void deleteById(String id) {
        StringBuffer hql = new StringBuffer(
                "delete from "
                + getPersistentClass().getName() + " as model where id="
                + id);
        Query query = getSession().createQuery(hql.toString());
        query.executeUpdate();
    }
}
