

package com.cei.kidvisionweb.dao;

import java.io.Serializable;
import java.util.List;

/**
 *
 * @author Shrikant
 */
public interface GenericDao<T, ID extends Serializable> {

    void add(T obj);

    void delete(T obj);

    void deleteById(Integer id);

    void update(T obj);

    void merge(T obj);
    
    T get(Serializable id);

    T getByProperties(String... strs);

    T getUniqueByProperty(String pName, Object pValue);

    List<T> getList();

    List<T> getListByProperty(String pName, Object pValue);

    List<T> getListByProperties(String... strs);

    List<T> getListOrderByProperty(String pName);

    void deleteByProperty(String propertyName, Object value);
}
