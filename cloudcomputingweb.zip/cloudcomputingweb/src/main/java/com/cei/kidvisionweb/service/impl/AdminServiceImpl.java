package com.cei.kidvisionweb.service.impl;

import com.cei.kidvisionweb.service.AdminService;
import com.cei.kidvisionweb.service.util.SimpleUser;
import com.cei.kidvisionweb.config.KidvisionWebConfig;
import com.cei.kidvisionweb.dao.AddressDao;
import com.cei.kidvisionweb.dao.ConfigDao;
import com.cei.kidvisionweb.dao.ModuleDao;
import com.cei.kidvisionweb.dao.ModuleResourceDao;
import com.cei.kidvisionweb.dao.QuestionDao;
import com.cei.kidvisionweb.dao.AnswerDao;
import com.cei.kidvisionweb.dao.RegistrationDao;
import com.cei.kidvisionweb.dao.ResourceDao;
import com.cei.kidvisionweb.dao.StandardDao;
import com.cei.kidvisionweb.dao.SurveyQuestionDao;
import com.cei.kidvisionweb.dao.SurveyResultDao;
import com.cei.kidvisionweb.dao.UserDao;
import com.cei.kidvisionweb.dao.UserModuleActivityDao;
import com.cei.kidvisionweb.dao.UserModuleSurveyAnswerDao;
import com.cei.kidvisionweb.dao.UserModuleTestAnswerDao;
import com.cei.kidvisionweb.dao.UserModuleTestDao;
import com.cei.kidvisionweb.dao.UserPretestAnswerDao;
import com.cei.kidvisionweb.dao.UserSurveyAnswerDao;
import com.cei.kidvisionweb.dao.VideoDao;
import com.cei.kidvisionweb.db.model.Address;
import com.cei.kidvisionweb.db.model.Answer;
import com.cei.kidvisionweb.db.model.Config;
import com.cei.kidvisionweb.db.model.Module;
import com.cei.kidvisionweb.db.model.ModuleResource;
import com.cei.kidvisionweb.db.model.Question;
import com.cei.kidvisionweb.db.model.Registration;
import com.cei.kidvisionweb.db.model.Resource;
import com.cei.kidvisionweb.db.model.Standard;
import com.cei.kidvisionweb.db.model.SurveyQuestion;
import com.cei.kidvisionweb.db.model.SurveyResult;
import com.cei.kidvisionweb.db.model.User;
import com.cei.kidvisionweb.db.model.UserDatatable;
import com.cei.kidvisionweb.db.model.UserModuleActivityFieldtripDatatable;
import com.cei.kidvisionweb.db.model.UserModuleSurveyAnswerResult;
import com.cei.kidvisionweb.db.model.UserSurveyAnswerResult;
import com.cei.kidvisionweb.db.model.UsersByCountyState;
import com.cei.kidvisionweb.db.model.Video;
import com.google.api.services.youtube.model.PlaylistItem;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;

import java.io.File;
import java.io.FileWriter;
import java.math.BigInteger;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.TransactionTemplate;
import org.springframework.util.Assert;

public class AdminServiceImpl implements AdminService {
	
	private static Logger logger = LoggerFactory.getLogger(AdminServiceImpl.class);
    private final TransactionTemplate transactionTemplate;
    @Autowired
    private AddressDao addressDao;
    @Autowired
    private UserDao userDao;
    @Autowired
    private ModuleDao moduleDao;
    @Autowired
    private VideoDao videoDao;
    @Autowired
    private StandardDao standardDao;
    @Autowired
    private QuestionDao questionDao;
    @Autowired
    private AnswerDao answerDao;
    @Autowired
    private UserModuleActivityDao userModuleActivityDao;
    @Autowired
    private UserModuleTestDao userModuleTestDao;
    @Autowired
    private UserPretestAnswerDao userPretestAnswerDao;
    @Autowired
    private UserModuleTestAnswerDao userModuleTestAnswerDao;
    @Autowired
    private SurveyQuestionDao surveyQuestionDao;
    @Autowired
    private SurveyResultDao surveyResultDao;
    @Autowired
    private ResourceDao resourceDao;
    @Autowired
    private ModuleResourceDao moduleResourceDao;
    @Autowired
    private UserSurveyAnswerDao userSurveyAnswerDao;
    @Autowired
    private RegistrationDao registrationDao;
    @Autowired
    private ConfigDao configDao;
    @Autowired
    private UserModuleSurveyAnswerDao userModuleSurveyAnswerDao;
    
    @Autowired
    public AdminServiceImpl( PlatformTransactionManager transactionManager) {
        Assert.notNull(transactionManager, "The 'transactionManager' argument must not be null.");
        this.transactionTemplate = new TransactionTemplate(transactionManager);
        this.transactionTemplate.setPropagationBehavior(TransactionDefinition.PROPAGATION_REQUIRES_NEW);
        this.transactionTemplate.setTimeout(30);
        logger.debug("transaction template = " + transactionTemplate);
    }
    
    @Override
    @Transactional
    @PreAuthorize("hasAnyRole('Administrator')")
    public String getNewRegistrationUsers(String starttime, String endtime) throws AccessDeniedException {
    	String result = null;
        try {
        	List<UserDatatable> users = userDao.getNewRegistrationUsers(starttime, endtime);
            result = new GsonBuilder().serializeNulls().create().toJson(users);
            logger.debug("getNewRegistrationUsers result: " + users.size());
        } 
        catch (Exception ex) {
            logger.error("Error occurred::", ex);
        }
        return result;
    }
    
    @Override
    @Transactional
    @PreAuthorize("hasAnyRole('Administrator')")
    public String updateModuleQuestionAnswer(int aid, String answer, short correct, Integer sequence) throws AccessDeniedException {
        String result = null;
        try {
        	Answer a = answerDao.get(aid);
        	if (a != null) {
        		a.setAnswerValue(answer);
        		a.setCorrect(correct);
        		a.setSequence(sequence);
        		answerDao.add(a);
        		result = a.getId().toString();
        		logger.debug("updateModuleQuestionAnswer result: " + a.toString());
        	}
        } 
        catch (Exception ex) {
            logger.error("Error occurred::", ex);
        }
        return result;
    }
    
    @Override
    @Transactional
    @PreAuthorize("hasAnyRole('Administrator')")
    public int updateModuleQuestion(int questionId, String question, int sequence, int standardId) throws AccessDeniedException {
        int result = -1;
        try {
        	Question q = questionDao.get(questionId);
        	if (q != null) {
        		q.setQuestion(question);
        		q.setSequence(sequence);
        		q.setStandardId(standardId);
        		questionDao.update(q);
        		result = q.getId();
        		logger.debug("updateModuleQuestion result: " + q.toString());
        	}
        } 
        catch (Exception ex) {
            logger.error("Error occurred::", ex);
        }
        return result;
    }
        
    @Override
    @Transactional
    @PreAuthorize("hasAnyRole('Administrator')")
    public String updateModuleClassroomMaterials(int userId, int moduleId,
    		String lessionPlanFileName, String assessmentFileName, String takeHomeFileName) throws AccessDeniedException {
        String result = null;
        try {
        	Module module = moduleDao.get(moduleId);
        	if (module != null) {
        		module.setUpdatedOn(new Date());
        		module.setModifiedbyId(userId);
        		
        		if (lessionPlanFileName != null) {
        			module.setPdfLessonPlan(lessionPlanFileName);
        		}
        		
        		if (assessmentFileName != null) {
        			module.setStudentAssessmentForm(assessmentFileName);
        		}
        		
        		if (takeHomeFileName != null) {
        			module.setColoringWorksheets(takeHomeFileName);
        		}
        		
        		moduleDao.update(module);
        		result = new GsonBuilder().serializeNulls().create().toJson(module);
        		logger.debug("updateModuleClassroomMaterials result: " + result);
        	}
        } 
        catch (Exception ex) {
            logger.error("Error occurred::", ex);
        }
        return result;
    }
    
    @Override
    @Transactional
    @PreAuthorize("hasAnyRole('Administrator')")
    public String triggerUser(int adminUserId, int userId) throws AccessDeniedException {
        String result = null;
        try {
        	User user = userDao.get(userId);
        	if (user != null) {
                        logger.info("user isActvie status: " + user.getIsActive());
        		user.setIsActive( (user.getIsActive() == 0) ? (byte) 1 : (byte) 0 );
        		user.setUpdatedbyId(adminUserId);
        		user.setUpdatedOn(new Date());
        		
        		userDao.update(user);
                        logger.info("user isActvie status changed to: " + user.getIsActive());
        		result = new GsonBuilder().serializeNulls().create().toJson(user);
        		logger.debug("triggerUser result: " + user.toString());
        	}
        } 
        catch (Exception ex) {
            logger.error("Error occurred::", ex);
        }
        return result;
    }
    
    @Override
    @Transactional
    @PreAuthorize("hasAnyRole('Administrator')")
    public String triggerUserPaid(int adminUserId, int userId, short isPaid) throws AccessDeniedException {
        String result = null;
        try {
        	List<Config> msgs = configDao.getListOrderByProperty("currentSchoolYearFrom");
        	Config config = msgs.get(0);
			Registration registration = registrationDao.getRegistrationByConfig(userId, config.getCurrentSchoolYearFrom());
      	    
        	if (registration != null) {
        		if (isPaid == 0 && registration.getIsPaid() == 1
        				&& registration.getCardLastFour().equalsIgnoreCase("0000")) {
        			registration.setIsPaid(isPaid);
        			registration.setCardFullName(null);
	        		registration.setCardLastFour(null);
	        		registration.setCardExp(null);
	        		registration.setSagePaymentDatetime(new Date());
	        		registration.setModifiedbyId(adminUserId);
	        		registration.setModifiedonDatetime(new Date());
        		}
        		else if (isPaid == 1 && registration.getIsPaid() != 1){
	        		registration.setIsPaid(isPaid);
	        		registration.setCardFullName("0000");
	        		registration.setCardLastFour("0000");
	        		registration.setCardExp("0000");
	        		registration.setSagePaymentDatetime(new Date());
	        		registration.setModifiedbyId(adminUserId);
	        		registration.setModifiedonDatetime(new Date());
	        		
	        		User user = userDao.get(userId);
	        		user.setRegistrationtypeId((byte)2);
	        		user.setCurrentRegistrationId(registration.getId());
	        		userDao.update(user);
        		}
        		
                registrationDao.update(registration);
        	}
        	else {
        		if (isPaid == 1) {
	    			registration = new Registration();
	        		registration.setUserId(userId);
	        		registration.setCreatedonDatetime(new Date());
	        		registration.setIsActive(true);
	        		registration.setCreatedbyId(adminUserId);
	        		registration.setFromDatetime(config.getCurrentSchoolYearFrom());
	        		registration.setToDatetime(config.getCurrentSchoolYearTo());
	        		
	        		registration.setIsPaid(isPaid);
	        		registration.setCardFullName("0000");
	        		registration.setCardLastFour("0000");
	        		registration.setCardExp("0000");
	        		registration.setSagePaymentDatetime(new Date());
	        		registrationDao.add(registration);
	        		
	        		User user = userDao.get(userId);
	        		user.setRegistrationtypeId((byte)2);
	        		user.setCurrentRegistrationId(registration.getId());
	        		userDao.update(user);
        		}
        		
        	}
        	result = new GsonBuilder().serializeNulls().create().toJson(registration);
    		logger.debug("triggerUser result: " + result);
        } 
        catch (Exception ex) {
            logger.error("Error occurred::", ex);
        }
        return result;
    }
    
    @Override
    @Transactional
    @PreAuthorize("hasAnyRole('Administrator')")
    public String triggerModule(int userId, int moduleId) throws AccessDeniedException {
        String result = null;
        try {
        	Module module = moduleDao.get(moduleId);
        	if (module != null) {
                        logger.info("module delete status: " + module.getDeleted());
        		module.setDeleted( (module.getDeleted() == 0) ? (byte) 1 : (byte) 0 );
        		module.setModifiedbyId(userId);
        		module.setUpdatedOn(new Date());
        		
        		moduleDao.update(module);
        		result = new GsonBuilder().serializeNulls().create().toJson(module);
        		logger.debug("triggerModule result: " + module.toString());
                        logger.info("module delete status changed to: " + module.getDeleted());
        	}
        } 
        catch (Exception ex) {
            logger.error("Error occurred::", ex);
        }
        return result;
    }
    
    @Override
    @Transactional
    @PreAuthorize("hasAnyRole('Administrator')")
    public String createOrUpdateModuleStandard(int standardId, int moduleId, String title, String description, int number) throws AccessDeniedException {
        String result = null;
        try {
        	Standard standard;
        	
    		standard = standardDao.get(standardId);
    		
    		if (standard == null) {
    			standard = new Standard();
    			standard.setModuleId(moduleId);
    			
    			standard.setTitle(title);
            	standard.setDescription(description);
            	standard.setStandardNo(number);
            	
            	standardDao.add(standard);
    		}
    		else {
    			standard.setTitle(title);
            	standard.setDescription(description);
            	standard.setStandardNo(number);
            	
            	standardDao.update(standard);
    		}
        	        	
        	result = standard.getId().toString();
        	logger.debug("createOrUpdateModuleStandard result: " + standard.toString());
        } 
        catch (Exception ex) {
            logger.error("Error occurred::", ex);
        }
        return result;
    }
    
    @Override
    @Transactional
    @PreAuthorize("hasAnyRole('Administrator')")
    public String updateModule(int userId, int moduleId, String title, String shortDescription, String longDescription,
    		String imageFileName, String iconFileName) throws AccessDeniedException {
        String result = null;
        try {
        	Module module = moduleDao.get(moduleId);
        	if (module != null) {
        		module.setTitle(title);
        		module.setShortDescription(shortDescription);
        		module.setLongDescription(longDescription);
        		module.setUpdatedOn(new Date());
        		module.setModifiedbyId(userId);
        		
        		if (imageFileName != null) {
        			module.setImageFile(imageFileName);
        		}
        		
        		if (iconFileName != null) {
        			module.setIconFile(iconFileName);
        		}
        		
        		moduleDao.update(module);
        		result = new GsonBuilder().serializeNulls().create().toJson(module);
        		logger.debug("updateModule result: " + module.toString());
        	}
        } 
        catch (Exception ex) {
            logger.error("Error occurred::", ex);
        }
        return result;
    }
    
    @Override
    @Transactional
    @PreAuthorize("hasAnyRole('Administrator')")
    public String createOrUpdateModuleResource(int userId, int moduleId, int resourceId, String title, String shortDescription, String link, String imageFileName) throws AccessDeniedException {
        String result = null;
        try {
        	Resource resource = resourceDao.get(resourceId);
        	if (resource != null) {
        		resource.setTitle(title);
        		resource.setShortDescription(shortDescription);
        		resource.setResourceUrl(link);
        		resource.setModifiedOn(new Date());
        		resource.setModifiedBy(userId);
        		
        		if (imageFileName != null) {
        			resource.setImageFilePath(imageFileName);
        		}
        		
        		resourceDao.update(resource);
        		result = new GsonBuilder().serializeNulls().create().toJson(resource);
        		logger.debug("createOrUpdateModuleResource update resource: " + resource.toString());
        	}
        	else {
        		resource = new Resource();
        		resource.setTitle(title);
        		resource.setShortDescription(shortDescription);
        		resource.setResourceUrl(link);
        		resource.setCreatedBy(userId);
        		resource.setCreatedOn(new Date());
        		resource.setTypeId(4);
        		
        		if (imageFileName != null) {
        			resource.setImageFilePath(imageFileName);
        		}
        		
        		resourceDao.add(resource);
        		result = new GsonBuilder().serializeNulls().create().toJson(resource);
        		logger.debug("createOrUpdateModuleResource new resource: " + resource.toString());
        		
        		ModuleResource mr = new ModuleResource();
        		mr.setModuleId(moduleId);
        		mr.setResourceId(resource.getId());
        		mr.setDeleted((byte)0);
        		moduleResourceDao.add(mr);
        		logger.debug("createOrUpdateModuleResource new ModuleResource: " + mr.toString());
        	}
        } 
        catch (Exception ex) {
            logger.error("Error occurred::", ex);
        }
        return result;
    }
    
    @Override
    @Transactional
    @PreAuthorize("hasAnyRole('Administrator')")
    public String createOrUpdateVideo(int userId, int moduleId, int videoId) throws AccessDeniedException {
        String result = null;
        try {
        	Video video = videoDao.get(videoId);
        	if (video != null) {
        		logger.debug("copy video from : " + video.toString());
        		Video newVideo = videoDao.getByProperties("moduleId", Integer.toString(moduleId), "isOverview", Integer.toString(video.getIsOverview()));
        		
        		if (newVideo != null) {
        			logger.debug("update video");
        			newVideo.setModuleId(moduleId);
        			newVideo.setFileName(video.getFileName());
        			newVideo.setVideoStreamingId(video.getVideoStreamingId());
        			newVideo.setIsOverview(video.getIsOverview());
    	        	videoDao.update(newVideo);
        		}
        		else {
        			logger.debug("create new video");
        			newVideo = new Video();
        			newVideo.setCreatedbyId(userId);
        			newVideo.setCreatedOn(new Date());
        			newVideo.setModuleId(moduleId);
        			newVideo.setFileName(video.getFileName());
        			newVideo.setVideoStreamingId(video.getVideoStreamingId());
        			newVideo.setIsOverview(video.getIsOverview());
        			videoDao.add(newVideo);
        		}
	        	
        		logger.debug("createOrUpdateVideo result: " + newVideo.toString());
        		result = new GsonBuilder().serializeNulls().create().toJson(newVideo);
        	}
        } 
        catch (Exception ex) {
            logger.error("Error occurred::", ex);
        }
        return result;
    }
    
    @Override
    @Transactional
    @PreAuthorize("hasAnyRole('Administrator')")
    public String createOrUpdateUploadedVideo(int userId, int moduleId, short isOverview, String fileName) throws AccessDeniedException {
        String result = null;
        try {
        	Video videoModel = videoDao.getByProperties("moduleId", Integer.toString(moduleId), "isOverview", Integer.toString(isOverview));
            if (videoModel == null) {
            	videoModel = new com.cei.kidvisionweb.db.model.Video();
            	videoModel.setCreatedbyId(userId);
                videoModel.setModuleId(moduleId);
                videoModel.setFileName(fileName);
                videoModel.setCreatedOn(new Date());
                videoModel.setIsOverview(isOverview);
                videoModel.setSequence(null);
                videoModel.setVideoStreamingId("0");
                
                videoDao.add(videoModel);
            }
            else {
            	videoModel.setCreatedbyId(userId);
                videoModel.setModuleId(moduleId);
                videoModel.setFileName(fileName);
                videoModel.setCreatedOn(new Date());
                videoModel.setIsOverview(isOverview);
                videoModel.setSequence(null);
                videoModel.setVideoStreamingId("0");
                
                videoDao.update(videoModel);
            }
            logger.debug("createOrUpdateUploadedVideo result: " + videoModel.toString());
            result = new GsonBuilder().serializeNulls().create().toJson(videoModel);
            return result;
        } 
        catch (Exception ex) {
            logger.error("Error occurred::", ex);
        }
        return result;
    }
    
//    @Override
//    @Transactional
//    @PreAuthorize("hasAnyRole('Administrator')")
//    public String updateVideo(int videoId, int userId, int moduleId, String fileName, String streamId, short isOverview, Byte sequence) throws AccessDeniedException {
//        String result = null;
//        try {
//        	Video video = videoDao.get(videoId);
//        	if (video != null) {
//	        	video.setCreatedbyId(userId);
//	        	video.setModuleId(moduleId);
//	        	video.setFileName(fileName);
//	        	video.setCreatedOn(new Date());
//	        	video.setIsOverview(isOverview);
//	        	video.setSequence(sequence);
//	        	video.setVideoStreamingId(streamId);
//	        	videoDao.update(video);
//	        	
//        		logger.debug("updateVideo result: " + video.toString());
//        		result = video.getId().toString();
//        	}
//        } 
//        catch (Exception ex) {
//            logger.error("Error occurred::", ex);
//        }
//        return result;
//    }
    
    @Override
    @Transactional
    @PreAuthorize("hasAnyRole('Administrator')")
    public String createModule(int userId, int moduleId, String title) throws AccessDeniedException {
        String result = null;
        try {
        	Module newModule = null;
        	if ( moduleId != 0 ) {
        		Module module = moduleDao.get(moduleId);
        		
        		if (module != null) {
        			newModule = moduleDao.createModuleFromExistingModule(userId, moduleId, title);
        		}
        	}
        	else {
        		newModule = new Module();
            	newModule.setTitle(title);
            	newModule.setDeleted((short)1);
            	newModule.setCreatedOn(new Date());
            	newModule.setCreatedbyId(userId);
            	moduleDao.add(newModule);	
        	}
        	
        	if (newModule != null) {
        		newModule.setSequence(newModule.getId());
        		moduleDao.update(newModule);
        		
        		logger.debug("createModule result: " + newModule.toString());
        		result = newModule.getId().toString();
        	}
        } 
        catch (Exception ex) {
            logger.error("Error occurred::", ex);
        }
        return result;
    }
    
    @Override
    @Transactional
    @PreAuthorize("hasAnyRole('Administrator')")
    public String deleteModuleQuestionAndAnswers(int questionId) throws AccessDeniedException {
        String result = null;
        try {
        	Question q = questionDao.get(questionId);
        	if (q != null) {
        		q.setDeleted((short)1);
        		questionDao.update(q);
        		logger.debug("deleteModuleQuestionAndAnswers result: " + q.toString());
        		result = q.getId().toString();
        	}
        } 
        catch (Exception ex) {
            logger.error("Error occurred::", ex);
        }
        return result;
    }
    
    @Override
    @Transactional
    @PreAuthorize("hasAnyRole('Administrator')")
    public String deleteModuleQuestion(int moduleId, int sequence) throws AccessDeniedException {
        String result = null;
        try {
        	Question q = questionDao.getByProperties("moduleId", Integer.toString(moduleId), "sequence", Integer.toString(sequence));
        	if (q != null) {
        		
        		q.setDeleted((short)1);
        		questionDao.update(q);
        		logger.debug("deleteModuleQuestion result: " + q.toString());
        		result = q.getId().toString();
        	}
        } 
        catch (Exception ex) {
            logger.error("Error occurred::", ex);
        }
        return result;
    }
    
    @Override
    @Transactional
    @PreAuthorize("hasAnyRole('Administrator')")
    public int createModuleQuestion(int moduleId, String question, int sequence, int standardId) throws AccessDeniedException {
        int result = -1;
        try {
        	Question q = new Question();
        	q.setModuleId(moduleId);
        	q.setQuestion(question);
        	q.setDeleted((short)0);
        	q.setSequence(sequence);
        	q.setStandardId(standardId);
        	questionDao.add(q);
        	result = q.getId();
        	logger.debug("createModuleQuestion result: " + q.toString());
        } 
        catch (Exception ex) {
            logger.error("Error occurred::", ex);
        }
        return result;
    }
    
    @Override
    @Transactional
    @PreAuthorize("hasAnyRole('Administrator')")
    public String createModuleQuestionAnswer(int questionId, String answer, short correct, Integer sequence) throws AccessDeniedException {
        String result = null;
        try {
        	Answer a = new Answer();
        	a.setQuestionId(questionId);
        	a.setAnswerValue(answer);
        	a.setCorrect(correct);
        	a.setSequence(sequence);
        	answerDao.add(a);
        	result = a.getId().toString();
        	logger.debug("createModuleQuestionAnswer result: " + a.toString());
        } 
        catch (Exception ex) {
            logger.error("Error occurred::", ex);
        }
        return result;
    }
    
    
    @Override
    @Transactional
    @PreAuthorize("hasAnyRole('Administrator')")
    public int createVideo(int userId, int moduleId, String fileName, String streamId, short isOverview, Byte sequence) throws AccessDeniedException {
        int result = -1;
        try {
        	Video video = new Video();
        	video.setCreatedbyId(userId);
        	video.setModuleId(moduleId);
        	video.setFileName(fileName);
        	video.setCreatedOn(new Date());
        	video.setIsOverview(isOverview);
        	video.setSequence(sequence);
        	video.setVideoStreamingId(streamId);
        	videoDao.add(video);
        	
        	logger.debug("createVideo result: " + video.toString());
        	result = video.getId();
        	
        } 
        catch (Exception ex) {
            logger.error("Error occurred::", ex);
        }
        return result;
    }
    
    @Override
    @Transactional
    @PreAuthorize("hasAnyRole('Administrator')")
    public String getStandardsByModule(int moduleId) throws AccessDeniedException {
        String result = null;
        try {
            List<Standard> msgs = standardDao.getModuleStandsByOrder(moduleId);
            result = new GsonBuilder().serializeNulls().create().toJson(msgs);
            logger.debug("getStandardsByModule result: " + msgs.size());
        } 
        catch (Exception ex) {
            logger.error("Error occurred::", ex);
        }
        return result;
    }
    
    @Override
    @Transactional
    @PreAuthorize("hasAnyRole('Administrator')")
    public String getQuestionAndAnsers(int questionId) throws AccessDeniedException {
        String result = null;
        try {
            Question q = questionDao.get(questionId);
            result = new GsonBuilder().serializeNulls().create().toJson(q);
            logger.debug("getQuestionAndAnsers result: " + q.toString());
        } 
        catch (Exception ex) {
            logger.error("Error occurred::", ex);
        }
        return result;
    }
    
    @Override
    @Transactional
    @PreAuthorize("hasAnyRole('Administrator')")
    public String getModuleVideos(int moduleId) throws AccessDeniedException {
        String result = null;
        try {
            List<Video> videos = videoDao.getListByProperty("moduleId", moduleId);
            result = new GsonBuilder().serializeNulls().create().toJson(videos);
            logger.debug("getModuleVideos result: " + videos.size());
        } 
        catch (Exception ex) {
            logger.error("Error occurred::", ex);
        }
        return result;
    }
    
    @Override
    @Transactional
    @PreAuthorize("hasAnyRole('Administrator')")
    public String getModule(int moduleId) throws AccessDeniedException {
        String result = null;
        try {
            Module module = moduleDao.get(moduleId);// .getModuleAndVideos(ModuleId);
            result = new GsonBuilder().serializeNulls().create().toJson(module);
            logger.debug("getModule result: " + module.toString());
        } 
        catch (Exception ex) {
            logger.error("Error occurred::", ex);
        }
        return result;
    }
    
    @Override
    @Transactional
    @PreAuthorize("hasAnyRole('Administrator')")
    public String getAllModules() throws AccessDeniedException {
        String result = null;
        logger.debug("request to get all modules");
        try {
            List<Module> msgs = moduleDao.getAllModulesOrderByTitleAndVideos();
            result = new GsonBuilder().serializeNulls().create().toJson(msgs);
            logger.debug("getAllModules result: " + msgs.size());
        } 
        catch (Exception ex) {
            logger.error("Error occurred::", ex);
        }
        return result;
    }
    
    @Override
    @Transactional
    @PreAuthorize("hasAnyRole('Administrator')")
    public String getAllVideos() throws AccessDeniedException {
        String result = null;
        logger.debug("request to get all videos");
        try {
            List<Video> msgs = videoDao.getListOrderByProperty("fileName");
            result = new GsonBuilder().serializeNulls().create().toJson(msgs);
            logger.debug("getAllVideos result: " + msgs.size());
        } 
        catch (Exception ex) {
            logger.error("Error occurred::", ex);
        }
        return result;
    }
    
//    @Override
//    @Transactional
//    @PreAuthorize("hasAnyRole('Administrator')")
//    public String getUnmappingVideos() throws AccessDeniedException {
//        String result = null;
//        logger.debug("request to get all videos");
//        try {
//            List<Video> msgs = videoDao.getListByProperty("videoStreamingId", "NULL");
//            result = new GsonBuilder().serializeNulls().create().toJson(msgs);
//            logger.debug("getAllVideos result: " + msgs.size());
//        } 
//        catch (Exception ex) {
//            logger.error("Error occurred::", ex);
//        }
//        return result;
//    }
    
    @Override
    @Transactional
    @PreAuthorize("hasAnyRole('Administrator')")
    public String getAllUsers() throws AccessDeniedException {
        String result = null;
        logger.debug("request to get all modules");
        try {
            List<User> msgs = userDao.getList();
            result = new GsonBuilder().serializeNulls().create().toJson(msgs);
            logger.debug("getAllUsers result: " + msgs.size());
        } 
        catch (Exception ex) {
            logger.error("Error occurred::", ex);
        }
        return result;
    }
    
    @Override
    @Transactional
    @PreAuthorize("hasAnyRole('Administrator')")
    public String getAllUsersPagination(int length, int start, int orderIndex, String order, String search) throws AccessDeniedException {
        String result = null;
        logger.debug("request to get all users pagination");
        try {
        	List<Config> configs = configDao.getListOrderByProperty("currentSchoolYearFrom");
        	Config config = configs.get(0);
        	
            List<UserDatatable> msgs = userDao.getAllUsersPagination(length, start, orderIndex, order, search, config.getCurrentSchoolYearFrom().toString());
            
            Gson gson = new GsonBuilder().serializeNulls().create(); //new Gson();
            
            long count = userDao.getAllUsersCount();
            logger.debug("cout = " + count);
            
            JsonObject object = new JsonObject();
            object.addProperty("iTotalRecords", Long.toString(count));
            object.addProperty("iTotalDisplayRecords", Long.toString(count));
            object.add("aaData", gson.toJsonTree(msgs));
            
            //result = new GsonBuilder().serializeNulls().create().toJson(map);
            result = object.toString();
            logger.debug("getAllUsersPagination result: " + msgs.size());
        } 
        catch (Exception ex) {
            logger.error("Error occurred::", ex);
        }
        return result;
    }
    
    @Override
    @Transactional
    @PreAuthorize("hasAnyRole('Administrator')")
    public String countUsersByCountyStatePagination(int length, int start, int orderIndex, String order, String search) throws AccessDeniedException {
        String result = null;
        logger.debug("countUsersByCountyStatePagination");
        try {
            List<UsersByCountyState> msgs = userDao.countUsersByCountyStatePagination(length, start, orderIndex, order, search);
            
            Gson gson = new GsonBuilder().serializeNulls().create();
            
            BigInteger count = addressDao.countAllCountyState();
            logger.debug("count = " + count);
            
            JsonObject object = new JsonObject();
            object.addProperty("iTotalRecords", count.toString());
            object.addProperty("iTotalDisplayRecords", count.toString());
            object.add("aaData", gson.toJsonTree(msgs));
            
            //result = new GsonBuilder().serializeNulls().create().toJson(map);
            result = object.toString();
            logger.debug("getAllUsersPagination result: " + msgs.size());
        } 
        catch (Exception ex) {
            logger.error("Error occurred::", ex);
        }
        return result;
    }
    
//    @Override
//    @Transactional
//    @PreAuthorize("hasAnyRole('Administrator')")
//    public List<Video> getAllVideosList() throws AccessDeniedException {
//        //String result = null;
//        logger.debug("request to get all videos");
//        try {
//            List<Video> msgs = videoDao.getListOrderByProperty("fileName");
//            logger.debug("getAllVideosList result: " + msgs.size());
//            return msgs;
//        } 
//        catch (Exception ex) {
//            logger.error("Error occurred::", ex);
//        }
//        return null;
//    }
    
	// module id 121 - 160
	
	// stream field video
	// KidVisionVPK Animal Shelter Field Trip
	// KidVision VPK Music Store Field Trip
	
	// Video field video
	// vpkbisc_field_VP6_1Mbps.flv
	// vpksheriff_VP6_1Mbps.flv
	// vpkscience_field_fr16_1Mbps.flv
	//   aquatic_intro_VP6_1Mbps.flv module_id=162 deleted
	//   aquatic_prog_VP6_1Mbps.flv module_id=11
	//   RR_prog_VP6_1Mbps.flv module_id=12
	//   vpaikido_field_VP6_1Mbps.flv module_id=24
	
	// vpkyoungart_field_fr16_1Mbps.flv
    // vpkanimal_VP6_1Mbps.flv     overview 0
	// vpkanimalintro_VP6_768K.flv overview 1
	// vpkbakeshop_stand_fr16_336.flv
	// vpkbakeshop stand fr16 336
	// 83
    //update videos
    //set video_streaming_id=null, video_streaming_title=null;
    @Override
    @Transactional
    @PreAuthorize("hasAnyRole('Administrator')")
    public String mappingYoutubeMP4VideosAndTableVideos(List<PlaylistItem> streams) throws AccessDeniedException {
        logger.debug("mappingYoutubeMP4VideosAndTableVideos");
        try {
            List<Video> videos = videoDao.getListOrderByProperty("fileName");
            logger.debug("getAllVideosList result: " + videos.size());
            
            
            for (Video video : videos) {
				
				if (video.getVideoStreamingId() != null) {
					continue;
				}
				
				String fileName = video.getFileName();
				int isOverview = video.getIsOverview();
				int startPos = fileName.indexOf("vpk") != -1 ? 3 : 0;
				int endPos = fileName.indexOf("_") != -1 ? fileName.indexOf("_") : fileName.indexOf(".");
				String key = fileName.substring(startPos, endPos).toLowerCase(); // get xxx from vpkxxx_field_....
				logger.debug("key=" + key + ",isOverview=" + isOverview);
				
				if (key.indexOf("rr") != -1) {
					key = "railroad";
					logger.debug("..key=" + key);
				}
				else if (key.indexOf("helicopters") != -1) {
					key = "airport";
					logger.debug("..key=" + key);
				}
				else if (key.indexOf("marlins") != -1) { // At Marlins' Park
					key = "baseball";
					logger.debug("..key=" + key);
				}
				else if (key.indexOf("theater") != -1) {
					key = "theatre";
					logger.debug("..key=" + key);
				}
				else if (key.indexOf("oceanography") != -1) {
					key = "oceanographic";
					logger.debug("..key=" + key);
				}
				else if (key.indexOf("postoffice") != -1) {
					key = "postoffice";
					logger.debug("..key=" + key);
				}
				
				// KidVisionVPK G R O W Project Field Trip
													
				for (PlaylistItem stream : streams) {
					String title = stream.getSnippet().getTitle().toLowerCase();
					//logger.debug("..title=" + title);
					if ( ( title.indexOf("hardware store") != -1 || title.indexOf("field") != -1 ) && isOverview == 0 ) {
						int startp = title.indexOf("vpk") != -1 ? title.indexOf("vpk")+3 : 0; // remove KidVision VPKx or KidVisionVPKx
						int endp = title.indexOf("field") != -1 ? title.indexOf("field") : title.length(); // remove xField Trip
						String longTitle = title.substring(startp, endp).trim();
						String shortTitle = longTitle;
						
						if (longTitle.indexOf("g r o w") != -1) {
							shortTitle = "miamigrow";
						}
						else if (longTitle.indexOf("hardware store visit") != -1) {
							shortTitle = "hardware";
						}
						else if (longTitle.indexOf(" ") != -1) {
							shortTitle = longTitle.substring(0, longTitle.indexOf(" "));
						}
						
						if (key.indexOf(shortTitle) != -1) {
							logger.debug("..match key short title: key=" + key + ",title=" + title);
							video.setVideoStreamingId(stream.getContentDetails().getVideoId());
							video.setVideoStreamingTitle(title);
							videoDao.update(video);
							break;
						}
						else if (shortTitle.indexOf(key) != -1) {
							logger.debug("..match short title key: key=" + key + ",title=" + title);
							video.setVideoStreamingId(stream.getContentDetails().getVideoId());
							video.setVideoStreamingTitle(title);
							videoDao.update(video);
							break;
						}
						else if (longTitle.indexOf(key) != -1) {
							logger.debug("..match long title key: key=" + key + ",title=" + title);
							video.setVideoStreamingId(stream.getContentDetails().getVideoId());
							video.setVideoStreamingTitle(title);
							videoDao.update(video);
							break;
						}
					}
					else if ( ( title.indexOf("336") != -1 || title.indexOf("postofficestandup") != -1
							|| title.indexOf("vp6") != -1) && isOverview == 1 ) {
						// vpkanimalintro_VP6_768K.flv
						// vpkfireintro_VP6_768K.flv
						// vpkrecycleintro_VP6_768K.flv
						// vpksheriffintro_VP6_768K.flv

						key = fileName.substring(0, endPos).toLowerCase();
						
						if (key.indexOf("postoffice") != -1) {
							key = "postoffice";
							logger.debug("..key=" + key);
						}
						
						if ( title.indexOf(key) != -1) {
							logger.debug("..match tite = " + title + " , fileName= " + fileName);
							//adminService.mappingVideo(video.getId(), stream.getContentDetails().getVideoId());
							video.setVideoStreamingId(stream.getContentDetails().getVideoId());
							video.setVideoStreamingTitle(title);
							videoDao.update(video);
							break;
						}
						//String fileNamewithoutextension = fileName.substring(0, fileName.indexOf(".")); // remove .flv
						//String fileNamewithoutunderscore = fileNamewithoutextension.replaceAll("_", " "); // 
						//logger.debug("fileNamewithoutunderscore = " + fileNamewithoutunderscore);
						
						/*if (fileName.indexOf("vpkanimalintro") != -1 && stream.getSnippet().getTitle().indexOf("vpkanimalintro") != -1) {
							logger.debug("..match tite = " + stream.getSnippet().getTitle() + " , vpkanimalintro");
							video.setVideoStreamingId(stream.getContentDetails().getVideoId());
							break;
						}
						else if (fileName.indexOf("vpkfireintro") != -1) {
							logger.debug("..match tite = " + stream.getSnippet().getTitle() + " , vpkfireintro");
							video.setVideoStreamingId(stream.getContentDetails().getVideoId());
							break;
						}
						else if (fileName.indexOf("vpkrecycleintro") != -1) {
							logger.debug("..match tite = " + stream.getSnippet().getTitle() + " , vpkrecycleintro");
							video.setVideoStreamingId(stream.getContentDetails().getVideoId());
							break;
						}
						else if (fileName.indexOf("vpksheriffintro") != -1) {
							logger.debug("..match tite = " + stream.getSnippet().getTitle() + " , vpksheriffintro");
							video.setVideoStreamingId(stream.getContentDetails().getVideoId());
							break;
						}*/
//						if ( fileNamewithoutunderscore.equalsIgnoreCase( stream.getSnippet().getTitle() ) ) {
//							logger.debug("..match tite = " + stream.getSnippet().getTitle() + " , fileName= " + fileName);
//							//adminService.mappingVideo(video.getId(), stream.getContentDetails().getVideoId());
//							video.setVideoStreamingId(stream.getContentDetails().getVideoId());
//							break;
//						}
					}
				}
            }
            
            List<Video> msgs = videoDao.getVideoWithoutStreamingId();
            String result = new GsonBuilder().serializeNulls().create().toJson(msgs);
            logger.debug("unmapping videos result: " + msgs.size());
            return result;
        } 
        catch (Exception ex) {
            logger.error("Error occurred::", ex);
        }
        return null;
    }
    
//    @Override
//    @Transactional
//    @PreAuthorize("hasAnyRole('Administrator')")
//    public String mappingVideo(int id, String stream_id) throws AccessDeniedException {
//        String result = null;
//        logger.debug("request to get all videos");
//        try {
//            Video video = videoDao.get(id);
//            video.setVideoStreamingId(stream_id);
//            videoDao.update(video);
//            logger.debug("mappingVideo result: " + video.toString());
//            return video.getVideoStreamingId();
//        } 
//        catch (Exception ex) {
//            logger.error("Error occurred::", ex);
//        }
//        return result;
//    }
    
    @Override
    @Transactional
    @PreAuthorize("hasAnyRole('Administrator')")
    public String createSurveyQuestion(int userId, String question, int sequence) throws AccessDeniedException {
        String result = null;
        try {
            SurveyQuestion sq = new SurveyQuestion();
            sq.setCreatedBy(userId);
            sq.setCreatedOn(new Date());
            sq.setDeleted((byte)0);
            sq.setQuestion(question);
            sq.setSequence(sequence);
            surveyQuestionDao.add(sq);
            result = new GsonBuilder().serializeNulls().create().toJson(sq);
            logger.debug("createSurveyQuestion result: " + sq.toString());
        } 
        catch (Exception ex) {
            logger.error("Error occurred::", ex);
        }
        return result;
    }
    
    @Override
    @Transactional
    @PreAuthorize("hasAnyRole('Administrator')")
    public String updateSurveyQuestion(int userId, int questionId, String question, int sequence) throws AccessDeniedException {
        String result = null;
        try {
            SurveyQuestion sq = surveyQuestionDao.get(questionId); 
            if (sq != null) {
            	sq.setModifiedBy(userId);
                sq.setModifiedOn(new Date());
                sq.setDeleted((byte)0);
                sq.setQuestion(question);
                sq.setSequence(sequence);
                surveyQuestionDao.update(sq);
                result = new GsonBuilder().serializeNulls().create().toJson(sq);
            }
            
            logger.debug("updateSurveyQuestion result: " + sq.toString());
        } 
        catch (Exception ex) {
            logger.error("Error occurred::", ex);
        }
        return result;
    }
    
    @Override
    @Transactional
    @PreAuthorize("hasAnyRole('Administrator')")
    public String triggerSurveyQuestion(int userId, int questionId) throws AccessDeniedException {
        String result = null;
        try {
            SurveyQuestion sq = surveyQuestionDao.get(questionId); 
            if (sq != null) {
            	sq.setModifiedBy(userId);
                sq.setModifiedOn(new Date());
                sq.setDeleted((sq.getDeleted() == 0) ? (byte)1 : (byte)0);
                surveyQuestionDao.update(sq);
                result = new GsonBuilder().serializeNulls().create().toJson(sq);
            }
            
            logger.debug("triggerSurveyQuestion result: " + sq.toString());
        } 
        catch (Exception ex) {
            logger.error("Error occurred::", ex);
        }
        return result;
    }
    
    @Override
    @Transactional
    @PreAuthorize("hasAnyRole('Administrator')")
    public String getSurveyQuestions() throws AccessDeniedException {
        String result = null;
        try {
            List<SurveyQuestion> msgs = surveyQuestionDao.getList();
            result = new GsonBuilder().serializeNulls().create().toJson(msgs);
            logger.debug("getSurveyQuestions result: " + msgs.size());
        } 
        catch (Exception ex) {
            logger.error("Error occurred::", ex);
        }
        return result;
    }
    
    @Override
    @Transactional
    @PreAuthorize("hasAnyRole('Administrator')")
    public String getSurveyResults() throws AccessDeniedException {
        String result = null;
        try {
            List<SurveyResult> msgs = surveyResultDao.getList();
            result = new GsonBuilder().serializeNulls().create().toJson(msgs);
            logger.debug("getSurveyResults result: " + msgs.size());
        } 
        catch (Exception ex) {
            logger.error("Error occurred::", ex);
        }
        return result;
    }
    
    @Override
    @Transactional
    @PreAuthorize("hasAnyRole('Administrator')")
    public String getUserSurveyAnswers() throws AccessDeniedException {
        String result = null;
        try {
            List<UserSurveyAnswerResult> msgs = userSurveyAnswerDao.getUserSurveyAnswers();
            result = new GsonBuilder().serializeNulls().create().toJson(msgs);
            logger.debug("getUserSurveyAnswers result: " + msgs.size());
        } 
        catch (Exception ex) {
            logger.error("Error occurred::", ex);
        }
        return result;
    }
    
    @Override
    @Transactional
    @PreAuthorize("hasAnyRole('Administrator')")
    public String getUserModuleActivityFieldtripCVS(String title) throws AccessDeniedException {
        String result = null;
        try {
            List<UserModuleActivityFieldtripDatatable> msgs = userModuleActivityDao.getUserModuleActivitiesFieldtrip();
            result = new GsonBuilder().serializeNulls().create().toJson(msgs);
            logger.debug("getUserModuleActivityFieldtrip result: " + msgs.size());
        	
            String path = KidvisionWebConfig.USER_MODULE_ACTIVITY_FIELDTRIP_DIRECTORY + title + ".csv";
        	
        	File newUploadedFile = new File(KidvisionWebConfig.USER_MODULE_ACTIVITY_FIELDTRIP_DIRECTORY);
        	
	    	if (!newUploadedFile.exists()) {  // Checks that Directory/Folder Doesn't Exists!  
	            if(newUploadedFile.mkdir()) {  
	            	logger.debug("create folder " + KidvisionWebConfig.USER_MODULE_ACTIVITY_FIELDTRIP_DIRECTORY);
	            }
	        }
	    	
	    	FileWriter writer = new FileWriter(path);
        	
	    	writer.append("Last Name");
		    writer.append(',');
		    writer.append("First Name");
		    writer.append(',');
		    writer.append("Company Name");
		    writer.append(',');
		    writer.append("Mailing Address");
		    writer.append(',');
		    writer.append("City,State,Zip");
		    writer.append(',');
		    writer.append("Cell Phone");
		    writer.append(',');
		    writer.append("Email Address");
		    writer.append(',');
		    writer.append("Session Date");
		    writer.append(',');
		    writer.append("Session Name");
		    writer.append(',');
		    writer.append("Session Duration");
		    writer.append('\n');
		    
		    for (UserModuleActivityFieldtripDatatable msg : msgs) {
		    	writer.append(msg.getLastName());
			    writer.append(',');
			    writer.append(msg.getFirstName());
			    writer.append(',');
			    writer.append(msg.getSchoolName());
			    writer.append(',');
			    writer.append(msg.getStreetAddress());
			    writer.append(',');
			    writer.append(msg.getCity() + "," + msg.getState() + "," + msg.getZipCode());
			    writer.append(',');
			    writer.append("" + ((msg.getPhone() == null) ? "" : msg.getPhone()));
			    writer.append(',');
			    writer.append(msg.getEmail());
			    writer.append(',');
			    writer.append("" + ((msg.getStartDatetime() == null) ? "" : new SimpleDateFormat("MM-dd-yyyy").format(msg.getStartDatetime())));
			    writer.append(',');
			    writer.append(msg.getTitle());
			    writer.append(',');
			    writer.append('0');
			    //writer.append("" + TimeUnit.MILLISECONDS.toHours(msg.getStartDatetime().getTime() - msg.getEndDatetime().getTime()) + " hours");
			    writer.append('\n');
		    }
		    
	    	writer.flush();
		    writer.close();
	    	
            result = path; // new GsonBuilder().serializeNulls().create().toJson(msgs);
            logger.debug("getUserModuleTestTranscriptDetails path: " + path);
        } 
        catch (Exception ex) {
            logger.error("Error occurred::", ex);
        }
        return result;
    }
    
    @Override
    @Transactional
    @PreAuthorize("hasAnyRole('Administrator')")
    public String getAllUserModuleSurveyAnswers() throws AccessDeniedException {
        String result = null;
        try {
            List<UserModuleSurveyAnswerResult> msgs = userModuleSurveyAnswerDao.getAllUserModuleSurveyAnswers();
            result = new GsonBuilder().serializeNulls().create().toJson(msgs);
            logger.debug("getUserModuleSurveyAnswers result: " + msgs.size());
        } 
        catch (Exception ex) {
            logger.error("Error occurred::", ex);
        }
        return result;
    }
    
    @Override
    @Transactional
    @PreAuthorize("hasAnyRole('Administrator')")
    public String addOrUpdateAddress(Integer userId, Integer addressId, String streetAddress, String city, String county, 
    		String state, String country, String zipCode) throws AccessDeniedException {
    	String result = null;
        try {
        	Address address;
        	if (addressId == -1) {
        		logger.debug("addressId = null");
        		address = new Address();
        		address.setStreetAddress(streetAddress);
        		address.setCity(city);
        		address.setCounty(county);
        		address.setState(state);
        		address.setCountry(country);
        		address.setZipCode(zipCode);
        		addressDao.add(address);

        		User user = userDao.get(userId);
            	if (user != null) {
            		user.setPrimaryAddressId(address.getId());
            		userDao.update(user);
            	}
        	}
        	else {
        		logger.debug("addressId = " + addressId);
        		address = addressDao.get(addressId);
        		address.setStreetAddress(streetAddress);
        		address.setCity(city);
        		address.setCounty(county);
        		address.setState(state);
        		address.setCountry(country);
        		address.setZipCode(zipCode);
        		addressDao.update(address);
        	}

        	result = new GsonBuilder().serializeNulls().create().toJson(address);
            logger.debug("addOrUpdateAddress result: " + result);
        } 
        catch (Exception ex) {
            logger.error("Error occurred::", ex);
        }
        return result;
    }
    
    
    @Override
    @Transactional
    @PreAuthorize("hasAnyRole('Administrator')")
    public String updateUser(int userId, String prefix, String firstName, String middleName, String lastName,
    		String email, String userName, String educationLevel, int occupationalTitleId, 
    		String otherOccupationalTitle, String phone, boolean emailNotification, byte registrationtypeId, 
    		String schoolName) throws AccessDeniedException {
        String result = null;
        try {
        	User user = userDao.get(userId);

        	if (user != null) {
        		user.setPrefix(prefix);
	        	user.setFirstName(firstName);
	            user.setLastName(lastName);
	            user.setMiddleName(middleName);
	            //user.setEmail(email);
	            //user.setUserName(userName);
	            if (occupationalTitleId == 6) {
	            	user.setOtherOccupationalTitle(otherOccupationalTitle);
	            } 
	            else {
	            	user.setOtherOccupationalTitle(null);
	            }
	            user.setOccupationalTitleId(occupationalTitleId);
	            user.setPhone(phone);
	            user.setSchoolName(schoolName);
	            user.setEmailNotification(emailNotification);
	            user.setRegistrationtypeId(registrationtypeId);
	            user.setUpdatedOn(new Date());
	        	
	            userDao.update(user);
	            SimpleUser sUser = new SimpleUser(user);
	            result = new GsonBuilder().serializeNulls().create().toJson(sUser);
        	}
        	logger.debug("updateUser result: " + user.toString());
        } 
        catch (Exception ex) {
            logger.error("Error occurred::", ex);
        }
        return result;
    }
    
//    @Override
//    @Transactional
//    @PreAuthorize("hasAnyRole('Administrator')")
//    public Integer getUserPrimaryAddressId(int userId) throws AccessDeniedException {
//    	Integer result = null;
//        try {
//        	User user = userDao.get(userId);
//        	if (user != null) {
//        		result = user.getPrimaryAddressId();
//        		logger.debug("getUserPrimaryAddressId result: " + user.toString());
//        	}
//        } 
//        catch (Exception ex) {
//            logger.error("Error occurred::", ex);
//        }
//        return result;
//    }
    
    
    @Override
    @Transactional
    @PreAuthorize("hasAnyRole('Administrator')")
    public String getUser(int userId) throws AccessDeniedException {
    	String result = null;
        try {
        	User user = userDao.get(userId);
        	if (user != null) {
        		result = new GsonBuilder().serializeNulls().create().toJson(user);
        	}
        } 
        catch (Exception ex) {
            logger.error("Error occurred::", ex);
        }
        return result;
    }
    
    @Override
    @Transactional
    @PreAuthorize("hasAnyRole('Administrator')")
    public String getUserAddress(int addressId) throws AccessDeniedException {
        String result = null;
        try {
        	Address msgs = addressDao.get(addressId);
            result = new GsonBuilder().serializeNulls().create().toJson(msgs);
            logger.debug("getUserAddress result: " + msgs.toString());
        } 
        catch (Exception ex) {
            logger.error("Error occurred::", ex);
        }
        return result;
    }
    
    @Override
    @Transactional
    @PreAuthorize("hasAnyRole('Administrator')")
    public String updateUserPassword(int userId, String password) throws AccessDeniedException {
        String result = null;
        try {
        	User user = userDao.get(userId);

        	if (user != null) {
        		user.setPassword(password);
        		//user.setTempPassword(null);
        		user.setPasswordReset((short)0);
        		userDao.update(user);
        		//SimpleUser sUser = new SimpleUser(user);
        		//result = new GsonBuilder().serializeNulls().create().toJson(sUser);
        		result = user.getPassword();
        	}
            
            logger.debug("updateUserPassword user: " + user.toString());
        } 
        catch (Exception ex) {
            logger.error("Error occurred::", ex);
        }
        return result;
    }
    
    @Override
	@Transactional
	@PreAuthorize("hasAnyRole('Administrator')")
	public String checkUserName(String username) {
		String result = "false";
		try {
			 User user = userDao.getUniqueByProperty("userName", username);
			 //User user = userDao.getUniqueByPropertyCaseSensitive("userName", username);
			 result = (user == null) ? "true" : "false";
			 logger.debug("checkUserName true is no duplicate : " + result);
		} catch (Exception ex) {
	        logger.error("Error occurred::", ex);
	    } 
		return result;
	}
    
    @Override
    @Transactional
    @PreAuthorize("hasAnyRole('Administrator')")
    public String updateUsername(int userId, String username) throws AccessDeniedException {
        String result = null;
        try {
        	User user = userDao.get(userId);

        	if (user != null) {
        		user.setUserName(username);
        		userDao.update(user);
        		result = user.getUserName();
        	}
            
            logger.debug("updateUsername user: " + user.toString());
        } 
        catch (Exception ex) {
            logger.error("Error occurred::", ex);
        }
        return result;
    }
}
