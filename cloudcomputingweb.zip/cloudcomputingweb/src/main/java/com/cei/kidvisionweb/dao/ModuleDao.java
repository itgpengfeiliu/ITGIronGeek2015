package com.cei.kidvisionweb.dao;

import com.cei.kidvisionweb.db.model.Module;

import java.util.List;

/**
 *
 * @author Shrikant
 */
public interface ModuleDao extends GenericDao<Module, Long> {
    
      List<Module> getAllModulesOrderBySequence();
      
      List<Module> getAllModulesOrderByTitleAndVideos();
      
      //List getAllModulesOrderBySequenceAndOverviewVideo();
      
      List<Module> getAllModulesOrderBySequenceAndVideos();
      
      Module createModuleFromExistingModule(int userId, int moduleId, String title);
}
