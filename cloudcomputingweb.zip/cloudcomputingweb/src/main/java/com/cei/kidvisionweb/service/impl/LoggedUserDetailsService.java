package com.cei.kidvisionweb.service.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.TransactionTemplate;
import org.springframework.util.Assert;

import com.cei.kidvisionweb.dao.UserDao;
import com.cei.kidvisionweb.db.model.User;
import com.cei.kidvisionweb.service.util.LoggedUser;

public class LoggedUserDetailsService implements UserDetailsService {
	
	private static Logger logger = LoggerFactory.getLogger(LoggedUserDetailsService.class);
    private final TransactionTemplate transactionTemplate;
    @Autowired
    private UserDao userDao;
	
    @Autowired
    public LoggedUserDetailsService(PlatformTransactionManager transactionManager) {
        Assert.notNull(transactionManager, "The 'transactionManager' argument must not be null.");
        this.transactionTemplate = new TransactionTemplate(transactionManager);
        this.transactionTemplate.setPropagationBehavior(TransactionDefinition.PROPAGATION_REQUIRES_NEW);
        this.transactionTemplate.setTimeout(30);
        logger.debug("transaction template = " + transactionTemplate);
    }

	@Override
    @Transactional
    public LoggedUser loadUserByUsername(String username) throws UsernameNotFoundException, DataAccessException {
        User user = userDao.getUniqueByProperty("userName", username);
        //User user = userDao.getUniqueByPropertyCaseSensitive("userName", username);
        logger.debug("loadUserByUsername after : " + user.toString());
        throwExceptionIfNotFound(user, username);
        return new LoggedUser(user);
    }
 
    private void throwExceptionIfNotFound(User user, String username) {
        if (user == null) {
        	logger.error("User with username " + username + "  has not been found.");
            throw new UsernameNotFoundException("User with username " + username + "  has not been found.");
        }
    }
}
