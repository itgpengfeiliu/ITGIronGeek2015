package com.cei.kidvisionweb.service.impl;

import com.cei.kidvisionweb.config.KidvisionWebConfig;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.cei.kidvisionweb.dao.AddressDao;
import com.cei.kidvisionweb.dao.AuthenticationQuestionDao;
import com.cei.kidvisionweb.dao.AuthenticationUserAnswerDao;
import com.cei.kidvisionweb.dao.ConfigDao;
import com.cei.kidvisionweb.dao.OccupationalTitleDao;
import com.cei.kidvisionweb.dao.RegistrationDao;
import com.cei.kidvisionweb.dao.UserDao;
import com.cei.kidvisionweb.dao.UserModuleActivityDao;
import com.cei.kidvisionweb.dao.UsersLoginDao;
import com.cei.kidvisionweb.db.model.Address;
import com.cei.kidvisionweb.db.model.AuthenticationQuestion;
import com.cei.kidvisionweb.db.model.AuthenticationUserAnswer;
import com.cei.kidvisionweb.db.model.Config;
import com.cei.kidvisionweb.db.model.OccupationalTitle;
import com.cei.kidvisionweb.db.model.Registration;
import com.cei.kidvisionweb.db.model.User;
import com.cei.kidvisionweb.db.model.UsersLogin;
import com.cei.kidvisionweb.service.UserService;
import com.google.gson.GsonBuilder;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.TransactionTemplate;
import org.springframework.util.Assert;

public class UserServiceImpl implements UserService {

	private static Logger logger = LoggerFactory.getLogger(UserServiceImpl.class);
    private final TransactionTemplate transactionTemplate;
    
    
    @Value("#{kidvisionProperties['process.payment']}")
    private int processPayment;
    
    @Autowired
    private UserDao userDao;
    @Autowired
    private UsersLoginDao usersLoginDao;
    @Autowired
    private RegistrationDao registrationDao;
    @Autowired
    private AddressDao addressDao;
    @Autowired
    private ConfigDao configDao;
    @Autowired
    private AuthenticationUserAnswerDao authenUserAnswerDao;
    @Autowired
    private AuthenticationQuestionDao authenQuestionDao;
    @Autowired
    private UserModuleActivityDao userModuleActivityDao;
    @Autowired
    private OccupationalTitleDao occupationalTitleDao;
    
    @PostConstruct
    protected void init() {
        logger.info("initializing");
        logger.debug("processPayment = " + processPayment);
    }
    @Autowired
    public UserServiceImpl(PlatformTransactionManager transactionManager) {
        Assert.notNull(transactionManager, "The 'transactionManager' argument must not be null.");
        this.transactionTemplate = new TransactionTemplate(transactionManager);
        this.transactionTemplate.setPropagationBehavior(TransactionDefinition.PROPAGATION_REQUIRES_NEW);
        this.transactionTemplate.setTimeout(30);
        logger.debug("transaction template = " + transactionTemplate);
        logger.debug("kidvison home: " + KidvisionWebConfig.KIDVISION_HOME);
    }
    
    
    /*@Override
    @Transactional
    public String addIfNotExistUserModulePretestActivity(int userId, byte completed) {
        String result = "false";
        try {
        	UserModuleActivity newUserModuleActivity = 
        			userModuleActivityDao.getByProperties("userId", Integer.toString(userId),
        												  "activityType", UserModuleActivity.ACTIVITY_TYPES.pretest.name());
        	if (newUserModuleActivity == null) {
        		logger.debug("addIfNotExistUserModulePretestActivity not exist. userId = " + userId);
        		newUserModuleActivity = new UserModuleActivity();
            	newUserModuleActivity.setUserId(userId);
            	newUserModuleActivity.setModuleId(null);
            	//newUserModuleActivity.setActivityName(activityName);
        		newUserModuleActivity.setIsCompleted(completed);
            	newUserModuleActivity.setStartDatetime(new Date());
            	newUserModuleActivity.setActivityType(UserModuleActivity.ACTIVITY_TYPES.pretest.name());
            	if (completed == 1) {
            		newUserModuleActivity.setEndDatetime(new Date());
            	}
                userModuleActivityDao.add(newUserModuleActivity);
                logger.debug("add new : " + newUserModuleActivity.toString());
            }
        	else {
        		logger.debug("existing : " + newUserModuleActivity.toString());
        		if (completed == 1) {
            		newUserModuleActivity.setEndDatetime(new Date());
            		userModuleActivityDao.update(newUserModuleActivity);
            	}
        	}
        	result = "true";
        } 
        catch (Exception ex) {
            logger.error("Error occurred::", ex);
        }
        return result;
    }*/
    
    @Override
	@Transactional
	public Config getConfig() {
		try {
			List<Config> msgs = configDao.getListOrderByProperty("currentSchoolYearFrom");
			if (msgs != null) {
				logger.debug("getConfig : " + msgs.get(0).toString());
				return msgs.get(0);
			}
		} catch (Exception ex) {
            logger.error("Error occurred::", ex);
        } 
		return null;
	}
    
    @Override
	@Transactional
	public String validUserPasswordRecoveryQuestionsAndAnswers(String username, String qid0, String qid1, String a0, String a1) {
		try {
			User user = userDao.getUniqueByProperty("userName", username);
			//User user = userDao.getUniqueByPropertyCaseSensitive("userName", username);
			if (user != null) {
				int valid = 0;
				AuthenticationQuestion authenQuestion;
				List<AuthenticationUserAnswer> authenUserAnswers = authenUserAnswerDao.getListByProperty("userId", user.getId());
			
				for (AuthenticationUserAnswer aua : authenUserAnswers) {
					authenQuestion = authenQuestionDao.get(aua.getAuthenticationQuestionId());
					if (authenQuestion.getId() == Integer.parseInt(qid0)) {
						if (aua.getAnswer().equals(a0)) {
							logger.debug("correct answer a0 = " + a0);
							valid++;
						}
						else {
							return null;
						}
					}
					else if (authenQuestion.getId() == Integer.parseInt(qid1)) {
						if (aua.getAnswer().equals(a1)) {
							logger.debug("correct answer a1 = " + a1);
							valid++;
						}
						else {
							return null;
						}
					}
				}
				
				return (valid == 2) ? user.getPassword() : null;
			}
		} catch (Exception ex) {
            logger.error("Error occurred::", ex);
        } 
		return null;
	}
    
    @Override
	@Transactional
	public String getUserPasswordRecoveryQuestions(String userName) {
		String result = null;
		try {
			User user = userDao.getUniqueByProperty("userName", userName);
			//User user = userDao.getUniqueByPropertyCaseSensitive("userName", userName);
			if (user != null) {
				List<AuthenticationQuestion> msgs = new ArrayList<AuthenticationQuestion>();
				List<AuthenticationUserAnswer> authenUserAnswers = authenUserAnswerDao.getListByProperty("userId", user.getId());
			
				for (AuthenticationUserAnswer aua : authenUserAnswers) {
					msgs.add(authenQuestionDao.get(aua.getAuthenticationQuestionId()));
				}
				result = new GsonBuilder().serializeNulls().create().toJson(msgs);
				logger.debug("getUserPasswordRecoveryQuestions : " + result.toString());
			}
		} catch (Exception ex) {
            logger.error("Error occurred::", ex);
        } 
		return result;
	}
    
    
    @Override
	@Transactional
	public String getPasswordRecoveryQuestions() {
		String result = null;
		try {
			List<AuthenticationQuestion> msgs = authenQuestionDao.getList();
			result = new GsonBuilder().serializeNulls().create().toJson(msgs);
			logger.debug("getPasswordRecoveryQuestions : " + result.toString());
		} catch (Exception ex) {
            logger.error("Error occurred::", ex);
        } 
		return result;
	}
    
    @Override
	@Transactional
	public Integer addAuthenticationUserAnswer(AuthenticationUserAnswer authenUserAnswer) {
    	Integer result = null;
		try {
			authenUserAnswerDao.add(authenUserAnswer);
			result = authenUserAnswer.getId();
			logger.debug("addAuthenticationUserAnswer : " + authenUserAnswer.toString());
		} catch (Exception ex) {
            logger.error("Error occurred::", ex);
        } 
		return result;
	}
    
	@Override
	@Transactional
	public Integer addAddress(Address address) {
		Integer result = null;
		try {
			addressDao.add(address);
			result = address.getId();
			logger.debug("addAddress : " + address.toString());
		} catch (Exception ex) {
            logger.error("Error occurred::", ex);
        } 
		return result;
	}
    
	@Override
	@Transactional
	public Integer addRegistration(Registration registration) {
		Integer result = null;
		try {
			registrationDao.add(registration);
			result = registration.getId();
			logger.debug("addRegistration : " + registration.toString());
		} catch (Exception ex) {
            logger.error("Error occurred::", ex);
        } 
		return result;
	}
	
	@Override
	@Transactional
	public Integer updateRegistration(int userId, int currentRegistrationId) {
		Integer result = null;
		try {
			User user = userDao.get(userId);
			user.setCurrentRegistrationId(currentRegistrationId);
			userDao.update(user);
			result = user.getId();
			logger.debug("updateRegistration : " + user.toString());
		} catch (Exception ex) {
            logger.error("Error occurred::", ex);
        } 
		return result;
	}

	@Override
	@Transactional
	public Integer addUser(User user) {
		Integer result = null;
		try {
			userDao.add(user);
			result = user.getId();
			logger.debug("addUser : " + user.toString());
		} catch (Exception ex) {
            logger.error("Error occurred::", ex);
        } 
		return result;
	}
	
	@Override
	@Transactional
	public String checkEmail(String email) {
		String result = "false";
		try {
			 User user = userDao.getUniqueByProperty("email", email);
			 //User user = userDao.getUniqueByPropertyCaseSensitive("email", email);
			 result = (user == null) ? "true" : "false";
			 logger.debug("checkEmail true is no duplicate : " + result);
		} catch (Exception ex) {
	        logger.error("Error occurred::", ex);
	    } 
		return result;
	}

	@Override
	@Transactional
	public String checkUserName(String username) {
		String result = "false";
		try {
			 User user = userDao.getUniqueByProperty("userName", username);
			 //User user = userDao.getUniqueByPropertyCaseSensitive("userName", username);
			 result = (user == null) ? "true" : "false";
			 logger.debug("checkUserName true is no duplicate : " + result);
		} catch (Exception ex) {
	        logger.error("Error occurred::", ex);
	    } 
		return result;
	}
	
	@Override
	@Transactional
	public String validNewUserEmailandUsername(final String email, final String username) {
		String result = "false";
		try {
			result = userDao.validNewUserEmailandUsername(email, username);
			logger.debug("validNewUserEmailandUsername " + email + " , " + username + " : " + result);
		} catch (Exception ex) {
            logger.error("Error occurred::", ex);
        } 
		return result;
	}
 
	@Override
    @Transactional
    public String getOccupationalTitles() throws AccessDeniedException {
        String result = null;
        try {
            List<OccupationalTitle> msgs = occupationalTitleDao.getListOrderByProperty("id");
            result = new GsonBuilder().serializeNulls().create().toJson(msgs);
            logger.debug("getOccupationalTitles result : " + msgs.size());
            return result;
        } 
        catch (Exception ex) {
            logger.error("Error occurred::", ex);
        }
        return result;
    }
	
	@Override
	@Transactional
	public String addUserLoginTime(Integer userId) {
		String result = null;
		try {
			UsersLogin ul = new UsersLogin();
			ul.setUserId(userId);
			ul.setLoginOn(new Date());
			usersLoginDao.add(ul);
			
			logger.debug("addUserLoginTime " + ul.toString());
			return ul.getId().toString();
		} catch (Exception ex) {
            logger.error("Error occurred::", ex);
        } 
		return result;
	}
	
    @Override
    @Transactional
    public int getProcessPayment() throws AccessDeniedException {
        return processPayment;
    }
}
