package com.cei.kidvisionweb.dao;

import java.util.List;

import com.cei.kidvisionweb.db.model.UserModuleSurveyAnswer;
import com.cei.kidvisionweb.db.model.UserModuleSurveyAnswerResult;


public interface UserModuleSurveyAnswerDao extends GenericDao<UserModuleSurveyAnswer, Long> {
	
	List<UserModuleSurveyAnswerResult> getAllUserModuleSurveyAnswers();
	
	List<UserModuleSurveyAnswerResult> getUserModuleSurveyAnswers(int moduleId);
}
