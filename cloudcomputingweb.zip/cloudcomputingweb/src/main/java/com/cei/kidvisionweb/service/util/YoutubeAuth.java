package com.cei.kidvisionweb.service.util;

import com.cei.kidvisionweb.config.KidvisionWebConfig;
import com.google.api.client.auth.oauth2.Credential;
import com.google.api.client.auth.oauth2.StoredCredential;
import com.google.api.client.extensions.java6.auth.oauth2.AuthorizationCodeInstalledApp;
import com.google.api.client.extensions.jetty.auth.oauth2.LocalServerReceiver;
import com.google.api.client.googleapis.auth.oauth2.GoogleAuthorizationCodeFlow;
import com.google.api.client.googleapis.auth.oauth2.GoogleClientSecrets;
import com.google.api.client.http.HttpTransport;
import com.google.api.client.http.javanet.NetHttpTransport;
import com.google.api.client.json.JsonFactory;
import com.google.api.client.json.jackson2.JacksonFactory;
import com.google.api.client.util.store.DataStore;
import com.google.api.client.util.store.FileDataStoreFactory;
import java.io.File;
import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;
import java.util.List;
import javax.annotation.PostConstruct;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;

public class YoutubeAuth {

    private static Logger logger = LoggerFactory.getLogger(YoutubeAuth.class);

    @Value("#{kidvisionProperties['youtube.client.secrets']}")
    private String youtubeClientSecrets;
    /**
     * Define a global instance of the HTTP transport.
     */
    public final HttpTransport HTTP_TRANSPORT = new NetHttpTransport();

    /**
     * Define a global instance of the JSON factory.
     */
    public final JsonFactory JSON_FACTORY = new JacksonFactory();

    /**
     * This is the directory that will be used under the user's home directory
     * where OAuth tokens will be stored.
     */
    //private final String CREDENTIALS_DIRECTORY = ".youtube-api-oauth-credentials";

    //private final String CLIENT_SECRETS_FILENAME = "/youtube_client_secrets.json";
    //private final String KIDVISION_HOME = System.getenv("KIDVISION_HOME") + "/vpk/";

    //private final String UPLOADED_VIDEOS_DIRECTORY = KIDVISION_HOME + "youtube_uploaded_videos/";

    public YoutubeAuth() {
    }

    @PostConstruct
    protected void init() {
        logger.info("initializing");
        logger.debug("youtubeClientSecrets = " + youtubeClientSecrets);
    }
    
    
    /**
     * Authorizes the installed application to access user's protected data.
     *
     * @param scopes list of scopes needed to run youtube upload.
     * @param credentialDatastore name of the credential datastore to cache
     * OAuth tokens
     */
    public Credential authorize(List<String> scopes, String credentialDatastore) throws IOException {

        // Load client secrets.
        //Reader clientSecretReader = new InputStreamReader(YoutubeAuth.class.getResourceAsStream(youtubeClientSecrets));
        Reader clientSecretReader = new StringReader(youtubeClientSecrets);
        GoogleClientSecrets clientSecrets = GoogleClientSecrets.load(JSON_FACTORY, clientSecretReader);

        // Checks that the defaults have been replaced (Default = "Enter X here").
        if (clientSecrets.getDetails().getClientId().startsWith("Enter")
                || clientSecrets.getDetails().getClientSecret().startsWith("Enter ")) {
            logger.debug("Enter Client ID and Secret from https://code.google.com/apis/console/?api=youtube"
                    + "into src/main/resources" + youtubeClientSecrets);
            return null;
        }

        // This creates the credentials datastore at ~/.oauth-credentials/${credentialDatastore}
        FileDataStoreFactory fileDataStoreFactory = new FileDataStoreFactory(new File(KidvisionWebConfig.KIDVISION_HOME + KidvisionWebConfig.CREDENTIALS_DIRECTORY));
        DataStore<StoredCredential> datastore = fileDataStoreFactory.getDataStore(credentialDatastore);

        GoogleAuthorizationCodeFlow flow = new GoogleAuthorizationCodeFlow.Builder(
                HTTP_TRANSPORT, JSON_FACTORY, clientSecrets, scopes).setCredentialDataStore(datastore)
                .build();

        // Build the local server and bind it to port 8080
        LocalServerReceiver localReceiver = new LocalServerReceiver.Builder().build(); // .setPort(58417)

        // Authorize.
        return new AuthorizationCodeInstalledApp(flow, localReceiver).authorize("user");
    }

}
