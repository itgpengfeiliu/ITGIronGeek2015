package com.cei.kidvisionweb.dao.impl;

import java.util.List;

import org.hibernate.transform.Transformers;

import com.cei.kidvisionweb.dao.UserModuleActivityDao;
import com.cei.kidvisionweb.db.model.UserModuleActivity;
import com.cei.kidvisionweb.db.model.UserModuleActivityFieldtripDatatable;


public class UserModuleActivityDaoImpl extends GenericDaoImpl<UserModuleActivity, Long> implements UserModuleActivityDao {

	@Override
	@SuppressWarnings("unchecked")
	public List<UserModuleActivityFieldtripDatatable> getUserModuleActivitiesFieldtrip() {
	  	List<UserModuleActivityFieldtripDatatable> resutls = null;
	  	try {
	  		String sql = " SELECT uma.id as id, uma.user_id as userId, uma.module_id as moduleId, uma.activity_type as activityType, "
	  				+ " uma.is_completed as isCompleted, uma.start_datetime as startDatetime, uma.end_datetime as endDatetime, "
	  				+ " m.title as title, u.first_name as firstName, u.last_name as lastName, u.email as email, u.is_active as isActive, u.phone as phone, "
	  				+ " u.school_name as schoolName, u.primary_address_Id as primaryAddressId, a.streetaddress as streetAddress, "
	  				+ " a.city as city, a.county as county, a.state as state, a.country as country, a.zipcode as zipCode "
	  				+ " FROM user_module_activity uma "
	  				+ " inner join user_module_test umt on uma.id = umt.user_module_activity_id"
	  				+ " inner join modules m on uma.module_id = m.id "
	  				+ " inner join users u on uma.user_id = u.id "
	  				+ " inner join address a on u.primary_address_Id = a.id "
	  				+ " where uma.activity_type = 'fieldtrip' and umt.is_completed = 1; ";
	      	resutls = getSession().createSQLQuery(sql).setResultTransformer(Transformers.aliasToBean(UserModuleActivityFieldtripDatatable.class)).list();
		} catch (Exception ex) {
			logger.error("Error occurred::", ex);
		}
		return resutls;
	}
	
//    @Override
//	@SuppressWarnings("unchecked")
//	public List<UserModuleActivity> getUserSurveyActivities(int userId, int moduleId) {
//	  	List<UserModuleActivity> activities = null;
//	  	try {
//	  		Calendar now = Calendar.getInstance();
//	  		int month = now.get(Calendar.MONTH)+1;
//	  		int year = now.get(Calendar.YEAR);
//	  		if (month <= 6) {
//	  			year = year - 1;
//	  		}
//	  		String sql = "select id, user_id as userId, module_id as moduleId, activity_type as activityType, "
//	      			+ " activity_name as activityName, is_completed as isCompleted, "
//	  				+ " start_datetime as startDatetime, end_datetime as endDatetime from  user_module_activity "
//	      			+ " where is_completed=1 and activity_type='survey' and user_id=" + userId + " and module_id=" + moduleId + " and date(start_datetime) > date('" + year + "-06-30') ;";
//	      	activities = getSession().createSQLQuery(sql).setResultTransformer(Transformers.aliasToBean(UserModuleActivity.class)).list();
//		} catch (Exception ex) {
//			logger.error("Error occurred::", ex);
//		}
//		return activities;
//	}
    
//    @Override
//	@SuppressWarnings("unchecked")
//	public List<UserModuleActivity> getUserModuleActivities(int userId, int moduleId) {
//	  	List<UserModuleActivity> activities = null;
//	  	try {
//	  		Calendar now = Calendar.getInstance();
//	  		int month = now.get(Calendar.MONTH)+1;
//	  		int year = now.get(Calendar.YEAR);
//	  		if (month <= 6) {
//	  			year = year - 1;
//	  		}
//	  		String sql = "select id, user_id as userId, module_id as moduleId, activity_type as activityType, "
//	      			+ " activity_name as activityName, is_completed as isCompleted, "
//	  				+ " start_datetime as startDatetime, end_datetime as endDatetime from  user_module_activity "
//	      			+ " where user_id=" + userId + " and module_id= " + moduleId + " and date(start_datetime) > date('" + year + "-06-30') ;";
//	      	activities = getSession().createSQLQuery(sql).setResultTransformer(Transformers.aliasToBean(UserModuleActivity.class)).list();
//		} catch (Exception ex) {
//			logger.error("Error occurred::", ex);
//		}
//		return activities;
//	 }
		
}
