
package com.cei.kidvisionweb.dao.impl;

import com.cei.kidvisionweb.dao.AuthenticationUserAnswerDao;
import com.cei.kidvisionweb.db.model.AuthenticationUserAnswer;
import org.hibernate.Query;

/**
 *
 * @author Shrikant
 */
public class AuthenticationUserAnswerDaoImpl extends GenericDaoImpl<AuthenticationUserAnswer, Long> implements AuthenticationUserAnswerDao{
    @Override
    public void deleteById(String id) {
        StringBuffer hql = new StringBuffer(
                "delete from "
                + getPersistentClass().getName() + " as model where id="
                + id);
        Query query = getSession().createQuery(hql.toString());
        query.executeUpdate();
    }
}
