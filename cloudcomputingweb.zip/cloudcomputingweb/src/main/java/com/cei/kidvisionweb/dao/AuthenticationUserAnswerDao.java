package com.cei.kidvisionweb.dao;

import com.cei.kidvisionweb.db.model.AuthenticationUserAnswer;

/**
 *
 * @author Shrikant
 */
public interface AuthenticationUserAnswerDao extends GenericDao<AuthenticationUserAnswer, Long> {
//    void add(AuthenticationUserAnswer object);
//
//    void update(AuthenticationUserAnswer object);
//
//    void delete(AuthenticationUserAnswer object);

    void deleteById(String id);
}
