package com.cei.kidvisionweb.dao;

import com.cei.kidvisionweb.db.model.RegistrationType;

/**
 *
 * @author Shrikant
 */
public interface RegistrationTypeDao extends GenericDao<RegistrationType, Long> {

//    void add(RegistrationType object);
//
//    void update(RegistrationType object);
//
//    void delete(RegistrationType object);

    void deleteById(String id);
}
