package com.cei.kidvisionweb.db.model;

import java.util.HashSet;
import java.util.Set;

import org.apache.commons.lang3.builder.ToStringBuilder;

public class Question  implements java.io.Serializable {

     /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	private Integer id;
    private Integer moduleId;
    private String standard;
    private Integer standardId;
    private String question;
    private Integer sequence;
    private short deleted;
     
    private Set<Answer> answers = new HashSet<Answer>(0);

    public Set<Answer> getAnswers() {
		return answers;
	}


	public void setAnswers(Set<Answer> answers) {
		this.answers = answers;
	}

    public Question() {
    }

    public Question(Integer moduleId, String standard, Integer standardId, String question, 
    		Integer sequence, short deleted) {
       this.moduleId = moduleId;
       this.standard = standard;
       this.standardId = standardId;
       this.question = question;
       this.sequence = sequence;
       this.deleted = deleted;
    }
   
    public Integer getId() {
        return this.id;
    }
    
    public void setId(Integer id) {
        this.id = id;
    }
    public Integer getModuleId() {
        return this.moduleId;
    }
    
    public void setModuleId(Integer moduleId) {
        this.moduleId = moduleId;
    }
    public String getStandard() {
        return this.standard;
    }
    
    public void setStandard(String standard) {
        this.standard = standard;
    }
    public Integer getStandardId() {
        return this.standardId;
    }
    
    public void setStandardId(Integer standardId) {
        this.standardId = standardId;
    }
    public String getQuestion() {
        return this.question;
    }
    
    public void setQuestion(String question) {
        this.question = question;
    }
    public Integer getSequence() {
        return this.sequence;
    }
    
    public void setSequence(Integer sequence) {
        this.sequence = sequence;
    }
    public short getDeleted() {
        return this.deleted;
    }
    
    public void setDeleted(short deleted) {
        this.deleted = deleted;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("id", id).
                append("moduleId", moduleId).
                append("standard", standard).
                append("standardId", standardId).
                append("question", question).
                append("sequence", sequence).
                append("deleted", deleted).
                toString();
    }


}


