package com.cei.kidvisionweb.config;

import java.security.SecureRandom;
import java.util.Random;

/**
 *
 * @author Shrikant
 */
public class KidvisionWebConfig {
    
    //@Value("#{kidvisionProperties['kidvision.directory']}")
    //private static String kidvisionDirectory;
    
    public static String CREDENTIALS_DIRECTORY = ".youtube-api-oauth-credentials";   
    public static String KIDVISION_HOME = System.getenv("KIDVISION_HOME") + "/vpk/"; // System.getProperty("KIDVISION_HOME") + "/vpk/";// 
    //public static String KIDVISION_HOME = "/opt/kidvision/vpk/"; // "/opt/kidvision/vpk/"; //  kidvisionDirectory + "/vpk/";
    public static String UPLOADED_VIDEOS_DIRECTORY = KIDVISION_HOME + "youtube_uploaded_videos/";
    public static String USER_MODULE_TEST_TRANSCRIPTS_DIRECTORY = KIDVISION_HOME + "user_module_transcripts/";
    public static String MODULE_IMAGE_DIRECTORY = KIDVISION_HOME + "module_images/";
    public static String MODULE_ICON_DIRECTORY = KIDVISION_HOME + "module_icons/";
    public static String MODULE_RESOURCE_IMAGE_DIRECTORY = KIDVISION_HOME + "module_resource_images/";
    public static String USER_MODULE_ACTIVITY_FIELDTRIP_DIRECTORY = KIDVISION_HOME + "user_module_activity_fieldtrip/";
    public static String CLASSROOM_MATERIALS_DIRECTORY = KIDVISION_HOME + "classroom_materials/";
        
    //public static String FORGOT_PASSWORD_EMAIL_SUBJECT = "Your VPK Account Login Information";
    //public static String FORGOT_USERNAME_EMAIL_SUBJECT ="Your VPK Account Login Information";
        
    public static String FORGOT_PASSWORD_EMAIL_TEXT(String firstName, String tmpPassword) {
    	String text = "<p>Hello " + firstName + " </p><p> Here is your login information: </p><p> Password: " + tmpPassword + " </p>Thank you, <br />Customer Support <br />KidVision VPK<br />";
    	return text;
    }
    
    public static String FORGOT_USERNAME_EMAIL_TEXT(String firstName, String username) {
    	String text = "<p>Hello " + firstName + " </p><p> Here is your login information: </p><p> UserName: " + username + " </p>Thank you, <br />Customer Support <br />KidVision VPK<br />";
    	return text;
    }
    
    public static String REGISTRATION_WELCOME_EMAIL_TEXT(String firstName, String username, String accountType) {
    	String text = "<p>Hello " + firstName + ", </p>"
    		+ "<p> Thank you for joining KidVision VPK!   You can now log into your KidVision VPK account at any time to enjoy Virtual Field Trips on your computer, tablet, or smartphone. </p>" 
    		+ "<p> Here is your <b>User Name</b>: " + username + " </p>"
    		+ "<ul>"
    			+ "<li>To log into your account, enter your user name and the password you selected during registration in the black boxes at the top right of the website. </li>"
    			+ "<li>If you know your user name but not your password, use the '<b>Forgot User Info</b>?' link to reset it.  A response will be sent immediately to the e-mail address listed on your user profile. </li>"
    		+ "</ul>"
    		+ "<p>There are two types of KidVision VPK accounts.  Your account is set up as <b>" + accountType + "</b>.</p>"	
    		+ "<p>1) <u><b>Standard Registration<b></u>.  If you joined KidVision VPK as a standard member (no charge) you now have access to our Virtual Field Trips to enjoy in your classroom or with your children, as   well as the corresponding Lesson Plans, Student Assessments, and Take Home Pages.  However, you do not have access to earning CEUs/In-Service Hours and you are not a member of the KidVisionTeachers Association professional organization.</p>"
    		+ "<p>2) <u><b>Teachers Association Membership</b></u>.  If you joined as a member of the KidVision Teachers Association ($30 annual fee) you have access to the above, plus these additional benefits:</p>"
    		+ "<ul>"
    			+ "<li>Ability to earn CEUs and In-Service Hours from your computer, tablet, or smartphone and print out transcripts of completed classes.</li>"
    			+ "<li>Certificate of membership in the KidVision Teachers Association, which satisfies the requirement of 'membership in a professional organization' for CDA renewal.</li>"
    			+ "<li>Monthly electronic newsletter to update you on KidVision VPK news, PBS kids programming, and PBS Learning Media highlights.</li>"
    			+ "<li>Daily classroom activities that promote standards for 4-year-olds on KidVision VPK Facebook, Twitter and Pinterest pages.</li>"
    		+ "</ul>"
    		+ "<p><i>Note:  KidVision Teachers Association members will receive a separate e-mail confirmation when the $30 annual fee is charged to their credit card.</i></p>"
    		+ "<p>If you have any questions, contact us at info@kidvisionvpk.org.</p>"  
    		+ "<br />Thank you for supporting KidVision VPK!<br />";
    	return text;
    }
    
    private static final Random RANDOM = new SecureRandom();
    
    public static String generateRandomPassword()
    {
        // Pick from some letters that won't be easily mistaken for each
        // other. So, for example, omit o O and 0, 1 l and L.
        String letters = "abcdefghjkmnpqrstuvwxyzABCDEFGHJKMNPQRSTUVWXYZ23456789";

        String pw = "";
        for (int i=0; i<8; i++)
        {
            int index = (int)(RANDOM.nextDouble()*letters.length());
            pw += letters.substring(index, index+1);
        }
        return pw;
    }
    
    public KidvisionWebConfig()
    {
        
    }
//    @PostConstruct
//    protected void init() {
//        this.KIDVISION_HOME = System.getenv("KIDVISION_HOME") + "/vpk/";
//        this.CREDENTIALS_DIRECTORY = ".youtube-api-oauth-credentials";
//        this.UPLOADED_VIDEOS_DIRECTORY = KIDVISION_HOME + "youtube_uploaded_videos/";
//        
//        logger.debug("KIDVISION_HOME = " + KIDVISION_HOME);
//        logger.debug("CREDENTIALS_DIRECTORY = " + CREDENTIALS_DIRECTORY);
//        logger.debug("UPLOADED_VIDEOS_DIRECTORY = " + UPLOADED_VIDEOS_DIRECTORY);
//    }
//    public String getCredentialsDirectory()
//    {
//        return this.CREDENTIALS_DIRECTORY;
//    }
//    public String getKidvisionHome()
//    {
//        return this.KIDVISION_HOME;
//    }
//    public String getUploadVideoDirectory()
//    {
//        return this.UPLOADED_VIDEOS_DIRECTORY;
//    }
}
