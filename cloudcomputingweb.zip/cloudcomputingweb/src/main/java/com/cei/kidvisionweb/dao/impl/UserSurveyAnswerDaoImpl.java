package com.cei.kidvisionweb.dao.impl;

import java.util.List;

import org.hibernate.transform.Transformers;

import com.cei.kidvisionweb.dao.UserSurveyAnswerDao;
import com.cei.kidvisionweb.db.model.UserSurveyAnswer;
import com.cei.kidvisionweb.db.model.UserSurveyAnswerResult;

public class UserSurveyAnswerDaoImpl extends GenericDaoImpl<UserSurveyAnswer, Long> implements UserSurveyAnswerDao {

	@Override
	@SuppressWarnings("unchecked")
	public List<UserSurveyAnswerResult> getUserSurveyAnswers() {
	  	List<UserSurveyAnswerResult> resutls = null;
	  	try {
	  		String sql = "select survey_question_id as question, survey_answer_yes_no as yes, count(id) as no "
	      			+ " from user_survey_answers where module_id is not null and module_id != 0 "
	  				+ " group by survey_question_id, survey_answer_yes_no ";
	      	resutls = getSession().createSQLQuery(sql).setResultTransformer(Transformers.aliasToBean(UserSurveyAnswerResult.class)).list();
		} catch (Exception ex) {
			logger.error("Error occurred::", ex);
		}
		return resutls;
	 }
}
