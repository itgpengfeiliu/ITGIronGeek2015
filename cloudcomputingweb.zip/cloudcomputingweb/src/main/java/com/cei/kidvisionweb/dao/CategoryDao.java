package com.cei.kidvisionweb.dao;

import com.cei.kidvisionweb.db.model.Categorie;

public interface CategoryDao extends GenericDao<Categorie, Long> {

}
