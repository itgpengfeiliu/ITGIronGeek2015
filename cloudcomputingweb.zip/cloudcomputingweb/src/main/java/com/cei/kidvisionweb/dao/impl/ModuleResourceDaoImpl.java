package com.cei.kidvisionweb.dao.impl;

import com.cei.kidvisionweb.dao.ModuleResourceDao;
import com.cei.kidvisionweb.db.model.ModuleResource;

public class ModuleResourceDaoImpl extends GenericDaoImpl<ModuleResource, Long> implements ModuleResourceDao {

}
