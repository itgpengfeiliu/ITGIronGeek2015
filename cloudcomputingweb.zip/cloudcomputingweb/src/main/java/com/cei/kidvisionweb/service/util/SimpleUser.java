package com.cei.kidvisionweb.service.util;

import java.util.Date;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.cei.kidvisionweb.db.model.Config;
import com.cei.kidvisionweb.db.model.Registration;
import com.cei.kidvisionweb.db.model.User;

public class SimpleUser implements java.io.Serializable {

	private Integer id  = null;
    private String firstName = null;
    private String lastName  = null;
    private String middleName  = null;
    private String userName = null;
    //private String password;
    private String email  = null;
    private byte roleId = -1;
    private Integer occupationalTitleId = null;
    private String otherOccupationalTitle = null;
    private Boolean emailNotification;
    private String phone = null;
    private String facilityType = null;
    private Byte registrationtypeId = -1;
    private Integer currentRegistrationId = null;
    private Integer primaryAddressId = null;
    private Integer billingAddressId = null;
    private Integer shippingAddressId = null;
    private byte pretestCompleted = 2;
    //private Date createdOn;
    //private Date updatedOn;
    //private Integer createdbyId;
    //private Integer updatedbyId;
    private short isActive = 2;
    private short passwordReset = 2;
    private String prefix;
    private String schoolName;
    
    private Date currentSchoolYearFrom = null;
    private Date currentSchoolYearTo = null;
    
    private Integer registrationId = null;
    private Date fromDatetime = null;
    private Date toDatetime = null;
    private Boolean isRegistrationActive = null;
    private short isPaid = 0;
    
    private int processPayment = 0;
	
    private static final long serialVersionUID = 1L;

    public static long getSerialversionuid() {
        return serialVersionUID;
    }

    public SimpleUser() {
    }


    public SimpleUser(LoggedUser user, boolean hahah, int processPayment) {
    	this.id = user.getId();
        this.firstName = user.getFirstName();
        this.lastName = user.getLastName();
        this.userName = user.getUsername();
        this.email = user.getEmail();
        this.roleId = user.getRoleId();
        this.isActive = user.isEnabled() ? (short) 1 : (short) 0;
        this.registrationtypeId = user.getRegistrationtypeId();
        
        this.processPayment = processPayment;
    }
    
    public SimpleUser(User user, Config config, Registration registration, int processPayment) {
    	this.id = user.getId();
        this.firstName = user.getFirstName();
        this.lastName = user.getLastName();
        this.middleName = user.getMiddleName();
        this.userName = user.getUserName();
        //this.password = password;
        this.email = user.getEmail();
        this.roleId = user.getRoleId();
        this.occupationalTitleId = user.getOccupationalTitleId();
        this.otherOccupationalTitle = user.getOtherOccupationalTitle();
        this.emailNotification = user.getEmailNotification();
        this.phone = user.getPhone();
        this.registrationtypeId = user.getRegistrationtypeId();
        this.currentRegistrationId = user.getCurrentRegistrationId();
        this.primaryAddressId = user.getPrimaryAddressId();
        this.billingAddressId = user.getBillingAddressId();
        this.shippingAddressId = user.getShippingAddressId();
        this.pretestCompleted = user.getPretestCompleted();
        //this.createdOn = user.getCreatedOn();
        //this.updatedOn = user.getUpdatedOn();
        //this.createdbyId = user.getCreatedbyId();
        //this.updatedbyId = user.getUpdatedbyId();
        this.isActive = user.getIsActive();
        this.passwordReset = user.getPasswordReset();
        this.prefix = user.getPrefix();
        this.schoolName = user.getSchoolName();
                
        if (config != null) {
        	this.currentSchoolYearFrom = config.getCurrentSchoolYearFrom();
        	this.currentSchoolYearTo = config.getCurrentSchoolYearTo();
        }
        
        if (registration != null) {
        	this.registrationId = registration.getId();
	        this.fromDatetime = registration.getFromDatetime();
	        this.toDatetime = registration.getToDatetime();
	        this.isRegistrationActive = registration.getIsActive();
	        this.isPaid = registration.getIsPaid();
        }
        
        this.processPayment = processPayment;
    }
    
    public SimpleUser(User user) {
    	this.id = user.getId();
        this.firstName = user.getFirstName();
        this.lastName = user.getLastName();
        this.middleName = user.getMiddleName();
        this.userName = user.getUserName();
        //this.password = password;
        this.email = user.getEmail();
        this.roleId = user.getRoleId();
        this.occupationalTitleId = user.getOccupationalTitleId();
        this.otherOccupationalTitle = user.getOtherOccupationalTitle();
        this.emailNotification = user.getEmailNotification();
        this.phone = user.getPhone();
        this.registrationtypeId = user.getRegistrationtypeId();
        this.currentRegistrationId = user.getCurrentRegistrationId();
        this.primaryAddressId = user.getPrimaryAddressId();
        this.billingAddressId = user.getBillingAddressId();
        this.shippingAddressId = user.getShippingAddressId();
        this.pretestCompleted = user.getPretestCompleted();
        //this.createdOn = user.getCreatedOn();
        //this.updatedOn = user.getUpdatedOn();
        //this.createdbyId = user.getCreatedbyId();
        //this.updatedbyId = user.getUpdatedbyId();
        this.isActive = user.getIsActive();
        this.passwordReset = user.getPasswordReset();
        this.prefix = user.getPrefix();
        this.schoolName = user.getSchoolName();
    }

    public Integer getId() {
        return this.id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getFirstName() {
        return this.firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return this.lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getMiddleName() {
        return this.middleName;
    }

    public void setMiddleName(String middleName) {
        this.middleName = middleName;
    }

    public String getUserName() {
        return this.userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

//    public String getPassword() {
//        return this.password;
//    }
//
//    public void setPassword(String password) {
//        this.password = password;
//    }

    public String getEmail() {
        return this.email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public byte getRoleId() {
        return this.roleId;
    }

    public void setRoleId(byte roleId) {
        this.roleId = roleId;
    }

    public Integer getOccupationalTitleId() {
        return this.occupationalTitleId;
    }

    public void setOccupationalTitleId(Integer occupationalTitleId) {
        this.occupationalTitleId = occupationalTitleId;
    }

    public String getOtherOccupationalTitle() {
        return this.otherOccupationalTitle;
    }

    public void setOtherOccupationalTitle(String otherOccupationalTitle) {
        this.otherOccupationalTitle = otherOccupationalTitle;
    }

    public Boolean getEmailNotification() {
        return this.emailNotification;
    }

    public void setEmailNotification(Boolean emailNotification) {
        this.emailNotification = emailNotification;
    }

    public String getPhone() {
        return this.phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public Byte getRegistrationtypeId() {
        return this.registrationtypeId;
    }

    public void setRegistrationtypeId(Byte registrationtypeId) {
        this.registrationtypeId = registrationtypeId;
    }

    public Integer getCurrentRegistrationId() {
        return this.currentRegistrationId;
    }

    public void setCurrentRegistrationId(Integer currentRegistrationId) {
        this.currentRegistrationId = currentRegistrationId;
    }

    public Integer getPrimaryAddressId() {
        return this.primaryAddressId;
    }

    public void setPrimaryAddressId(Integer primaryAddressId) {
        this.primaryAddressId = primaryAddressId;
    }

    public Integer getBillingAddressId() {
        return this.billingAddressId;
    }

    public void setBillingAddressId(Integer billingAddressId) {
        this.billingAddressId = billingAddressId;
    }

    public Integer getShippingAddressId() {
        return this.shippingAddressId;
    }

    public void setShippingAddressId(Integer shippingAddressId) {
        this.shippingAddressId = shippingAddressId;
    }

    public byte getPretestCompleted() {
		return pretestCompleted;
	}

//	public Date getCreatedOn() {
//        return this.createdOn;
//    }
//
//    public void setCreatedOn(Date createdOn) {
//        this.createdOn = createdOn;
//    }
//
//    public Date getUpdatedOn() {
//        return this.updatedOn;
//    }
//
//    public void setUpdatedOn(Date updatedOn) {
//        this.updatedOn = updatedOn;
//    }
//
//    public Integer getCreatedbyId() {
//        return this.createdbyId;
//    }
//
//    public void setCreatedbyId(Integer createdbyId) {
//        this.createdbyId = createdbyId;
//    }
//
//    public Integer getUpdatedbyId() {
//        return this.updatedbyId;
//    }
//
//    public void setUpdatedbyId(Integer updatedbyId) {
//        this.updatedbyId = updatedbyId;
//    }

    public String getFacilityType() {
		return facilityType;
	}

	public void setFacilityType(String facilityType) {
		this.facilityType = facilityType;
	}

	public void setPretestCompleted(byte pretestCompleted) {
		this.pretestCompleted = pretestCompleted;
	}

	public short getIsActive() {
        return this.isActive;
    }

    public void setIsActive(short isActive) {
        this.isActive = isActive;
    }
    
    public short getPasswordReset() {
		return passwordReset;
	}

	public void setPasswordReset(short passwordReset) {
		this.passwordReset = passwordReset;
	}

	public String getPrefix() {
		return prefix;
	}

	public void setPrefix(String prefix) {
		this.prefix = prefix;
	}
		
	public String getSchoolName() {
		return schoolName;
	}

	public void setSchoolName(String schoolName) {
		this.schoolName = schoolName;
	}

	public Date getCurrentSchoolYearFrom() {
		return currentSchoolYearFrom;
	}

	public void setCurrentSchoolYearFrom(Date currentSchoolYearFrom) {
		this.currentSchoolYearFrom = currentSchoolYearFrom;
	}

	public Date getCurrentSchoolYearTo() {
		return currentSchoolYearTo;
	}

	public void setCurrentSchoolYearTo(Date currentSchoolYearTo) {
		this.currentSchoolYearTo = currentSchoolYearTo;
	}

	public Date getFromDatetime() {
		return fromDatetime;
	}

	public void setFromDatetime(Date fromDatetime) {
		this.fromDatetime = fromDatetime;
	}

	public Date getToDatetime() {
		return toDatetime;
	}

	public void setToDatetime(Date toDatetime) {
		this.toDatetime = toDatetime;
	}

	public Boolean getIsRegistrationActive() {
		return isRegistrationActive;
	}

	public void setIsRegistrationActive(Boolean isRegistrationActive) {
		this.isRegistrationActive = isRegistrationActive;
	}
	
	public Integer getRegistrationId() {
		return registrationId;
	}

	public void setRegistrationId(Integer registrationId) {
		this.registrationId = registrationId;
	}
	
	public int getProcessPayment() {
		return processPayment;
	}

	public void setProcessPayment(int processPayment) {
		this.processPayment = processPayment;
	}

	public short getIsPaid() {
		return isPaid;
	}

	public void setIsPaid(short isPaid) {
		this.isPaid = isPaid;
	}

	@Override
    public String toString() {
        return new ToStringBuilder(this).append("id", id).
                append("firstName", firstName).
                append("lastName", lastName).
                append("middleName", middleName).
                append("userName", userName).
                //append("password", password).
                append("email", email).
                append("roleId", Integer.toString(roleId)).
                append("occupationalTitleId", occupationalTitleId).
                append("otherOccupationalTitle", otherOccupationalTitle).
                append("emailNotification", emailNotification).
                append("phone", phone).
                append("isActive", isActive).
                append("facilityType", facilityType).
                append("roleId", roleId).
                append("registrationtypeId", registrationtypeId).
                append("currentRegistrationId", currentRegistrationId).
                append("primaryAddressId", primaryAddressId).
                append("billingAddressId", billingAddressId).
                append("shippingAddressId", shippingAddressId).
                append("pretestCompleted", pretestCompleted).
//                append("createdOn", createdOn).
//                append("updatedOn", updatedOn).
//                append("createdbyId", createdbyId).
//                append("updatedbyId", updatedbyId).
                append("passwordReset", passwordReset).
                append("prefix", prefix).
                append("schoolName", schoolName).
                append("currentSchoolYearFrom", currentSchoolYearFrom).
                append("currentSchoolYearTo", currentSchoolYearTo).
                append("registrationId", registrationId).
                append("fromDatetime", fromDatetime).
                append("toDatetime", toDatetime).
                append("isRegistrationActive", isRegistrationActive).
                append("isPaid", isPaid).
                append("processPayment", processPayment).
                toString();
    }
}