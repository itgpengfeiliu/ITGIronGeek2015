package com.cei.kidvisionweb.db.model;

import org.apache.commons.lang3.builder.ToStringBuilder;

public class RegistrationType  implements java.io.Serializable {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	private byte id;
    private String registrationtypeName;

    public RegistrationType() {
    }

	
    public RegistrationType(byte id) {
        this.id = id;
    }
    public RegistrationType(byte id, String registrationtypeName) {
       this.id = id;
       this.registrationtypeName = registrationtypeName;
    }
   
    public byte getId() {
        return this.id;
    }
    
    public void setId(byte id) {
        this.id = id;
    }
    public String getRegistrationtypeName() {
        return this.registrationtypeName;
    }
    
    public void setRegistrationtypeName(String registrationtypeName) {
        this.registrationtypeName = registrationtypeName;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("id", id).
                append("registrationtypeName", registrationtypeName).
                toString();
    }


}


