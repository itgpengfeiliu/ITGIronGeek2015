package com.cei.kidvisionweb.service.util;

import com.cei.kidvisionweb.config.KidvisionWebConfig;
import com.cei.kidvisionweb.dao.VideoDao;
import com.google.api.client.auth.oauth2.Credential;
import com.google.api.client.googleapis.json.GoogleJsonResponseException;
import com.google.api.client.googleapis.media.MediaHttpUploader;
import com.google.api.client.googleapis.media.MediaHttpUploaderProgressListener;
import com.google.api.client.http.InputStreamContent;
import com.google.api.services.youtube.YouTube;
import com.google.api.services.youtube.model.Channel;
import com.google.api.services.youtube.model.ChannelListResponse;
import com.google.api.services.youtube.model.PlaylistItem;
import com.google.api.services.youtube.model.PlaylistItemListResponse;
import com.google.api.services.youtube.model.Video;
import com.google.api.services.youtube.model.VideoSnippet;
import com.google.api.services.youtube.model.VideoStatus;
import com.google.common.collect.Lists;
import com.google.gson.GsonBuilder;
import com.sun.jersey.api.core.InjectParam;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.TransactionTemplate;
import org.springframework.util.Assert;

/**
 *
 * @author Shrikant
 */
public class VideoProcessor {

    private static Logger logger = LoggerFactory.getLogger(VideoProcessor.class);
    
    private final TransactionTemplate transactionTemplate;
    
    @Autowired
    private VideoDao videoDao;

    @InjectParam
    private YoutubeAuth youTubeAuth;
    
    /**
     * Define a global instance of a Youtube object, which will be used to make
     * YouTube Data API requests.
     */
    private static YouTube youtube;

    /**
     * Define a global variable that specifies the MIME type of the video being
     * uploaded. Make sure that you’re using one of the following formats .MOV
     * .MPEG4 .AVI .WMV .MPEGPS .FLV .3GPP .WebM
     */
    private static final String VIDEO_FILE_FORMAT = "video/*";

    private static final int KB = 0x400;
    
    @Autowired
    public VideoProcessor( PlatformTransactionManager transactionManager) {
        Assert.notNull(transactionManager, "The 'transactionManager' argument must not be null.");
        this.transactionTemplate = new TransactionTemplate(transactionManager);
        this.transactionTemplate.setPropagationBehavior(TransactionDefinition.PROPAGATION_REQUIRES_NEW);
        this.transactionTemplate.setTimeout(30);
        logger.debug("transaction template = " + transactionTemplate);
    }

    @Async
    @Transactional
    public String uploadVideo(String fileName, int userId, int moduleId, short isOverview, Byte sequence) {

        List<String> scopes = Lists.newArrayList("https://www.googleapis.com/auth/youtube.upload");

        try {
            String videoFilename = fileName;
            logger.debug("uploadVideo: " + videoFilename);

            // Authorize the request.
            Credential credential = youTubeAuth.authorize(scopes, "YoutubeUploadVideoImpl");

            logger.debug("check youtube api credentials.");
            if (credential == null) {
                logger.debug("youtube api credentials is null. cancel upload.");
                return null;
            }
            logger.debug("valid youtube api credentials. authenticate and build youtube");
            // This object is used to make YouTube Data API requests.
            youtube = new YouTube.Builder(youTubeAuth.HTTP_TRANSPORT, youTubeAuth.JSON_FACTORY, credential).setApplicationName("KidVisionWeb").build();
            logger.debug("authenticated and build");
            // Add extra information to the video before uploading.
            Video videoObjectDefiningMetadata = new Video();
            logger.debug("set the video status to 'unlisted'.");
            // Set the video to be publicly visible. This is the default
            // setting. Other supporting settings are "unlisted" and "private."
            VideoStatus status = new VideoStatus();
            status.setPrivacyStatus("unlisted"); // public
            videoObjectDefiningMetadata.setStatus(status);
            logger.debug("video status set to 'unlisted'.");
            // Most of the video's metadata is set on the VideoSnippet object.
            VideoSnippet snippet = new VideoSnippet();

            // This code uses a Calendar instance to create a unique name and
            // description for test purposes so that you can easily upload
            // multiple files. You should remove this code from your project
            // and use your own standard names instead.
            //Calendar cal = Calendar.getInstance();
            snippet.setTitle(videoFilename.substring(0, videoFilename.indexOf('.')));
            Date date = new Date();
            snippet.setDescription("learning video upload : " + date.toString());

            // Set the keyword tags that you want to associate with the video.
            List<String> tags = new ArrayList<String>();
            tags.add("test");
            tags.add("YouTube Data API V3");
            tags.add("erase me");
            snippet.setTags(tags);

            // Add the completed snippet object to the video resource.
            videoObjectDefiningMetadata.setSnippet(snippet);

            InputStreamContent mediaContent = new InputStreamContent(VIDEO_FILE_FORMAT,
                    new FileInputStream(KidvisionWebConfig.UPLOADED_VIDEOS_DIRECTORY + videoFilename));

            //mediaContent.setLength(fileDetail.getSize()); // ??
            // Insert the video. The command sends three arguments. The first
            // specifies which information the API request is setting and which
            // information the API response should return. The second argument
            // is the video resource that contains metadata about the new video.
            // The third argument is the actual video content.
            YouTube.Videos.Insert videoInsert = youtube.videos()
                    .insert("snippet,statistics,status", videoObjectDefiningMetadata, mediaContent);
            logger.debug("set the video data");
            // Set the upload type and add an event listener.
            MediaHttpUploader uploader = videoInsert.getMediaHttpUploader();

            // Indicate whether direct media upload is enabled. A value of
            // "True" indicates that direct media upload is enabled and that
            // the entire media content will be uploaded in a single request.
            // A value of "False," which is the default, indicates that the
            // request will use the resumable media upload protocol, which
            // supports the ability to resume an upload operation after a
            // network interruption or other transmission failure, saving
            // time and bandwidth in the event of network failures.
            uploader.setDirectUploadEnabled(false);

            int minimumChunkSize = 256 * KB;
            // The default chunk size is 10MB, here will use 1MB.
            uploader.setChunkSize(minimumChunkSize * 4);
            logger.debug("getChunkSize : " + uploader.getChunkSize());
            logger.debug("define http uploader listener.");
            MediaHttpUploaderProgressListener progressListener = new MediaHttpUploaderProgressListener() {
                public void progressChanged(MediaHttpUploader uploader) throws IOException {
                    switch (uploader.getUploadState()) {
                        case INITIATION_STARTED:
                            logger.debug("Initiation Started");
                            break;
                        case INITIATION_COMPLETE:
                            logger.debug("Initiation Completed");
                            break;
                        case MEDIA_IN_PROGRESS:
                            logger.debug("Upload in progress");
                            logger.debug("Upload number of bytes : " + uploader.getNumBytesUploaded());
                            break;
                        case MEDIA_COMPLETE:
                            logger.debug("Upload Completed!");
                            break;
                        case NOT_STARTED:
                            logger.debug("Upload Not Started!");
                            break;
                    }
                }
            };
            uploader.setProgressListener(progressListener);
            logger.debug("http uploader listener attached to uploader.");
            // Call the API and upload the video.
            Video returnedVideo = videoInsert.execute();
            String videoId = returnedVideo.getId();

            // Print data about the newly inserted video from the API response.
            logger.debug("\n================== Returned Video ==================\n");
            logger.debug("  - Id: " + videoId);
            logger.debug("  - Title: " + returnedVideo.getSnippet().getTitle());
            logger.debug("  - Tags: " + returnedVideo.getSnippet().getTags());
            logger.debug("  - Privacy Status: " + returnedVideo.getStatus().getPrivacyStatus());
            logger.debug("  - Video Count: " + returnedVideo.getStatistics().getViewCount());

//            com.cei.kidvisionweb.db.model.Video videoModel = new com.cei.kidvisionweb.db.model.Video();
//            videoModel.setVideoStreamingId(videoId);
//			videoDao.add(videoModel);
            logger.debug("upload complete, videoId: " + videoId);
            
            com.cei.kidvisionweb.db.model.Video videoModel = videoDao.getByProperties("moduleId", Integer.toString(moduleId), "isOverview", Integer.toString(isOverview));
            if (videoModel == null) {
            	videoModel = new com.cei.kidvisionweb.db.model.Video();
            	videoModel.setCreatedbyId(userId);
                videoModel.setModuleId(moduleId);
                videoModel.setFileName(fileName);
                videoModel.setCreatedOn(new Date());
                videoModel.setIsOverview(isOverview);
                videoModel.setSequence(sequence);
                videoModel.setVideoStreamingId(videoId);
                
                videoDao.add(videoModel);
            }
            else {
            	videoModel.setCreatedbyId(userId);
                videoModel.setModuleId(moduleId);
                videoModel.setFileName(fileName);
                videoModel.setCreatedOn(new Date());
                videoModel.setIsOverview(isOverview);
                videoModel.setSequence(sequence);
                videoModel.setVideoStreamingId(videoId);
                
                videoDao.update(videoModel);
            }
            String result = new GsonBuilder().serializeNulls().create().toJson(videoModel);
            return result;

        } catch (GoogleJsonResponseException e) {
            logger.error("GoogleJsonResponseException code: " + e.getDetails().getCode() + " : "
                    + e.getDetails().getMessage());
        } catch (IOException e) {
            logger.error("IOException: " + e.getMessage());
        } catch (Throwable t) {
            logger.error("Throwable: " + t.getMessage());
        }

        return null;
    }

//    public boolean writeToFile(InputStream uploadedInputStream, FormDataContentDisposition fileDetail) {
//        
//        try {
//        	String videoFilename = fileDetail.getFileName();
//        	logger.debug("uploadVideo writeToFile " + videoFilename);
//        	
//            OutputStream out = new FileOutputStream(new File(YoutubeAuth.UPLOADED_VIDEOS_DIRECTORY + videoFilename));
//            
//            int read = 0;
//            byte[] bytes = new byte[1024];
//
//            while ((read = uploadedInputStream.read(bytes)) != -1) {
//                out.write(bytes, 0, read);
//            }
//            out.flush();
//            out.close();
//
//            return true;
//        } catch (IOException e) {
//            logger.error("IOException: " + e.getMessage());
//        }
//
//        return false;
//    }
    public String getYoutubeVideoList() {

        // This OAuth 2.0 access scope allows for read-only access to the
        // authenticated user's account, but not other types of account access.
        List<String> scopes = Lists.newArrayList("https://www.googleapis.com/auth/youtube.readonly");

        try {
            // Authorize the request.
            Credential credential = youTubeAuth.authorize(scopes, "myuploads");

            // This object is used to make YouTube Data API requests.
            youtube = new YouTube.Builder(youTubeAuth.HTTP_TRANSPORT, youTubeAuth.JSON_FACTORY, credential).setApplicationName(
                    "KidVisionWeb").build();

            // Call the API's channels.list method to retrieve the
            // resource that represents the authenticated user's channel.
            // In the API response, only include channel information needed for
            // this use case. The channel's contentDetails part contains
            // playlist IDs relevant to the channel, including the ID for the
            // list that contains videos uploaded to the channel.
            YouTube.Channels.List channelRequest = youtube.channels().list("contentDetails");
            channelRequest.setMine(true);
            channelRequest.setFields("items/contentDetails,nextPageToken,pageInfo");
            ChannelListResponse channelResult = channelRequest.execute();

            List<Channel> channelsList = channelResult.getItems();

            if (channelsList != null) {
                // The user's default channel is the first item in the list.
                // Extract the playlist ID for the channel's videos from the
                // API response.
                String uploadPlaylistId
                        = channelsList.get(0).getContentDetails().getRelatedPlaylists().getUploads();

                // Define a list to store items in the list of uploaded videos.
                List<PlaylistItem> playlistItemList = new ArrayList<PlaylistItem>();

                // Retrieve the playlist of the channel's uploaded videos.
                YouTube.PlaylistItems.List playlistItemRequest
                        = youtube.playlistItems().list("id,contentDetails,snippet");
                playlistItemRequest.setPlaylistId(uploadPlaylistId);

                // Only retrieve data used in this application, thereby making
                // the application more efficient. See:
                // https://developers.google.com/youtube/v3/getting-started#partial
                playlistItemRequest.setFields(
                        "items(contentDetails/videoId,snippet/title,snippet/publishedAt),nextPageToken,pageInfo");

                String nextToken = "";

                // Call the API one or more times to retrieve all items in the
                // list. As long as the API response returns a nextPageToken,
                // there are still more items to retrieve.
                do {
                    playlistItemRequest.setPageToken(nextToken);
                    PlaylistItemListResponse playlistItemResult = playlistItemRequest.execute();

                    playlistItemList.addAll(playlistItemResult.getItems());

                    nextToken = playlistItemResult.getNextPageToken();
                } while (nextToken != null);

                // Prints information about the results.
                //prettyPrint(playlistItemList.size(), playlistItemList.iterator());
                return new GsonBuilder().serializeNulls().create().toJson(playlistItemList);
            }

        } catch (GoogleJsonResponseException e) {
            logger.error("There was a service error: " + e.getDetails().getCode() + " : "
                    + e.getDetails().getMessage());

        } catch (Throwable t) {
            logger.error("Error occurred::", t);
        }
        return null;
    }
    
    public List<PlaylistItem> getYoutubeVideoTitleIdList() {

        // This OAuth 2.0 access scope allows for read-only access to the
        // authenticated user's account, but not other types of account access.
        List<String> scopes = Lists.newArrayList("https://www.googleapis.com/auth/youtube.readonly");

        try {
            // Authorize the request.
            Credential credential = youTubeAuth.authorize(scopes, "myuploads");

            // This object is used to make YouTube Data API requests.
            youtube = new YouTube.Builder(youTubeAuth.HTTP_TRANSPORT, youTubeAuth.JSON_FACTORY, credential).setApplicationName(
                    "KidVisionWeb").build();

            // Call the API's channels.list method to retrieve the
            // resource that represents the authenticated user's channel.
            // In the API response, only include channel information needed for
            // this use case. The channel's contentDetails part contains
            // playlist IDs relevant to the channel, including the ID for the
            // list that contains videos uploaded to the channel.
            YouTube.Channels.List channelRequest = youtube.channels().list("contentDetails");
            channelRequest.setMine(true);
            channelRequest.setFields("items/contentDetails,nextPageToken,pageInfo");
            ChannelListResponse channelResult = channelRequest.execute();

            List<Channel> channelsList = channelResult.getItems();

            if (channelsList != null) {
                // The user's default channel is the first item in the list.
                // Extract the playlist ID for the channel's videos from the
                // API response.
                String uploadPlaylistId
                        = channelsList.get(0).getContentDetails().getRelatedPlaylists().getUploads();

                // Define a list to store items in the list of uploaded videos.
                List<PlaylistItem> playlistItemList = new ArrayList<PlaylistItem>();

                // Retrieve the playlist of the channel's uploaded videos.
                YouTube.PlaylistItems.List playlistItemRequest
                        = youtube.playlistItems().list("id,contentDetails,snippet");
                playlistItemRequest.setPlaylistId(uploadPlaylistId);

                // Only retrieve data used in this application, thereby making
                // the application more efficient. See:
                // https://developers.google.com/youtube/v3/getting-started#partial
                playlistItemRequest.setFields(
                        "items(contentDetails/videoId,snippet/title),nextPageToken,pageInfo");

                String nextToken = "";

                // Call the API one or more times to retrieve all items in the
                // list. As long as the API response returns a nextPageToken,
                // there are still more items to retrieve.
                do {
                    playlistItemRequest.setPageToken(nextToken);
                    PlaylistItemListResponse playlistItemResult = playlistItemRequest.execute();

                    playlistItemList.addAll(playlistItemResult.getItems());

                    nextToken = playlistItemResult.getNextPageToken();
                } while (nextToken != null);

                // Prints information about the results.
                //prettyPrint(playlistItemList.size(), playlistItemList.iterator());
                return playlistItemList;
            }

        } catch (GoogleJsonResponseException e) {
            logger.error("There was a service error: " + e.getDetails().getCode() + " : "
                    + e.getDetails().getMessage());

        } catch (Throwable t) {
            logger.error("Error occurred::", t);
        }
        return null;
    }

    /*
     * Print information about all of the items in the playlist.
     *
     * @param size size of list
     *
     * @param iterator of Playlist Items from uploaded Playlist
     */
//    private static void prettyPrint(int size, Iterator<PlaylistItem> playlistEntries) {
//        System.out.println("=============================================================");
//        System.out.println("\t\tTotal Videos Uploaded: " + size);
//        System.out.println("=============================================================\n");
//
//        while (playlistEntries.hasNext()) {
//            PlaylistItem playlistItem = playlistEntries.next();
//            System.out.println(" video name  = " + playlistItem.getSnippet().getTitle());
//            System.out.println(" video id    = " + playlistItem.getContentDetails().getVideoId());
//            System.out.println(" upload date = " + playlistItem.getSnippet().getPublishedAt());
//            System.out.println("\n-------------------------------------------------------------\n");
//        }
//    }
}
