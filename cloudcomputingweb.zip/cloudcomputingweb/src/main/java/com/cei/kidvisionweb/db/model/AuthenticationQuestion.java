

package com.cei.kidvisionweb.db.model;

import org.apache.commons.lang3.builder.ToStringBuilder;

/**
 *
 * @author Shrikant
 */
public class AuthenticationQuestion implements java.io.Serializable {


     /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	private Integer id;
    private String question;

    public AuthenticationQuestion() {
    }

	
    public AuthenticationQuestion(Integer id) {
        this.id = id;
    }
    public AuthenticationQuestion(Integer id, String question) {
       this.id = id;
       this.question = question;
    }
   
    public Integer getId() {
        return this.id;
    }
    
    public void setId(Integer id) {
        this.id = id;
    }
    public String getQuestion() {
        return this.question;
    }
    
    public void setQuestion(String question) {
        this.question = question;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("id", id).
                append("question", question).
                toString();
    }


}
