package com.cei.kidvisionweb.dao.impl;

import com.cei.kidvisionweb.dao.SurveyResultDao;
import com.cei.kidvisionweb.db.model.SurveyResult;

public class SurveyResultDaoImpl extends GenericDaoImpl<SurveyResult, Long> implements SurveyResultDao {

}
