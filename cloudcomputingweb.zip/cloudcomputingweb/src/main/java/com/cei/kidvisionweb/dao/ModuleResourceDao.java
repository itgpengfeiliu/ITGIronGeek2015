package com.cei.kidvisionweb.dao;

import com.cei.kidvisionweb.db.model.ModuleResource;

public interface ModuleResourceDao extends GenericDao<ModuleResource, Long> {

}
