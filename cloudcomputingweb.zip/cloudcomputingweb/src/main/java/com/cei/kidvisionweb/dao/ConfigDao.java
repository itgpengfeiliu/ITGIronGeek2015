package com.cei.kidvisionweb.dao;

import com.cei.kidvisionweb.db.model.Config;

public interface ConfigDao extends GenericDao<Config, Long> {

}
