package com.cei.kidvisionweb.db.model;



import java.util.Date;

import org.apache.commons.lang3.builder.ToStringBuilder;


public class SurveyQuestion  implements java.io.Serializable {

     /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private Integer id;
    private String question;
    private Integer sequence;
    private Byte deleted;
    private Date createdOn;
    private Integer createdBy;
    private Date modifiedOn;
    private Integer modifiedBy;

    public SurveyQuestion() {
    }

    public SurveyQuestion(String question, Integer sequence, Byte deleted, Date createdOn, Integer createdBy, Date modifiedOn, Integer modifiedBy) {
       this.question = question;
       this.sequence = sequence;
       this.deleted = deleted;
       this.createdOn = createdOn;
       this.createdBy = createdBy;
       this.modifiedOn = modifiedOn;
       this.modifiedBy = modifiedBy;
    }
   
    public Integer getId() {
        return this.id;
    }
    
    public void setId(Integer id) {
        this.id = id;
    }
    public String getQuestion() {
        return this.question;
    }
    
    public void setQuestion(String question) {
        this.question = question;
    }
    public Integer getSequence() {
        return this.sequence;
    }
    
    public void setSequence(Integer sequence) {
        this.sequence = sequence;
    }
    public Byte getDeleted() {
        return this.deleted;
    }
    
    public void setDeleted(Byte deleted) {
        this.deleted = deleted;
    }
    public Date getCreatedOn() {
        return this.createdOn;
    }
    
    public void setCreatedOn(Date createdOn) {
        this.createdOn = createdOn;
    }
    public Integer getCreatedBy() {
        return this.createdBy;
    }
    
    public void setCreatedBy(Integer createdBy) {
        this.createdBy = createdBy;
    }
    public Date getModifiedOn() {
        return this.modifiedOn;
    }
    
    public void setModifiedOn(Date modifiedOn) {
        this.modifiedOn = modifiedOn;
    }
    public Integer getModifiedBy() {
        return this.modifiedBy;
    }
    
    public void setModifiedBy(Integer modifiedBy) {
        this.modifiedBy = modifiedBy;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("id", id).
                append("question", question).
                append("sequence", sequence).
                append("createdOn", createdOn).
                append("createdBy", createdBy).
                append("modifiedOn", modifiedOn).
                append("modifiedBy", modifiedBy).
                append("deleted", deleted).
                toString();
    }


}


