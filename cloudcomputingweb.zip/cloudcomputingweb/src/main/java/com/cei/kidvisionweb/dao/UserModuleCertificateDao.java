package com.cei.kidvisionweb.dao;

import com.cei.kidvisionweb.db.model.UserModuleCertificate;

/**
 *
 * @author Shrikant
 */
public interface UserModuleCertificateDao extends GenericDao<UserModuleCertificate, Long> {

//    void add(UserModuleCertificate object);
//
//    void update(UserModuleCertificate object);
//
//    void delete(UserModuleCertificate object);

    void deleteById(String id);
}
