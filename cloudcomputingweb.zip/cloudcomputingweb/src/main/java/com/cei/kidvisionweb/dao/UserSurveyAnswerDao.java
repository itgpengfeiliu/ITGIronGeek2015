package com.cei.kidvisionweb.dao;

import java.util.List;

import com.cei.kidvisionweb.db.model.UserSurveyAnswer;
import com.cei.kidvisionweb.db.model.UserSurveyAnswerResult;

public interface UserSurveyAnswerDao extends GenericDao<UserSurveyAnswer, Long> {

	List<UserSurveyAnswerResult> getUserSurveyAnswers();
}
