

package com.cei.kidvisionweb.dao.impl;

import java.util.List;

import org.hibernate.transform.Transformers;

import com.cei.kidvisionweb.dao.UserModuleSurveyAnswerDao;
import com.cei.kidvisionweb.db.model.UserModuleSurveyAnswer;
import com.cei.kidvisionweb.db.model.UserModuleSurveyAnswerResult;


public class UserModuleSurveyAnswerDaoImpl extends GenericDaoImpl<UserModuleSurveyAnswer, Long> implements UserModuleSurveyAnswerDao{
    
	@Override
	@SuppressWarnings("unchecked")
	public List<UserModuleSurveyAnswerResult> getAllUserModuleSurveyAnswers() {
	  	List<UserModuleSurveyAnswerResult> resutls = null;
	  	try {
	  		String sql = "select question_id as question, answer as answer, count(id) as no "
	      			+ " from user_module_survey_answers where module_id is not null and module_id != 0 "
	  				+ " group by question_id, answer ";
	      	resutls = getSession().createSQLQuery(sql).setResultTransformer(Transformers.aliasToBean(UserModuleSurveyAnswerResult.class)).list();
		} catch (Exception ex) {
			logger.error("Error occurred::", ex);
		}
		return resutls;
	}
	
	@Override
	@SuppressWarnings("unchecked")
	public List<UserModuleSurveyAnswerResult> getUserModuleSurveyAnswers(int moduleId) {
	  	List<UserModuleSurveyAnswerResult> resutls = null;
	  	try {
	  		String sql = "select question_id as question, answer as answer, module_id as moduleId, count(id) as no "
	      			+ " from user_module_survey_answers where module_id = " + moduleId + " "
	  				+ " group by question_id, answer, module_id ";
	      	resutls = getSession().createSQLQuery(sql).setResultTransformer(Transformers.aliasToBean(UserModuleSurveyAnswerResult.class)).list();
		} catch (Exception ex) {
			logger.error("Error occurred::", ex);
		}
		return resutls;
	 }
}
