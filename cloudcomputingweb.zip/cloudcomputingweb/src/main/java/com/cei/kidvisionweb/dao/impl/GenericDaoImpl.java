package com.cei.kidvisionweb.dao.impl;

import com.cei.kidvisionweb.dao.GenericDao;

import java.io.Serializable;
import java.lang.reflect.ParameterizedType;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author Shrikant
 */
public abstract class GenericDaoImpl<T, ID extends Serializable>
        implements GenericDao<T, ID> {

    protected static Logger logger = LoggerFactory.getLogger(GenericDaoImpl.class);

    private final Class<T> persistentClass;
    private SessionFactory sessionFactory;

    @SuppressWarnings("unchecked")
    public GenericDaoImpl() {
        this.persistentClass = (Class<T>) ((ParameterizedType) getClass()
                .getGenericSuperclass()).getActualTypeArguments()[0];
    }

    public Class<T> getPersistentClass() {
        return persistentClass;
    }

	public SessionFactory getSessionFactory() {
        return sessionFactory;
    }

    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }

    protected Session getSession() {
        assert sessionFactory != null;
        return sessionFactory.getCurrentSession();
    }

    /* CRUD */

    /*
     * TRANSIENT: sets id if doesn't exist, persists to database, returns attached object
     * DETACHED: sets new id even if object already has it, persists to DB, returns attached object
     */
    @Override
    public void add(final T obj) {
        getSession().save(obj); // Persist the given transient instance
    }

    @Override
    public void delete(T obj) {
        getSession().delete(obj);
    }

    @Override
    public void deleteById(Integer id) {
        Session session = getSession();
        session.delete(session.get(getPersistentClass(), id));
    }

    /*
     * TRANSIENT: Exception
     * DETACHED: persists and re-attaches
     */
    @Override
    public void update(T obj) {
        getSession().update(obj);
    }
    
    /*
     * TRANSIENT: copy the state of object in DB, doesn't attach it, returns attached object
     * DETACHED: copy the state of object in DB, doesn't attach it, returns attached object
     */
    @Override
    public void merge(T obj) {
        getSession().merge(obj);
    }

    @Override
    @SuppressWarnings("unchecked")
    public T get(Serializable id) {
        return (T) getSession().get(getPersistentClass(), id);
    }

    /*
     * where condition1 and condition2 and condition3...
     */
    @Override
    @SuppressWarnings("unchecked")
    public T getByProperties(String... strs) {
    	String params = "";
    	for (String str : strs) {
    		params += str.toString() + " , ";
    	}
    	logger.debug("getByProperties params " + params);
        if (strs != null && strs.length != 0 && 0 == strs.length % 2) {
            StringBuffer hql = new StringBuffer("select model from "
                    + getPersistentClass().getName() + " as model where ");
            for (int i = 0; i < strs.length; i += 2) {
            	if (i > 0) {
                    hql.append(" and ");
                }
            	hql.append(" " + strs[i] + " = '" + strs[i + 1] + "' ");
            }
            logger.debug("getByProperties " + hql.toString());
            List<T> objs = getSession().createQuery(hql.toString()).list();
            if (objs != null && objs.size() != 0) {
                return objs.get(0);
            } else {
                return null;
            }

        } else {
            return null;
        }
    }

    @Override
    @SuppressWarnings("unchecked")
    public T getUniqueByProperty(String pName, Object pValue) {
        String hql = "select model from " + getPersistentClass().getName()
                + " as model where model." + pName + " = '" + pValue + "'";
        logger.debug("getUniqueByProperty " + hql.toString());
        List<T> objs = getSession().createQuery(hql).list();
        if (objs != null && objs.size() != 0) {
            return objs.get(0);
        } else {
            return null;
        }
    }

    @Override
    @SuppressWarnings("unchecked")
    public List<T> getList() {
        String hql = "select model from " + getPersistentClass().getName()
                + " as model ";
        List<T> list = getSession().createQuery(hql).list();
        return list;
    }

    @Override
    @SuppressWarnings("unchecked")
    public List<T> getListByProperty(String pName, Object pValue) {
        String hql = "select model from " + getPersistentClass().getName()
                + " as model where model." + pName + " = '" + pValue + "'";
        logger.debug("getListByProperty " + hql.toString());
        return getSession().createQuery(hql).list();

    }

    /*
     * where condition1 and condition2 and condition3...
     */
    @Override
    @SuppressWarnings("unchecked")
    public List<T> getListByProperties(String... strs) {
    	String params = "";
    	for (String str : strs) {
    		params += str.toString() + " , ";
    	}
    	logger.debug("getListByProperties params " + params);
        if (strs != null && strs.length != 0 && 0 == strs.length % 2) {
            StringBuffer hql = new StringBuffer("select model from "
                    + getPersistentClass().getName() + " as model where ");
            for (int i = 0; i < strs.length; i += 2) {
                if (i > 0) {
                    hql.append("and ");
                }
                hql.append(" " + strs[i] + " = '" + strs[i + 1] + "' ");
            }
            logger.debug("getListByProperties " + hql.toString());
            List<T> objs = getSession().createQuery(hql.toString()).list();
            return objs;
        } else {
            return null;
        }
    }

    @Override
    @SuppressWarnings("unchecked")
    public List<T> getListOrderByProperty(String pName) {
        String hql = "select model from " + getPersistentClass().getName()
                + " as model order by model." + pName;
        return getSession().createQuery(hql).list();
    }

    public void deleteByProperty(String propertyName, Object value) {
        String queryString = "delete from " + getPersistentClass().getName()
                + " as model where model." + propertyName + "= ?";
        Query query = getSession().createQuery(queryString);
        query.setParameter(0, value);
        query.executeUpdate();
    }

}
