package com.cei.kidvisionweb.db.model;

import java.util.Date;

import org.apache.commons.lang3.builder.ToStringBuilder;

public class UserModuleTestTranscriptDetail implements java.io.Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private Integer course_id;
	private String title;
	private Integer certificate_id;
	private Date date;
	private String s1;
	private String s2;
	private String s3;
	private String s4;
	
	public UserModuleTestTranscriptDetail() {
		
	}
	
	public UserModuleTestTranscriptDetail(Integer course_id, String title, Integer certificate_id, Date date,
			String s1, String s2, String s3, String s4) {
		this.course_id = course_id;
		this.title = title;
		this.certificate_id = certificate_id;
		this.date = date;
		this.s1 = s1;
		this.s2 = s2;
		this.s3 = s3;
		this.s4 = s4;
	}
	
	public Integer getCourse_id() {
		return course_id;
	}
	public void setCourse_id(Integer course_id) {
		this.course_id = course_id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public Integer getCertificate_id() {
		return certificate_id;
	}
	public void setCertificate_id(Integer certificate_id) {
		this.certificate_id = certificate_id;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public String getS1() {
		return s1;
	}

	public void setS1(String s1) {
		this.s1 = s1;
	}

	public String getS2() {
		return s2;
	}

	public void setS2(String s2) {
		this.s2 = s2;
	}

	public String getS3() {
		return s3;
	}

	public void setS3(String s3) {
		this.s3 = s3;
	}

	public String getS4() {
		return s4;
	}

	public void setS4(String s4) {
		this.s4 = s4;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	@Override
	 public String toString() {
	     return new ToStringBuilder(this).append("course_id", course_id)
	    		 .append("title", title)
	    		 .append("certificate_id", certificate_id)
	    		 .append("date", date)
	    		 .append("s1", s1)
	    		 .append("s2", s2)
	    		 .append("s3", s3)
	    		 .append("s4", s4).toString();
	 }

}
