package com.cei.kidvisionweb.db.model;

import org.apache.commons.lang3.builder.ToStringBuilder;

public class Standard  implements java.io.Serializable {


     /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	private Integer id;
     private Integer moduleId;
     private String title;
     private String description;
     private Integer standardNo;

    public Standard() {
    }

    public Standard(Integer moduleId, String title, String description, Integer standardNo) {
       this.moduleId = moduleId;
       this.title = title;
       this.description = description;
       this.standardNo = standardNo;
    }
   
    public Integer getId() {
        return this.id;
    }
    
    public void setId(Integer id) {
        this.id = id;
    }
    public Integer getModuleId() {
        return this.moduleId;
    }
    
    public void setModuleId(Integer moduleId) {
        this.moduleId = moduleId;
    }
    public String getTitle() {
        return this.title;
    }
    
    public void setTitle(String title) {
        this.title = title;
    }
    public String getDescription() {
        return this.description;
    }
    
    public void setDescription(String description) {
        this.description = description;
    }
    public Integer getStandardNo() {
        return this.standardNo;
    }
    
    public void setStandardNo(Integer standardNo) {
        this.standardNo = standardNo;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("id", id).
                append("moduleId", moduleId).
                append("title", title).
                append("description", description).
                append("standardNo", standardNo).
                toString();
    }
}


