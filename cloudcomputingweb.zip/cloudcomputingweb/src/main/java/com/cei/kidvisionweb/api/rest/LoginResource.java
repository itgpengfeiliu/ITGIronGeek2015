package com.cei.kidvisionweb.api.rest;

import javax.ws.rs.Consumes;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.authentication.BadCredentialsException;

import com.cei.kidvisionweb.config.KidvisionWebConfig;
import com.cei.kidvisionweb.db.model.User;
import com.cei.kidvisionweb.service.UserLoginService;
import com.cei.kidvisionweb.service.UserService;
import com.cei.kidvisionweb.service.util.EmailService;
import com.cei.kidvisionweb.service.util.LoggedUser;
import com.sun.jersey.api.core.InjectParam;

@Path("/user")
public class LoginResource {

	private static Logger logger = LoggerFactory.getLogger(LoginResource.class);
	
	@InjectParam
    private UserLoginService userLoginService;

	@InjectParam
    private UserService userService;
	
	@InjectParam
    private EmailService emailService;
	
    public LoginResource() {
    }
    
    @Path("/logout")
    @GET
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    @Produces(MediaType.TEXT_HTML)
    public Response logout() {
    	try {
    		userLoginService.logout();
    		logger.debug("logout ");
    		return Response.ok().entity("home").build();
	    } catch (BadCredentialsException ex) { 
	    	logger.error("Error occurred:: ", ex);
	    	return Response.status(Response.Status.UNAUTHORIZED).entity("Error occurred:").build();
	    } catch (Exception ex) {
	        logger.error("Error occurred: : ", ex);
	        return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("Error occurred:").build();
	    }
    }
    
    @Path("/login")
    @POST
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    @Produces(MediaType.APPLICATION_JSON)
    public Response login(@FormParam("username") String username,
    					  @FormParam("password") String password) {
    	try {
    		if (username != null && username != "" && password != null && password != "") {
	    		logger.debug("LoginResource login username = " + username + " , password = " + password);
	    		
	    		if ( userLoginService.isLoggedIn() ) {
					LoggedUser loggedUser = userLoginService.getLoggedUserUtil();
					logger.debug("logged user : " + loggedUser.toString());
					
					String result = userLoginService.getLoggedSimpleUser(loggedUser.getId());
	    			
	    			if (result != null) {
	    				return Response.ok(result, MediaType.APPLICATION_JSON).build();
	    			}
	    		}
	    		else {
		    		if ( userLoginService.login(username, password) ) {
		    			LoggedUser loggedUser = userLoginService.getLoggedUserUtil();
		    			
		    			String result = userLoginService.getLoggedSimpleUser(loggedUser.getId());
		    			
		    			if (result != null) {
		    				userService.addUserLoginTime(loggedUser.getId());
		    				
		    				return Response.ok(result, MediaType.APPLICATION_JSON).build();
		    			}
		    		}
	    		}
    		}
    		return Response.status(Response.Status.BAD_REQUEST).entity("Error occurred:").build();
	    } catch (BadCredentialsException ex) { 
	    	logger.error("Error occurred:: ", ex);
	    	return Response.status(Response.Status.UNAUTHORIZED).entity("Error occurred:").build();
	    } catch (Exception ex) {
	        logger.error("Error occurred: : ", ex);
	        return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("Error occurred:").build();
	    }
    }
    
    @Path("/forgotpassword")
    @POST
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    @Produces(MediaType.TEXT_HTML)
    public Response forgotPassword(@FormParam("username") String username,
    					  		   @FormParam("email") String email) {
    	try {
    		if (username != null && username != "" && email != null && email != "") {
	    		logger.debug("forgotPassword username = " + username + " , email = " + email);
	    		
	    		User user = userLoginService.setUserTempPassword(email, username);
	    		
	    		if ( user == null ) {
	    			return Response.ok("not found").build();
	    		}
	    		else {
	    			logger.debug("forgotPassword temP = " + user.getPassword());
	    			
	    			if (emailService.sendEmail(emailService.FORGOT_PASSWORD_EMAIL_SUBJECT, 
	    					KidvisionWebConfig.FORGOT_PASSWORD_EMAIL_TEXT(user.getFirstName(), user.getPassword()), email))
	    			{
	    				return Response.ok("true").build();
	    			}
	    			return Response.ok("email failed").build();
	    		}
    		}
    		return Response.status(Response.Status.NOT_FOUND).build();
	    } catch (Exception ex) {
	        logger.error("Error occurred: : ", ex);
	        return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("Error occurred:").build();
	    }
    }
    
    @Path("/forgotusername")
    @POST
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    @Produces(MediaType.TEXT_HTML)
    public Response forgotUsername(@FormParam("email") String email) {
    	try {
    		if (email != null && email != "") {
	    		logger.debug("forgotPassword email = " + email);
	    		
	    		User user = userLoginService.checkUserExist(email);
	    		//if ( userName != null && userName.endsWith(username) ) {
	    		//String tempP = userLoginService.setUserTempPassword(email, username);
	    		//logger.debug("forgotPassword temP = " + tempP);
	    		if ( user == null || user.getUserName() == null ) {
	    			return Response.ok("not found").build();
	    		}
	    		else {
	    			logger.debug("FORGOT_USERNAME_EMAIL_SUBJECT = " + emailService.FORGOT_USERNAME_EMAIL_SUBJECT);
	    			if (emailService.sendEmail(emailService.FORGOT_USERNAME_EMAIL_SUBJECT, 
	    					KidvisionWebConfig.FORGOT_USERNAME_EMAIL_TEXT(user.getFirstName(), user.getUserName()), email))
	    			{
	    				return Response.ok("true").build();
	    			}
	    			return Response.ok("email failed").build();
	    		}
    		}
    		return Response.status(Response.Status.NOT_FOUND).build();
	    } catch (Exception ex) {
	        logger.error("Error occurred: : ", ex);
	        return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("Error occurred:").build();
	    }
    }
    
    @Path("/getUserSecurityQuestions")
    @POST
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    @Produces(MediaType.APPLICATION_JSON)
    public Response getUserSecurityQuestions(@FormParam("username") String username) {
    	try {
    		if (username != null && username != "") {
	    		logger.debug("getUserSecurityQuestions username = " + username);
	    		
	    		String output = userService.getUserPasswordRecoveryQuestions(username);
	        	logger.debug("getPasswordRecoveryQuestions : " + output);
	        	return Response.ok(output, MediaType.APPLICATION_JSON).build();
    		}
    		return Response.status(Response.Status.NOT_FOUND).build();
	    } catch (Exception ex) {
	        logger.error("Error occurred: : ", ex);
	        return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("Error occurred:").build();
	    }
    }
    
    @Path("/validusersecurityquestions")
    @POST
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    @Produces(MediaType.TEXT_HTML)
    public Response validUserSecurityQuestions(@FormParam("username") String username,
    					  		  @FormParam("qid0") String qid0, @FormParam("qid1") String qid1,
    					  		  @FormParam("a0") String a0, @FormParam("a1") String a1) {
    	try {
    		if (username != null && username != "" 
    				&& qid0 != null && qid0 != "" && qid1 != null && qid1 != "" 
    				&& a0 != null && a0 != "" && a1 != null && a1 != "") {
	    		logger.debug("validUserSecurityQuestions username = " + username 
	    				+ " , qid0 = " + qid0 + " , qid1 = " + qid1
	    				+ " , a0 = " + a0 + " , a1 = " + a1);
	    		
	    		String isValid = userService.validUserPasswordRecoveryQuestionsAndAnswers(username, qid0, qid1, a0, a1);
	    		if (isValid != null) {
	    			if ( userLoginService.login(username, isValid) ) {
		    			LoggedUser loggedUser = userLoginService.getLoggedUserUtil();
		    			logger.debug("logged user : " + loggedUser.toString());
		    			
		    			return Response.ok().entity(username).build();
		    		}
	    			return Response.status(Response.Status.BAD_REQUEST).entity("Error occurred:").build();
	    		}
	    		else {
	    			return Response.status(Response.Status.UNAUTHORIZED).entity("wrong answers").build();
	    		}
    		}
    		return Response.status(Response.Status.NOT_FOUND).build();
	    } catch (Exception ex) {
	        logger.error("Error occurred: : ", ex);
	        return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("Error occurred:").build();
	    }
    }
    

    @Path("/adminlogin")
    @POST
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    @Produces(MediaType.TEXT_HTML)
    public Response adminLogin(@FormParam("username") String username,
    					  @FormParam("password") String password) {
    	try {
    		if (username != null && username != "" && password != null && password != "") {
	    		logger.debug("LoginResource login username = " + username + " , password = " + password);
	    		
	    		if ( userLoginService.login(username, password) ) {
	    			LoggedUser loggedUser = userLoginService.getLoggedUserUtil();
	    			if (loggedUser.getRoleId() == (byte)1) {
	    				return Response.ok().entity("home").build();
	    			}
	    			return Response.ok().entity("nonadmin").build();
	    		}
    		}
    		return Response.status(Response.Status.BAD_REQUEST).entity("Error occurred:").build();
	    } catch (BadCredentialsException ex) { 
	    	logger.error("Error occurred:: ", ex);
	    	return Response.status(Response.Status.UNAUTHORIZED).entity("Error occurred:").build();
	    } catch (Exception ex) {
	        logger.error("Error occurred: : ", ex);
	        return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("Error occurred:").build();
	    }
    }
    
}
