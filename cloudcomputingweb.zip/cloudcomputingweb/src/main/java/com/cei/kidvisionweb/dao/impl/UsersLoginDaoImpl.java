package com.cei.kidvisionweb.dao.impl;

import com.cei.kidvisionweb.dao.UsersLoginDao;
import com.cei.kidvisionweb.db.model.UsersLogin;

public class UsersLoginDaoImpl extends GenericDaoImpl<UsersLogin, Long> implements UsersLoginDao {

}
