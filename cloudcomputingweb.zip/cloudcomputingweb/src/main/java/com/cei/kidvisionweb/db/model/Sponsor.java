package com.cei.kidvisionweb.db.model;


import java.util.Date;

import org.apache.commons.lang3.builder.ToStringBuilder;

public class Sponsor  implements java.io.Serializable {

     /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private Integer id;
    private String name;
    private String description;
    private String imageFilePath;
    private String sponsorUrl;
    private Date createdOn;
    private Integer createdBy;
    private Date modifiedOn;
    private Integer modifiedBy;
    private Byte deleted;

    public Sponsor() {
    }

    public Sponsor(String name, String description, String imageFilePath, String sponsorUrl, Date createdOn, Integer createdBy, Date modifiedOn, Integer modifiedBy, Byte deleted) {
       this.name = name;
       this.description = description;
       this.imageFilePath = imageFilePath;
       this.sponsorUrl = sponsorUrl;
       this.createdOn = createdOn;
       this.createdBy = createdBy;
       this.modifiedOn = modifiedOn;
       this.modifiedBy = modifiedBy;
       this.deleted = deleted;
    }
   
    public Integer getId() {
        return this.id;
    }
    
    public void setId(Integer id) {
        this.id = id;
    }
    public String getName() {
        return this.name;
    }
    
    public void setName(String name) {
        this.name = name;
    }
    public String getDescription() {
        return this.description;
    }
    
    public void setDescription(String description) {
        this.description = description;
    }
    public String getImageFilePath() {
        return this.imageFilePath;
    }
    
    public void setImageFilePath(String imageFilePath) {
        this.imageFilePath = imageFilePath;
    }
    public String getSponsorUrl() {
        return this.sponsorUrl;
    }
    
    public void setSponsorUrl(String sponsorUrl) {
        this.sponsorUrl = sponsorUrl;
    }
    public Date getCreatedOn() {
        return this.createdOn;
    }
    
    public void setCreatedOn(Date createdOn) {
        this.createdOn = createdOn;
    }
    public Integer getCreatedBy() {
        return this.createdBy;
    }
    
    public void setCreatedBy(Integer createdBy) {
        this.createdBy = createdBy;
    }
    public Date getModifiedOn() {
        return this.modifiedOn;
    }
    
    public void setModifiedOn(Date modifiedOn) {
        this.modifiedOn = modifiedOn;
    }
    public Integer getModifiedBy() {
        return this.modifiedBy;
    }
    
    public void setModifiedBy(Integer modifiedBy) {
        this.modifiedBy = modifiedBy;
    }
    public Byte getDeleted() {
        return this.deleted;
    }
    
    public void setDeleted(Byte deleted) {
        this.deleted = deleted;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("id", id).
                append("name", name).
                append("description", description).
                append("imageFilePath", imageFilePath).
                append("sponsorUrl", sponsorUrl).
                append("createdOn", createdOn).
                append("createdBy", createdBy).
                append("modifiedOn", modifiedOn).
                append("modifiedBy", modifiedBy).
                append("deleted", deleted).
                toString();
    }

}


