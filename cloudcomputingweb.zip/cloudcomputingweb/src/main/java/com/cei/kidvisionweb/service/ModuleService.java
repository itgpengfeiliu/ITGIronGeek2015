package com.cei.kidvisionweb.service;

import com.cei.kidvisionweb.db.model.Config;

/**
 *
 * @author Shrikant
 */
public interface ModuleService {
	
	String triggerRegistrationType(int userId, boolean isContinue);
	
	String getUser(int userId);
	
	Integer getUserPrimaryAddressId(int userId);
	
	Integer getUserBillingAddressId(int userId);
	
	Integer getUserShippingAddressId(int userId);
	
	String updateUserPretestCompleted(int userId);
	
	String updateUserPassword(int userId, String password);
	
	String updateUserModuleActivityCompleted(int activityId);
	
	String completeFieldTripModuleActivity(int activityId);
	
	String updateUser(int userId, String prefix, String firstName, String middleName, String lastName,
    		String email, String userName, String educationLevel, int occupationalTitleId, 
    		String otherOccupationalTitle, String phone, boolean emailNotification, byte registrationtypeId, 
    		String schoolName);
	
	String getUserAddress(int addressId);
	
	Integer updateUserAddress(int userId, int addressId);
	
	String addOrUpdateAddress(Integer userId, Integer addressId, String streetAddress, String city, String county, 
    		String state, String country, String zipCode);
	
	String addOrUpdateBillingAddress(Integer userId, Integer addressId, String streetAddress, String city, String county, 
    		String state, String country, String zipCode);
	
	String addOrUpdateShippingAddress(Integer userId, Integer addressId, String streetAddress, String city, String county, 
    		String state, String country, String zipCode);
	
	String addOrUpdateSecurityQuestionsAndAnsers(int userId, int recorvery1, int recorvery2, String answer1, String answer2);
	
    String getAllModules();
    
    String getAllModulesOrderBySequenceAndVideos();
    
    String getModuleAndVideos(int moduleId);
    
    String getModuleResources(int ModuleId);
    
    String getStandardsByModule(int moduleId);
    
    String getPretestRandomQuestionsAndAnswers(int count);
    
    String getQuestionsAndAnswersByModule(int moduleId);
    
    String getUserModuleTest(int userId, int moduleId);
    
    String getUserModuleTestAnswers(int userId, int userModuleTestId);
    
    String addUserModuleActivityFiles(int userId, int moduleId, String activityName);
    
    //String addIfNotExistUserModuleActivity(int userId, int moduleId, String activityType);
    String addUserModuleActivity(int userId, int moduleId, String activityType);
    
    //String updateUserModuleActivity(int userId, int moduleId, String activityType);
    
    String getUserModuleActivities(int userId, int moduleId);
    
    String getUserSurveyActivities(int userId, int moduleId);
    
    String addUserSurveyActivity(int userId, int moduleId);
    
    String getUserModuleTests(int userId, int moduleId);
    
    String getUserModuleTestE(int userModuleTestId);
    
    //String addIfNotExistUserModuleTest(int userId, int moduleId);
    String addUserModuleTest(int userId, int moduleId);
    
    Integer addUserModuleTestE(int userId, int moduleId, int fieldtripActivityId, byte correct, byte isPassed);
    
    String updateUserModuleTest(int userModuleTestId, int totalQuestionCount, int score);
    
    String completeUserModuleTestE(int userModuleTestId);
    
    String addOrUpdateUserModuleTestAnswer(int userId, int userModuleTestId, int questionId, int answerId);
    
    String addUserModulePretestAnswer(int userId, int userModuleTestId, int questionId, int answerId, int userModuleActivityId);
    
    String addUserPretestAnswers(int userId, String qaids);
    
    int scoreUserModuleTest(String qaids);
    
    String addUserSurveyAnswers(int userId, int surveyQuestionId, byte answer, int moduleId);
    
    String getSurveyQuestions();
    
    String getUserCertificateTitles(int userId);
    
    String getUserModuleTestTranscriptTitles(int userId);
    
    String getUserModuleTestTranscriptDetails(int userId, String fullName, String title, int testyear, String imagesPath);
    
    String getUserModuleTestCertificateDetails(int userId, String fullName, String title, String testyear, String imagesPath);
    
    Config getConfig();
    
    String getConfigJson();
    
    String getModuleSurveyQuestions();
    
    //Integer addRegistration(Registration registration);
    
    int getProcessPayment();
    
    String getFullSimpleUser(Integer userId);
    
    String addUserModuleSurveyAnswer(int userId, int moduleId, int questionId, int answer, String comment, int userModuleActivityId);
    
    //String getUserCurrentRegistration(int userId);
    
    String payRegistration(int userId, String billingFullName, String billingStreetAddress, 
    		String billingCity, String billingState, String billingZipCode, String email, String cardNumber, 
    		String exp, String cardSecurityCode, String billingCountry, String shippingStreetAddress, 
    		String shippingCity, String shippingState, String shippingZipCode, String shippingCountry, String phone);
}
