package com.cei.kidvisionweb.service.util;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.springframework.security.core.GrantedAuthority;

public class GrantedAuthorityUtil implements GrantedAuthority {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	private String authority;
	
	public GrantedAuthorityUtil(byte roleId) {
		authority = Authorities[roleId];
	}
	
	private static final String Authorities[] = {"null", "Administrator", "User"}; // role id 1, 2
	
	@Override
	public String getAuthority() {
		return authority;
	}
	
	public void setAuthority(String authority) {
		this.authority = authority;
	}
	
    @Override
    public String toString() {
        return new ToStringBuilder(this).append("authority", authority).toString();
    }
	
}
