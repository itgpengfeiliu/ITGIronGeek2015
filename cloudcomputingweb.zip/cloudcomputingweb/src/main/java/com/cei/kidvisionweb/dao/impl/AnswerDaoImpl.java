

package com.cei.kidvisionweb.dao.impl;

import java.util.List;

import com.cei.kidvisionweb.dao.AnswerDao;
import com.cei.kidvisionweb.db.model.Answer;

/**
 *
 * @author Shrikant
 */
public class AnswerDaoImpl extends GenericDaoImpl<Answer, Long> implements AnswerDao{
 
	@Override
    @SuppressWarnings("unchecked")
    public List<Answer> getCorrectAnswers(String... strs) {
    	String params = "";
    	for (String str : strs) {
    		params += str.toString() + " , ";
    	}
    	logger.debug("getCorrectAnswers params " + params);
        if (strs != null && strs.length != 0 && 0 == strs.length % 2) {
            StringBuffer hql = new StringBuffer("select model from "
                    + getPersistentClass().getName() + " as model where correct='1' and ( ");
            for (int i = 0; i < strs.length; i += 2) {
                if (i > 0) {
                    hql.append("or ");
                }
                hql.append(" " + strs[i] + " = '" + strs[i + 1] + "' ");
            }
            hql.append(" )");
            logger.debug("getListByPropertyDifferentValues " + hql.toString());
            List<Answer> objs = getSession().createQuery(hql.toString()).list();
            return objs;
        } else {
            return null;
        }
    }
	
}
