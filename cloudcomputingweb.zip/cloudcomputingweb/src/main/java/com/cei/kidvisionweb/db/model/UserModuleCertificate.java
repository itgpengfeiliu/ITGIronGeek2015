package com.cei.kidvisionweb.db.model;


import java.util.Date;
import org.apache.commons.lang3.builder.ToStringBuilder;

public class UserModuleCertificate  implements java.io.Serializable {


     /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	private Integer id;
     private int userId;
     private int moduleId;
     private String fileName;
     private Date createdOn;

    public UserModuleCertificate() {
    }

	
    public UserModuleCertificate(int userId, int moduleId) {
        this.userId = userId;
        this.moduleId = moduleId;
    }
    public UserModuleCertificate(int userId, int moduleId, String fileName, Date createdOn) {
       this.userId = userId;
       this.moduleId = moduleId;
       this.fileName = fileName;
       this.createdOn = createdOn;
    }
   
    public Integer getId() {
        return this.id;
    }
    
    public void setId(Integer id) {
        this.id = id;
    }
    public int getUserId() {
        return this.userId;
    }
    
    public void setUserId(int userId) {
        this.userId = userId;
    }
    public int getModuleId() {
        return this.moduleId;
    }
    
    public void setModuleId(int moduleId) {
        this.moduleId = moduleId;
    }
    public String getFileName() {
        return this.fileName;
    }
    
    public void setFileName(String fileName) {
        this.fileName = fileName;
    }
    public Date getCreatedOn() {
        return this.createdOn;
    }
    
    public void setCreatedOn(Date createdOn) {
        this.createdOn = createdOn;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("id", id).
                append("userId", userId).
                append("moduleId", moduleId).
                append("fileName", fileName).
                append("createdOn", createdOn).
                toString();
    }


}


