

package com.cei.kidvisionweb.service.util;

import com.cei.kidvisionweb.config.KidvisionWebConfig;
import com.sun.jersey.core.header.FormDataContentDisposition;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author Shrikant
 */
public class FileProcessor {
    
    private static Logger logger = LoggerFactory.getLogger(FileProcessor.class);
    
    public boolean writeToWebapp(String path, InputStream uploadedInputStream, FormDataContentDisposition fileDetail) {

        try {
            String videoFilename = fileDetail.getFileName();
            logger.debug("FileProcessor writeToWebapp " + path + videoFilename);
            
            OutputStream out = new FileOutputStream(new File(path + videoFilename));

            int read = 0;
            byte[] bytes = new byte[1024];

            while ((read = uploadedInputStream.read(bytes)) != -1) {
                out.write(bytes, 0, read);
            }
            out.flush();
            out.close();

            return true;
        } catch (IOException e) {
            logger.error("IOException: " + e.getMessage());
        }

        return false;
    }
    
    public boolean writeToFile(InputStream uploadedInputStream, FormDataContentDisposition fileDetail) {

        try {
            String videoFilename = fileDetail.getFileName();
            logger.debug("FileProcessor writeToFile " + videoFilename);

            OutputStream out = new FileOutputStream(new File(KidvisionWebConfig.UPLOADED_VIDEOS_DIRECTORY + videoFilename));

            int read = 0;
            byte[] bytes = new byte[1024];

            while ((read = uploadedInputStream.read(bytes)) != -1) {
                out.write(bytes, 0, read);
            }
            out.flush();
            out.close();

            return true;
        } catch (IOException e) {
            logger.error("IOException: " + e.getMessage());
        }

        return false;
    }
}
