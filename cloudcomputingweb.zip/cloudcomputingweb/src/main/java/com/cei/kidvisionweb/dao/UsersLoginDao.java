package com.cei.kidvisionweb.dao;

import com.cei.kidvisionweb.db.model.UsersLogin;

public interface UsersLoginDao extends GenericDao<UsersLogin, Long> {

}
