package com.cei.kidvisionweb.dao.impl;

import com.cei.kidvisionweb.dao.ConfigDao;
import com.cei.kidvisionweb.db.model.Config;

public class ConfigDaoImpl extends GenericDaoImpl<Config, Long> implements ConfigDao {

}
