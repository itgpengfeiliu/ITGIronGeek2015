

package com.cei.kidvisionweb.dao.impl;

import java.util.List;

import org.hibernate.criterion.Projections;
import org.hibernate.transform.Transformers;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cei.kidvisionweb.dao.UserDao;
import com.cei.kidvisionweb.db.model.User;
import com.cei.kidvisionweb.db.model.UserDatatable;
import com.cei.kidvisionweb.db.model.UsersByCountyState;

/**
 *
 * @author Shrikant
 */
public class UserDaoImpl extends GenericDaoImpl<User, Long> implements UserDao {
		
	private static Logger logger = LoggerFactory.getLogger(UserDaoImpl.class);
	
	/*
	 * return: true is no user has same email or username
	 * 		   string is duplicate email or username
	 */
    @Override
    @SuppressWarnings("unchecked")
    public String validNewUserEmailandUsername(final String email, final String username) {
    	if (email == null || email.equalsIgnoreCase("") || username == null | username.equalsIgnoreCase("")) {
    		return "false";
    	}
    	logger.debug("validNewUserEmailandUsername params email = " + email + " , username = " + username);
    	String hql = "select model from " + getPersistentClass().getName()
                + " as model where model.email = '" + email + "' or model.userName = '" + username + "'";
    	List<User> objs = getSession().createQuery(hql).list();
    	//logger.debug(",----" + objs.size() + ",");
        if (objs != null && objs.size() != 0) {
        	for (User temp : objs) {
        		if (temp.getEmail().equalsIgnoreCase(email)) {
        			logger.debug("duplicate email : " + temp.toString());
        			return "email duplicate";
        		}
        		else if (temp.getUserName().equalsIgnoreCase(username)) {
        			logger.debug("duplicate username : " + temp.toString());
        			return "username duplicate";
        		}
        	}
        }
        return "true";
    }

    @Override
    @SuppressWarnings("unchecked")
    public List<UserDatatable> getAllUsersPagination(int length, int start, int orderIndex, String order, String search, String configCurrentSchoolYearFrom) {
        List<UserDatatable> modules = null;
        try {
        	
        	/*
        	String sql = "select u.id, u.first_name as firstName, u.last_name as lastName, u.user_name as userName, u.password, "
            		+ " u.email, u.role_id as roleId, u.is_active as isActive "
        			+ ", (SELECT max(ul.login_on) FROM users_login ul WHERE ul.user_id = u.id) AS lastLogon "
            		+ " from users u ";
            		*/
        	String sql = "select u.id, u.first_name as firstName, u.last_name as lastName, u.user_name as userName, u.password, "
            		+ " u.email, u.role_id as roleId, u.is_active as isActive "
        			+ " , max(ul.login_on) as 'lastLogon' , u.school_name as schoolName, r.card_last_four as cardNumber, r.is_paid as isPaid "
            		+ " from users u "
        			+ " left outer join users_login ul on u.id=ul.user_id "
            		+ " left outer join registration r on u.id=r.user_id and r.from_datetime='" + configCurrentSchoolYearFrom + "'";
        	
        	//  LIMIT 1 ORDER BY ul.login_on desc 
        	if (search != "") {
        		sql += " where u.first_name LIKE '%" + search + "%' or ";
        		sql += " u.first_name LIKE '%" + search + "%' or ";
        		sql += " u.last_name LIKE '%" + search + "%' or ";
        		sql += " u.user_name LIKE '%" + search + "%' or ";
        		sql += " u.email LIKE '%" + search + "%' or ";
        		sql += " u.school_name LIKE '%" + search + "%' ";
        	}
        	sql += " GROUP BY u.id " ;        	
        	if (orderIndex == 0) {
        		sql += " order by TRIM(u.first_name) ";
        	}
        	else if (orderIndex == 1) {
        		sql += " order by TRIM(u.last_name) ";
        	}
        	else if (orderIndex == 2) {
        		sql += " order by TRIM(u.user_name) ";
        	}
        	else if (orderIndex == 4) {
        		sql += " order by TRIM(u.email) ";
        	}
        	else if (orderIndex == 5) {
        		sql += " order by TRIM(u.role_id) ";
        	}
        	else if (orderIndex == 7) {
        		sql += " order by TRIM(u.is_active) ";
        	}
        	else if (orderIndex == 8) {
        		sql += " order by max(ul.login_on) ";
        	}
        	else if (orderIndex == 9) {
        		sql += " order by max(u.school_name) ";
        	}
        	else {
        		sql += " order by TRIM(u.first_name) ";
        	}
        	
        	if (order.equalsIgnoreCase("desc")) {
    			sql += order + " ";
    		}
        	
        	sql += " LIMIT " + length + " OFFSET " + start + " ;";
                
        	logger.debug("SQL: " + sql);
            //StringBuffer sqlSB = new StringBuffer(sql);
            modules = getSession().createSQLQuery(sql).setResultTransformer(Transformers.aliasToBean(UserDatatable.class)).list();
        } catch (Exception ex) {
            logger.error("Error occurred:", ex);
        }
        return modules;
    }
    // SELECT * FROM TableName ORDER BY id OFFSET 10 ROWS FETCH NEXT 10 ROWS ONLY;
    
    /*
     * select u.id, u.first_name as firstName, u.last_name as lastName, u.user_name as userName, u.password, 
     * u.email, u.role_id as roleId, u.is_active as isActive , 
     * ul.lastLogon 
     * from users u 
     * left outer join (select uls.user_id, max(uls.login_on) as 'lastLogon' from users_login uls group by uls.user_id) ul on u.id=ul.user_id 
     * LIMIT 50 OFFSET 0
     */
    
    @Override
    @SuppressWarnings("unchecked")
    public List<UsersByCountyState> countUsersByCountyStatePagination(int length, int start, int orderIndex, String order, String search) {
        List<UsersByCountyState> modules = null;
        try {
        	String sql = "select count(u.id) as count, a.county, a.state "
            		+ " from users u inner join address a on u.primary_address_Id = a.id "
        			+ " where u.is_active = 1 and u.primary_address_Id IS NOT NULL and a.county IS NOT NULL and a.state IS NOT NULL ";
        	// and a.country != 'OUTSIDE of UNITED STATES' 
        	if (search != "") {
        		sql += " and ( a.county LIKE '%" + search + "%' or ";
        		sql += " a.state LIKE '%" + search + "%' ) ";
        	}
        	
        	sql += " group by TRIM(a.county), TRIM(a.state) ";
        	        	
        	if (orderIndex == 0) {
        		sql += " order by count ";
        	}
        	else if (orderIndex == 1) {
        		sql += " order by a.county ";
        	}
        	else if (orderIndex == 2) {
        		sql += " order by a.state ";
        	}
        	else {
        		sql += " order by a.county ";
        	}
        	
        	if (order.equalsIgnoreCase("desc")) {
    			sql += order + " ";
    		}
        	
        	sql += " LIMIT " + length + " OFFSET " + start + " ;";
        	
            modules = getSession().createSQLQuery(sql).setResultTransformer(Transformers.aliasToBean(UsersByCountyState.class)).list();
        } catch (Exception ex) {
            logger.error("Error occurred:", ex);
        }
        return modules;
    }
    
    @Override
    public long getAllUsersCount() {
        long count = 0;
        try {
        	count = (long) getSession().createCriteria(User.class, "u").setProjection(Projections.rowCount()).uniqueResult();
					
        } catch (Exception ex) {
            logger.error("Error occurred:", ex);
        }
        return count;
    }
    
    @SuppressWarnings("unchecked")
	@Override
    public List<UserDatatable> getNewRegistrationUsers(String starttime, String endtime) {
    	List<UserDatatable> modules = null;
        try {
        	String sql = "select u.id, u.first_name as firstName, u.last_name as lastName, u.user_name as userName, u.password, "
            		+ " u.email, u.role_id as roleId, u.is_active as isActive "
            		+ " from users u "
        	        + " WHERE u.created_on >= " + starttime + " and u.created_on <= " + endtime
        	        + " order by u.created_on asc ";
        	
        	logger.debug("SQL: " + sql);
            modules = getSession().createSQLQuery(sql).setResultTransformer(Transformers.aliasToBean(UserDatatable.class)).list();
        } catch (Exception ex) {
            logger.error("Error occurred:", ex);
        }
        return modules;
    }
}
