package com.cei.kidvisionweb.service.util;

import java.util.Collection;
import java.util.HashSet;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import com.cei.kidvisionweb.db.model.User;

public class LoggedUser implements UserDetails {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	private Integer id;
    private String firstName;
    private String lastName;
    private String username;
    private String email;
    private String password;
    private byte roleId;
    private final boolean enabled;
    private Byte registrationtypeId;
    //private Integer occupationalTitleId;
    //private Integer primaryAddressId;
    //private byte pretestCompleted;
	private HashSet<GrantedAuthority> grantedAuthorities = new HashSet<GrantedAuthority>();
    
    public HashSet<GrantedAuthority> getGrantedAuthorities() {
		return grantedAuthorities;
	}

	public void setGrantedAuthorities(HashSet<GrantedAuthority> grantedAuthorities) {
		this.grantedAuthorities = grantedAuthorities;
	}
	
	public Byte getRegistrationtypeId() {
		return registrationtypeId;
	}

	public void setRegistrationtypeId(Byte registrationtypeId) {
		this.registrationtypeId = registrationtypeId;
	}
//
//	public Integer getOccupationalTitleId() {
//		return occupationalTitleId;
//	}
//
//	public void setOccupationalTitleId(Integer occupationalTitleId) {
//		this.occupationalTitleId = occupationalTitleId;
//	}

	public void setUsername(String username) {
		this.username = username;
	}

	public LoggedUser(User user) {
    	this.id = user.getId();
    	this.firstName = user.getFirstName();
    	this.lastName = user.getLastName();
        this.username = user.getUserName();
        this.email = user.getEmail();
        this.password = user.getPassword();
        this.roleId = user.getRoleId();
        this.enabled = (user.getIsActive() == 1) ? true : false;
        this.registrationtypeId = user.getRegistrationtypeId();
        //this.occupationalTitleId = user.getOccupationalTitleId();
        //this.primaryAddressId = user.getPrimaryAddressId();
        //this.pretestCompleted = user.getPretestCompleted();
        ////this.grantedAuthorities.addAll(user.getAuthorities());
        this.grantedAuthorities = new HashSet<GrantedAuthority>();
        grantedAuthorities.add(new GrantedAuthorityUtil(user.getRoleId()));
    }
    
    
//	public Integer getPrimaryAddressId() {
//		return primaryAddressId;
//	}
//
//	public void setPrimaryAddressId(Integer primaryAddressId) {
//		this.primaryAddressId = primaryAddressId;
//	}

	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
	@Override
	public String getPassword() {
		return password;
	}
	
	public void setPassword(String password) {
		this.password = password;
	}
	public byte getRoleId() {
		return roleId;
	}
	public void setRoleId(byte roleId) {
		this.roleId = roleId;
	}

//	public byte getPretestCompleted() {
//		return pretestCompleted;
//	}
//
//	public void setPretestCompleted(byte pretestCompleted) {
//		this.pretestCompleted = pretestCompleted;
//	}

	@Override
	public Collection<? extends GrantedAuthority> getAuthorities() {
		return grantedAuthorities;
	}


	@Override
	public String getUsername() {
		return username;
	}


	@Override
	public boolean isAccountNonExpired() {
		return true;
	}


	@Override
	public boolean isAccountNonLocked() {
		return true;
	}


	@Override
	public boolean isCredentialsNonExpired() {
		return true;
	}


	@Override
	public boolean isEnabled() {
		return enabled;
	}
	
    @Override
    public String toString() {
    	StringBuilder authorities = new StringBuilder();
    	for(GrantedAuthority ga : grantedAuthorities) {
    		authorities.append(ga.toString());
    	}
    	
        return new ToStringBuilder(this).append("id", id).
                append("firstName", firstName).
                append("lastName", lastName).
                append("username", username).
                append("email", email).
                append("roleId", roleId).
                append("enabled", enabled).
                append("registrationtypeId", registrationtypeId).
                //append("occupationalTitleId", occupationalTitleId).
                //append("primaryAddressId", primaryAddressId).
                //append("pretestCompleted", pretestCompleted).
                append("grantedAuthorities", authorities).
                toString();
    }
}
