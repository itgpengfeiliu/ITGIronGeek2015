package com.cei.kidvisionweb.db.model;

import java.util.Date;

import org.apache.commons.lang3.builder.ToStringBuilder;

public class UserModuleActivity implements java.io.Serializable {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	private Integer id;
	private Integer userId;
    private Integer moduleId;
    private String activityType;
    private String activityName;
    private byte isCompleted;
    private Date startDatetime;
    private Date endDatetime;
    
    // posttest videos in order to be compatible with old db data
    public static enum ACTIVITY_TYPES { files, videos, posttest, survey, fieldtrip };  // pretest
    public static enum ACTIVITY_NAMES_FILES { LessonPlans, StudentAssessments, TakeHomePages };

    public static String getActivityNameFiles(String activityName) {
    	if (ACTIVITY_NAMES_FILES.LessonPlans.name().indexOf(activityName) != -1) {
    		return ACTIVITY_NAMES_FILES.LessonPlans.name(); 
    	}
    	else if (ACTIVITY_NAMES_FILES.StudentAssessments.name().indexOf(activityName) != -1) {
    		return ACTIVITY_NAMES_FILES.StudentAssessments.name();
    	}
    	else if (ACTIVITY_NAMES_FILES.TakeHomePages.name().indexOf(activityName) != -1) {
    		return ACTIVITY_NAMES_FILES.TakeHomePages.name();
    	}
    	else {
    		return activityName;
    	}
    }
    
    public UserModuleActivity() {
    }

	
    public UserModuleActivity(int userId, int moduleId, 
    		String activityType, String activityName,
    		byte isCompleted, Date startDatetime, Date endDatetime) {
        this.userId = userId;
        this.moduleId = moduleId;
        this.activityType = activityType;
        this.activityName = activityName;
        this.isCompleted = isCompleted;
        this.startDatetime = startDatetime;
        this.endDatetime = endDatetime;
    }
    
    public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	public Integer getModuleId() {
		return moduleId;
	}

	public void setModuleId(Integer moduleId) {
		this.moduleId = moduleId;
	}

	public String getActivityType() {
		return activityType;
	}

	public void setActivityType(String activityType) {
		this.activityType = activityType;
	}

	public String getActivityName() {
		return activityName;
	}

	public void setActivityName(String activityName) {
		this.activityName = activityName;
	}

	public byte getIsCompleted() {
		return isCompleted;
	}

	public void setIsCompleted(byte isCompleted) {
		this.isCompleted = isCompleted;
	}

	public Date getStartDatetime() {
		return startDatetime;
	}

	public void setStartDatetime(Date startDatetime) {
		this.startDatetime = startDatetime;
	}

	public Date getEndDatetime() {
		return endDatetime;
	}

	public void setEndDatetime(Date endDatetime) {
		this.endDatetime = endDatetime;
	}

	@Override
    public String toString() {
        return new ToStringBuilder(this).append("id", id).
        		append("userId", userId).
                append("moduleId", moduleId).
                append("activityType", activityType).
                append("activityName", activityName).
                append("isCompleted", isCompleted).
                append("createdOn", startDatetime).
                append("updatedOn", endDatetime).
                toString();
    }
}
