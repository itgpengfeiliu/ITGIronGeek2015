package com.cei.kidvisionweb.dao.impl;

import com.cei.kidvisionweb.dao.OccupationalTitleDao;
import com.cei.kidvisionweb.db.model.OccupationalTitle;

public class OccupationalTitleDaoImpl extends GenericDaoImpl<OccupationalTitle, Long> implements OccupationalTitleDao {

}
