package com.cei.kidvisionweb.dao;

import java.math.BigInteger;

import com.cei.kidvisionweb.db.model.Address;

/**
 *
 * @author Shrikant
 */
public interface AddressDao extends GenericDao<Address, Long> {

	BigInteger countAllCountyState();
}
