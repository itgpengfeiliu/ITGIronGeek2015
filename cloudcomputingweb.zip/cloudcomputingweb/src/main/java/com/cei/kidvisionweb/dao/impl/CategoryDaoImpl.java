package com.cei.kidvisionweb.dao.impl;

import com.cei.kidvisionweb.dao.CategoryDao;
import com.cei.kidvisionweb.db.model.Categorie;

public class CategoryDaoImpl extends GenericDaoImpl<Categorie, Long> implements CategoryDao {

}
