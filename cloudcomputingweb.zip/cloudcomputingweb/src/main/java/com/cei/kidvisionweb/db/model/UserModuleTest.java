package com.cei.kidvisionweb.db.model;


import java.util.Date;
import org.apache.commons.lang3.builder.ToStringBuilder;

public class UserModuleTest  implements java.io.Serializable {

    private Integer id;
    private Integer userId;
    private Integer moduleId;
    private Byte isCompleted;
    private Byte isPassed;
    private Byte correctAnswersCount;
    private Byte totalQuestionCount;
    private Date startedOn;
    private Date completedOn;
    private Integer userModuleActivityId;

    private static final long serialVersionUID = 1L;

    public static long getSerialversionuid() {
        return serialVersionUID;
    }

    public UserModuleTest() {
    }

    public UserModuleTest(Integer userId, Integer moduleId, Byte isCompleted, Byte isPassed, Byte correctAnswersCount, Byte totalQuestionCount, Date startedOn, Date completedOn) {
        this.userId = userId;
        this.moduleId = moduleId;
        this.isCompleted = isCompleted;
        this.isPassed = isPassed;
        this.correctAnswersCount = correctAnswersCount;
        this.totalQuestionCount = totalQuestionCount;
        this.startedOn = startedOn;
        this.completedOn = completedOn;
    }

    public Integer getId() {
        return this.id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getUserId() {
        return this.userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public Integer getModuleId() {
        return this.moduleId;
    }

    public void setModuleId(Integer moduleId) {
        this.moduleId = moduleId;
    }

    public Byte getIsCompleted() {
        return this.isCompleted;
    }

    public void setIsCompleted(Byte isCompleted) {
        this.isCompleted = isCompleted;
    }

    public Byte getIsPassed() {
        return this.isPassed;
    }

    public void setIsPassed(Byte isPassed) {
        this.isPassed = isPassed;
    }

    public Byte getCorrectAnswersCount() {
        return this.correctAnswersCount;
    }

    public void setCorrectAnswersCount(Byte correctAnswersCount) {
        this.correctAnswersCount = correctAnswersCount;
    }

    public Byte getTotalQuestionCount() {
        return this.totalQuestionCount;
    }

    public void setTotalQuestionCount(Byte totalQuestionCount) {
        this.totalQuestionCount = totalQuestionCount;
    }

    public Date getStartedOn() {
        return this.startedOn;
    }

    public void setStartedOn(Date startedOn) {
        this.startedOn = startedOn;
    }

    public Date getCompletedOn() {
        return this.completedOn;
    }

    public void setCompletedOn(Date completedOn) {
        this.completedOn = completedOn;
    }

    public Integer getUserModuleActivityId() {
		return userModuleActivityId;
	}

	public void setUserModuleActivityId(Integer userModuleActivityId) {
		this.userModuleActivityId = userModuleActivityId;
	}

	@Override
    public String toString() {
        return new ToStringBuilder(this).append("id", id).
                append("userId", userId).
                append("moduleId", moduleId).
                append("isCompleted", isCompleted).
                append("isPassed", isPassed).
                append("correctAnswersCount", correctAnswersCount).
                append("totalQuestionCount", totalQuestionCount).
                append("startedOn", startedOn).
                append("completedOn", completedOn).
                append("userModuleActivityId", userModuleActivityId).
                toString();
    }


}


