package com.cei.kidvisionweb.db.model;

import java.math.BigInteger;

import org.apache.commons.lang3.builder.ToStringBuilder;

public class UsersByCountyState implements java.io.Serializable {

	private BigInteger count;
    private String county;
    private String state;
    private static final long serialVersionUID = 1L;

    public static long getSerialversionuid() {
        return serialVersionUID;
    }

    public UsersByCountyState() {
    }

	public BigInteger getCount() {
		return count;
	}

	public void setCount(BigInteger count) {
		this.count = count;
	}

	public String getCounty() {
		return county;
	}

	public void setCounty(String county) {
		this.county = county;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	@Override
    public String toString() {
        return new ToStringBuilder(this).append("count", count).
                append("county", county).
                append("state", state).
                toString();
    }
}


