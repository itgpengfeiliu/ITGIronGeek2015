package com.cei.kidvisionweb.dao;

import com.cei.kidvisionweb.db.model.Sponsor;

public interface SponsorDao extends GenericDao<Sponsor, Long> {

}
