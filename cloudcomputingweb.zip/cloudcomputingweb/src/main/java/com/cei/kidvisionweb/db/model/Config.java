package com.cei.kidvisionweb.db.model;


import java.math.BigDecimal;
import java.util.Date;

import org.apache.commons.lang3.builder.ToStringBuilder;


public class Config  implements java.io.Serializable {

     /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private int id;
    private BigDecimal tmRegistrationAmount;
    private Integer discountAmount;
    private Date currentSchoolYearFrom;
    private Date currentSchoolYearTo;

    public Config() {
    }

	
    public Config(int id) {
        this.id = id;
    }
    public Config(int id, BigDecimal tmRegistrationAmount, Integer discountAmount, Date currentSchoolYearFrom, Date currentSchoolYearTo) {
       this.id = id;
       this.tmRegistrationAmount = tmRegistrationAmount;
       this.discountAmount = discountAmount;
       this.currentSchoolYearFrom = currentSchoolYearFrom;
       this.currentSchoolYearTo = currentSchoolYearTo;
    }
   
    public int getId() {
        return this.id;
    }
    
    public void setId(int id) {
        this.id = id;
    }
    public BigDecimal getTmRegistrationAmount() {
        return this.tmRegistrationAmount;
    }
    
    public void setTmRegistrationAmount(BigDecimal tmRegistrationAmount) {
        this.tmRegistrationAmount = tmRegistrationAmount;
    }
    public Integer getDiscountAmount() {
        return this.discountAmount;
    }
    
    public void setDiscountAmount(Integer discountAmount) {
        this.discountAmount = discountAmount;
    }
    public Date getCurrentSchoolYearFrom() {
        return this.currentSchoolYearFrom;
    }
    
    public void setCurrentSchoolYearFrom(Date currentSchoolYearFrom) {
        this.currentSchoolYearFrom = currentSchoolYearFrom;
    }
    public Date getCurrentSchoolYearTo() {
        return this.currentSchoolYearTo;
    }
    
    public void setCurrentSchoolYearTo(Date currentSchoolYearTo) {
        this.currentSchoolYearTo = currentSchoolYearTo;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("id", id).
                append("tmRegistrationAmount", tmRegistrationAmount).
                append("discountAmount", discountAmount).
                append("currentSchoolYearFrom", currentSchoolYearFrom).
                append("currentSchoolYearTo", currentSchoolYearTo).
                toString();
    }

}


