package com.cei.kidvisionweb.service;

import com.cei.kidvisionweb.db.model.Config;
import com.cei.kidvisionweb.db.model.User;
//import com.cei.kidvisionweb.db.model.User;
import com.cei.kidvisionweb.service.util.LoggedUser;

public interface UserLoginService {

	/**
     * Heavyweight method to get logged authentication.
     * Remember that this method may be touching the database, ergo it's heavy.
     * Use getLoggedUserDetails for fast and light access to logged authentication data.
     */
    //User getLoggedUserModel();
	String getLoggedSimpleUser(Integer userId);
	
	Config getConfig();
 
    /**
     * Lightweight method to get currently logged authentication details
     */
    LoggedUser getLoggedUserUtil();
 
    /**
     * This method should be used only to login right after registration
     */
    boolean login(Integer userId);
 
    boolean login(String username, String password);
    void logout();
    boolean isLoggedIn();
    
    User checkUserExist(String email);
    
    User setUserTempPassword(String email, String userName);
}
