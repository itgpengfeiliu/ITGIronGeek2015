package com.cei.kidvisionweb.dao;

import java.util.Date;
import java.util.List;

import com.cei.kidvisionweb.db.model.Registration;

public interface RegistrationDao extends GenericDao<Registration, Long> {
	
	Registration getRegistrationByConfig(int userId, Date fromDate);
	
	Registration getUserRegistration(int userId);
	
	List<Registration> getUserPaidRegistrations(int userId);
}
