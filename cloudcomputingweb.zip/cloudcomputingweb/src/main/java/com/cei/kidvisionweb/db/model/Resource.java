package com.cei.kidvisionweb.db.model;



import java.util.Date;

import org.apache.commons.lang3.builder.ToStringBuilder;

public class Resource  implements java.io.Serializable {

     /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private Integer id;
    private Integer typeId;
    private String title;
    private String shortDescription;
    private String resourceUrl;
    private String imageFilePath;
    private Integer createdBy;
    private Date createdOn;
    private Integer modifiedBy;
    private Date modifiedOn;
    private Byte deleted;

    public Resource() {
    }

    public Resource(Integer typeId, String title, String shortDescription, String resourceUrl, String imageFilePath, Integer createdBy, Date createdOn, Integer modifiedBy, Date modifiedOn, Byte deleted) {
       this.typeId = typeId;
       this.title = title;
       this.shortDescription = shortDescription;
       this.resourceUrl = resourceUrl;
       this.imageFilePath = imageFilePath;
       this.createdBy = createdBy;
       this.createdOn = createdOn;
       this.modifiedBy = modifiedBy;
       this.modifiedOn = modifiedOn;
       this.deleted = deleted;
    }
   
    public Integer getId() {
        return this.id;
    }
    
    public void setId(Integer id) {
        this.id = id;
    }
    public Integer getTypeId() {
        return this.typeId;
    }
    
    public void setTypeId(Integer typeId) {
        this.typeId = typeId;
    }
    public String getTitle() {
        return this.title;
    }
    
    public void setTitle(String title) {
        this.title = title;
    }
    public String getShortDescription() {
        return this.shortDescription;
    }
    
    public void setShortDescription(String shortDescription) {
        this.shortDescription = shortDescription;
    }
    public String getResourceUrl() {
        return this.resourceUrl;
    }
    
    public void setResourceUrl(String resourceUrl) {
        this.resourceUrl = resourceUrl;
    }
    public String getImageFilePath() {
        return this.imageFilePath;
    }
    
    public void setImageFilePath(String imageFilePath) {
        this.imageFilePath = imageFilePath;
    }
    public Integer getCreatedBy() {
        return this.createdBy;
    }
    
    public void setCreatedBy(Integer createdBy) {
        this.createdBy = createdBy;
    }
    public Date getCreatedOn() {
        return this.createdOn;
    }
    
    public void setCreatedOn(Date createdOn) {
        this.createdOn = createdOn;
    }
    public Integer getModifiedBy() {
        return this.modifiedBy;
    }
    
    public void setModifiedBy(Integer modifiedBy) {
        this.modifiedBy = modifiedBy;
    }
    public Date getModifiedOn() {
        return this.modifiedOn;
    }
    
    public void setModifiedOn(Date modifiedOn) {
        this.modifiedOn = modifiedOn;
    }
    public Byte getDeleted() {
        return this.deleted;
    }
    
    public void setDeleted(Byte deleted) {
        this.deleted = deleted;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("id", id).
        		append("typeId", typeId).
                append("title", title).
                append("shortDescription", shortDescription).
                append("resourceUrl", resourceUrl).
                append("imageFilePath", imageFilePath).
                append("createdBy", createdBy).
                append("modifiedBy", modifiedBy).
                append("createdOn", createdOn).
                append("modifiedOn", modifiedOn).
                append("deleted", deleted).
                toString();
    }

}


