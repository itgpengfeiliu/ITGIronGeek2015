
var lRegistrationtypeId = 2; // teacher membership = 2
var lProcessPayment = 0; // 0 free, 1 charge
//var loginIsPaid = 0;

var siteDomain="/kidvisionweb"; // /kidvisionweb
function getURL(val)
{
    var url = siteDomain + val;
    return url;
}
$( document ).ready(function() {
	
	$( "#payment_dialog" ).dialog({
		autoOpen: false,
		width: 480,
		height: 220,
	    modal: true,
	    open: function(event, ui) { 
            //hide close button.
            $(this).parent().children().children('.ui-dialog-titlebar-close').hide();
        },
	    buttons: {
			"Pay now": function() { 
				window.location = siteDomain + "/payment.jsp";
			},
			"Don't want to continue": function() {
				$.ajax({
		    	    type: "POST",
		    	    url: siteDomain + "/rest/vpk/triggerRegitrationType",
		    	    data: {iscontinue:false},
		    	    dataType: "text",
				    success: function (data) {
				    	window.location = siteDomain + "/my_profile.jsp";
				    },
			   	    error: function(xhr, status, exception) {
				    }
		    	});
			}
		}
	});
	
    $( "#registrationtype_dialog" ).dialog({
    	autoOpen: false,
    	width: 450,
    	height: 160,
        modal: true,
        open: function(event, ui) { 
            //hide close button.
            $(this).parent().children().children('.ui-dialog-titlebar-close').hide();
        },
        buttons: {
			"Yes": function() {
				if (lProcessPayment == 0) {
					$.ajax({
			    	    type: "POST",
			    	    url: siteDomain + "/rest/vpk/triggerRegitrationType",
			    	    data: {iscontinue:true},
			    	    dataType: "text",
					    success: function (data) {
					    	window.location = siteDomain + "/index.jsp";
					    },
				   	    error: function(xhr, status, exception) {
					    }
				    });
					
					//$(this).dialog("close"); 
					
					//$( "#dialog" ).dialog("open");
		    		
		    		//setTimeout(function() {
			    	//	$( "#dialog" ).dialog("close");
			    	//}, 120000);
				}
				else {
					$(this).dialog("close"); 
					
					$( "#payment_message" ).html("If you want to continue CEUs/In-Service Hours subscription, please pay now.");
  				    $( "#payment_dialog" ).dialog('option', 'title', "CEU Payment");
  				    $( "#payment_dialog" ).dialog("open");
					//window.location = siteDomain + "/payment.jsp?status=login";
				}
			}, 
			"No": function() {
				$.ajax({
		    	    type: "POST",
		    	    url: siteDomain + "/rest/vpk/triggerRegitrationType",
		    	    data: {iscontinue:false},
		    	    dataType: "text",
				    success: function (data) {
				    	window.location = siteDomain + "/index.jsp";
				    },
			   	    error: function(xhr, status, exception) {
				    }
			    });
				
//				$(this).dialog("close"); 
//				
//				$( "#dialog" ).dialog("open");
//	    		
//	    		setTimeout(function() {
//		    		$( "#dialog" ).dialog("close");
//		    	}, 120000);
			}
		}
    });
	
	
	 
	$( "#alert_dialog" ).dialog({
    	autoOpen: false,
    	width: 480,
    	height: 120,
        modal: true
   	});
	
	//$.ajaxSetup({ cache: false });
	
	if (  window.location.href.indexOf("forgot_password.jsp") != -1 ) {
	} 
	else if ( window.location.href.indexOf("registration.jsp") != -1) {
	}
	else if ( window.location.href.indexOf("forgot_username.jsp") != -1) {
	}
	//else if ( window.location.href.indexOf("contact_us.jsp") != -1) {
	//}
	//else if ( window.location.href.indexOf("privacy_policy.jsp") != -1) {
	//}
	//else if ( window.location.href.indexOf("faqs.jsp") != -1) {
	//}
	//else if ( window.location.href.indexOf("underwriters.jsp") != -1) {
	//}
	else if ( window.location.href.indexOf("vft.jsp") != -1) {
	}
	else if ( window.location.href.indexOf("tdev.jsp") != -1) {
	}
	else if ( window.location.href.indexOf("ctools.jsp") != -1) {
	}
	else if ( window.location.href.indexOf("ctools.jsp") != -1) {
	}
	else {
	  $.ajax({
	    type: "GET",
	    cache: false,
  		url: siteDomain + "/rest/vpk/getLoginUser",
  		dataType: 'json',
  		cache: false,
  		success: function (data) {
  			registrationtypeId = data.registrationtypeId;
  			lProcessPayment = data.processPayment;
  			
  			$("#user_fullname").html(data.firstName + " " + data.lastName);
  			
  			// table class 
  			// login/logout registration/profile 
  			// right_panel.js table menu
  			$(".beforelogin").hide();  
  			$(".afterlogin").show();
  			
  			// top.jsp menu
  			$("#beforeloginmenu").hide();
  			$("#afterloginmenu").show();
                        
            $("#divBeforeLogin").hide();
  			$("#divAfterLogin").show();
  			
  			// bottom.jsp container.jsp
  			$("a[name=a_virtual_field_trips]").attr("href", "virtual_field_trips.jsp");
  			$("a[name=a_teacher_development]").attr("href", "teacher_development.jsp");
  			$("a[name=a_classroom_tools]").attr("href", "classroom_tools.jsp");
  			$("a[name=a_field_trips_resources]").attr("href", "field_trips_resources.jsp");

  			$("#bottom_registration_profile").html("profile");
  			$("#bottom_registration_profile").attr("href", "my_profile.jsp");
  		},
	    error: function(xhr, status, exception) {
	    	if (xhr.status == 401) {
	    		if ( window.location.href.indexOf("virtual_field_trips.jsp") != -1 ) {
	    			window.location = siteDomain + "/vft.jsp";
	    		}
	    		else if ( window.location.href.indexOf("teacher_development.jsp") != -1 ) {
	    			window.location = siteDomain + "/tdev.jsp";
	    		}
	    		else if ( window.location.href.indexOf("classroom_tools.jsp") != -1 ) {
	    			window.location = siteDomain + "/ctools.jsp";
	    		}
	    		else if ( window.location.href.indexOf("field_trips_resources.jsp") != -1 ) {
	    			window.location = siteDomain + "/resources.jsp";
	    		}
	    		else if ( window.location.href.indexOf("field_trip.jsp") != -1 ) {
	    			window.location = siteDomain + "/vft.jsp";
	    		}
	    		else if ( window.location.href.indexOf("my_profile.jsp") != -1 ) {
	    			window.location = siteDomain + "/index.jsp";
	    		}
	    		else if ( window.location.href.indexOf("edit_profile.jsp") != -1 ) {
	    			window.location = siteDomain + "/index.jsp";
	    		}
	    		else if ( window.location.href.indexOf("change_password.jsp") != -1 ) {
	    			window.location = siteDomain + "/index.jsp";
	    		}
	    		else if ( window.location.href.indexOf("change_security_qa.jsp") != -1 ) {
	    			window.location = siteDomain + "/index.jsp";
	    		}
	    		else if ( window.location.href.indexOf("users_list.jsp") != -1 ) {
	    			window.location = siteDomain + "/index.jsp";
	    		}
	    		else if ( window.location.href.indexOf("modules_list.jsp") != -1 ) {
	    			window.location = siteDomain + "/index.jsp";
	    		}
	    		else if ( window.location.href.indexOf("survey_results.jsp") != -1 ) {
	    			window.location = siteDomain + "/index.jsp";
	    		}
	    		else if ( window.location.href.indexOf("add_module.jsp") != -1 ) {
	    			window.location = siteDomain + "/index.jsp";
	    		}
	    		else if ( window.location.href.indexOf("manage_module.jsp") != -1 ) {
	    			window.location = siteDomain + "/index.jsp";
	    		}
	    		else if ( window.location.href.indexOf("edit_user.jsp") != -1 ) {
	    			window.location = siteDomain + "/index.jsp";
	    		}
	    		else if ( window.location.href.indexOf("payment.jsp") != -1 ) {
	    			window.location = siteDomain + "/index.jsp";
	    		}
	    	}
	    }
  	  });
	}
	
	$( "#logout" ).click( "click", function() {
		$.ajax({
    	    type: "GET",
    	    cache: false,
    	    url: siteDomain + "/rest/user/logout",
		    dataType: "text",
		    success: function (data) {
	  			window.location = siteDomain + "/index.jsp";
		    },
	   	    error: function(xhr, status, exception) {
		    }
	    });
	});
	
	$( "#password" ).bind('keypress', function(e) {
		if(e.keyCode==13){
			$( "#login" ).click();
		}
	});
	
	
	$( "#login" ).click( "click", function() {
		if ( $("#username").val().trim() == "" || $("#password").val().trim() == "" ) {
			$( "#dialog_message" ).html("Please input username and password.");
			$( "#alert_dialog" ).dialog("open");
		}
		else {
	    	$.ajax({
	    	    type: "POST",
	    	    url: siteDomain + "/rest/user/login",
			    data: {username:$("#username").val(),
			        password:$("#password").val()},
			    dataType: "json",
			    success: function (data) {
			    	
			    	//loginIsPaid = data.isPaid;
			    	
			    	$( "#dialog" ).dialog({
			        	autoOpen: false,
			        	width: 650,
			        	height: 450,
			            modal: true,
			            close: function() {
			            	lProcessPayment = data.processPayment;
			            	if (data.passwordReset == "1") {
			    	    		window.location = siteDomain + "/change_password.jsp";
			    	    	}
			    	    	else if (data.roleId == 1) {
			    	    		window.location = siteDomain + "/admin/modules_list.jsp";
			    	    	}
			    	    	else if ((data.registrationtypeId == 2 && data.currentRegistrationId == null) || (data.registrationtypeId == 2 && data.fromDatetime == null)) {
					    		$( "#registrationtype_dialog" ).dialog("open");
					    	}
			    	    	else if (data.registrationtypeId == 2 && data.fromDatetime != null && data.currentRegistrationId != null 
				    				&& data.processPayment == 1 && data.isPaid == 0 ) {
				    			//window.open("/kidvisionweb/payment.jsp", "_blank");
				    			//window.location = siteDomain + "/payment.jsp?status=login";
			    	    		$( "#payment_message" ).html("If you want to continue CEUs/In-Service Hours subscription, please pay now.");
			  				    $( "#payment_dialog" ).dialog('option', 'title', "CEU Payment");
			  				    $( "#payment_dialog" ).dialog("open");
				    		}
			    	    	else if (data.pretestCompleted == 0) {
			    	    		window.location = siteDomain + "/pretest.jsp";
			    	    	}
			    	    	else if (data.primaryAddressId == null) {
			    	    		window.location = siteDomain + "/edit_profile.jsp";
			    	    	}
			    	    	else {
			    	    		window.location = siteDomain + "/index.jsp";
			    	    	}
			            }
			        });
			    	
			    	/*if ((data.registrationtypeId == 2 && data.currentRegistrationId == null) || (data.registrationtypeId == 2 && data.fromDatetime == null)) {
			    		$( "#registrationtype_dialog" ).dialog("open");
			    	}
			    	else {*/
			    		
			    		$( "#dialog" ).dialog("open");
			    		
			    		setTimeout(function() {
				    		$( "#dialog" ).dialog("close");
				    	}, 120000);
			    	//}
			    },
		   	    error: function(xhr, status, exception) { 
		   	    	$( "#dialog_message" ).html("Invalid username or password!");
                    $( "#alert_dialog" ).dialog('option', 'title', "Login Error");
					$( "#alert_dialog" ).dialog("open");
					
		    	  	if (xhr.status == 401) {
		    	  		//alert(xhr.responseText + " , UNAUTHORIZED ,  " + xhr.status);
		    	  	}
		    	  	else if (xhr.status == 400) {
		    	  		//alert(xhr.responseText + " , BAD_REQUEST ,  " + xhr.status);
		    	  	}
		    	  	else {
		    	  		//alert(xhr.responseText + " , " + xhr.status);
			    	}
			    }
		    });
    	}
    });
});
