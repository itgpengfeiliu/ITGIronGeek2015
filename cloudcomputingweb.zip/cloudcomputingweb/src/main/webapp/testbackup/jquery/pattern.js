/*
	    ^                    # Start of the line
		  [a-z0-9_-]	     # Match characters and symbols in the list, a-z, 0-9, underscore, hyphen
		             {3,15}  # Length at least 3 characters and maximum length of 15 
		$                    # End of the line
	*/
	var USERNAME_PATTERN = "^[a-z0-9_-]{3,15}$";
	var USERNAME_TEST = new RegExp(USERNAME_PATTERN);
	
	/*
	 	(			        # Start of group
		  (?=.*\d)		    #   must contains one digit from 0-9
		  (?=.*[a-z])		#   must contains one lowercase characters
		  (?=.*[A-Z])		#   must contains one uppercase characters
		  (?=.*[@#$%])		#   must contains one special symbols in the list "@#$%"
		              .		#     match anything with previous condition checking
		                {6,20}	#        length at least 6 characters and maximum of 20	
		)			# End of group
	 */
	//private static final String PASSWORD_PATTERN =  "((?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%]).{6,20})";
	var PASSWORD_PATTERN =  "((?=.*\\d)(?=.*[a-z]).{5,20})";
	var PASSWORD_TEST = new RegExp(PASSWORD_PATTERN);
	
	/*
		^			                  #start of the line
		  [_A-Za-z0-9-\\+]+	          #  must start with string in the bracket [ ], must contains one or more (+)
		  (			                  #   start of group #1
		    \\.[_A-Za-z0-9-]+	      #     follow by a dot "." and string in the bracket [ ], must contains one or more (+)
		  )*			              #   end of group #1, this group is optional (*)
		    @			              #     must contains a "@" symbol
		     [A-Za-z0-9-]+            #       follow by string in the bracket [ ], must contains one or more (+)
		      (			              #         start of group #2 - first level TLD checking
		       \\.[A-Za-z0-9]+        #           follow by a dot "." and string in the bracket [ ], must contains one or more (+)
		      )*		              #         end of group #2, this group is optional (*)
		      (			              #         start of group #3 - second level TLD checking
		       \\.[A-Za-z]{2,}        #           follow by a dot "." and string in the bracket [ ], with minimum length of 2
		      )			              #         end of group #3
		$			                  #end of the line	
	*/
	
	var EMAIL_PATTERN = 
			"^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"
					+ "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";
	var EMAIL_TEST = new RegExp(EMAIL_PATTERN);
	
	
	//MatchDate (e.g. 21/3/2006)
	//var dateRegex = /(\d{1,2}\/\d{1,2}\/\d{4})/gm; 
	//match date in format MM/DD/YYYY
	//var dateMMDDYYYRegex = '^(0[1-9]|1[012])[- /.](0[1-9]|[12][0-9]|3[01])[- /.](19|20)\d\d$'; 
	//match date in format DD/MM/YYYY
	//var dateDDMMYYYRegex = '^(0[1-9]|[12][0-9]|3[01])[- /.](0[1-9]|1[012])[- /.](19|20)\d\d$';