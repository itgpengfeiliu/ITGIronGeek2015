
DROP TABLE IF EXISTS `temp_usertestansers`;
CREATE TABLE IF NOT EXISTS `temp_usertestansers` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `userTestId` int(11) unsigned DEFAULT NULL,
  `correctAnswersCount` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `temp_usertestquestions`;
CREATE TABLE IF NOT EXISTS `temp_usertestquestions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userTestId` int(11) DEFAULT NULL,
  `questionsCount` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

Insert into temp_usertestansers
SELECT
null,
umta.user_module_test_id,
	Count(a.correct)
FROM
	user_module_test_answers umta
	INNER JOIN answers a
	 ON umta.question_id = a.question_id
	 AND a.id = umta.answer_id
WHERE
	a.correct=1 
	and umta.created_on > '2014-05-30 15:47:58' and umta.created_on < '2014-06-02 10:25:38'
group by umta.user_id, umta.user_module_test_id;
	
	
insert into temp_usertestquestions
SELECT
null,
user_module_test.id,
	count(questions.id)
FROM
	questions
	INNER JOIN user_module_test
	 ON questions.module_id = user_module_test.module_id
where started_on > '2014-05-30 15:47:58' and started_on < '2014-06-02 10:25:38'
group by user_module_test.id;

CREATE INDEX idx_temp_usertestansers_userTestId ON temp_usertestansers (userTestId);
CREATE INDEX idx_temp_usertestquestions_userTestId ON temp_usertestquestions (userTestId);


UPDATE user_module_test AS umt
inner join temp_usertestquestions AS utq ON umt.id=utq.userTestId
inner join temp_usertestansers AS uta ON uta.userTestId=uta.userTestId 
set umt.is_completed=1, 
umt.is_passed=if(ifnull(utq.questionsCount,0)-ifnull(uta.correctAnswersCount,0)=0,1,0), 
umt.correct_answers_count=uta.correctAnswersCount, 
umt.total_question_count=utq.questionsCount
where umt.id=uta.userTestId and uta.userTestId=utq.userTestId and umt.started_on > '2014-05-30 15:47:58' and umt.started_on < '2014-06-02 10:25:38';

drop TABLE temp_usertestansers;
drop TABLE temp_usertestquestions;