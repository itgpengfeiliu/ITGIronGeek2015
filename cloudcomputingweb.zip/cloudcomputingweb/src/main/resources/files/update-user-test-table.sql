
DROP TABLE IF EXISTS `temp_usertestansers`;
CREATE TABLE IF NOT EXISTS `temp_usertestansers` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `userTestId` int(11) unsigned DEFAULT NULL,
  `correctAnswersCount` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `temp_usertestquestions`;
CREATE TABLE IF NOT EXISTS `temp_usertestquestions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userTestId` int(11) DEFAULT NULL,
  `questionsCount` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

Insert into temp_usertestansers
SELECT
null,
user_module_test.id,
	Count(answers.correct)
FROM
	user_module_test_answers
	INNER JOIN user_module_test
	 ON user_module_test_answers.user_module_test_id = user_module_test.id
	INNER JOIN answers
	 ON user_module_test_answers.question_id = answers.question_id
	 AND answers.id = user_module_test_answers.answer_id
WHERE
	answers.correct=1 
group by user_module_test.id;
	
	
insert into temp_usertestquestions
SELECT
null,
user_module_test.id,
	count(questions.id)
FROM
	questions
	INNER JOIN user_module_test
	 ON questions.module_id = user_module_test.module_id
group by user_module_test.id;

CREATE INDEX idx_temp_usertestansers_userTestId ON temp_usertestansers (userTestId);
CREATE INDEX idx_temp_usertestquestions_userTestId ON temp_usertestquestions (userTestId);


UPDATE user_module_test AS umt
inner join temp_usertestquestions AS utq ON umt.id=utq.userTestId
inner join temp_usertestansers AS uta ON uta.userTestId=uta.userTestId 
set umt.is_completed=1, 
umt.is_passed=if(ifnull(utq.questionsCount,0)-ifnull(uta.correctAnswersCount,0)=0,1,0), 
umt.correct_answers_count=uta.correctAnswersCount, 
umt.total_question_count=utq.questionsCount
where umt.id < 50001 and umt.id=uta.userTestId and uta.userTestId=utq.userTestId;

UPDATE user_module_test AS umt
inner join temp_usertestquestions AS utq ON umt.id=utq.userTestId
inner join temp_usertestansers AS uta ON uta.userTestId=uta.userTestId 
set umt.is_completed=1, 
umt.is_passed=if(ifnull(utq.questionsCount,0)-ifnull(uta.correctAnswersCount,0)=0,1,0), 
umt.correct_answers_count=uta.correctAnswersCount, 
umt.total_question_count=utq.questionsCount
where umt.id > 50000 and umt.id < 100000 and umt.id=uta.userTestId and uta.userTestId=utq.userTestId;

UPDATE user_module_test AS umt
inner join temp_usertestquestions AS utq ON umt.id=utq.userTestId
inner join temp_usertestansers AS uta ON uta.userTestId=uta.userTestId 
set umt.is_completed=1, 
umt.is_passed=if(ifnull(utq.questionsCount,0)-ifnull(uta.correctAnswersCount,0)=0,1,0), 
umt.correct_answers_count=uta.correctAnswersCount, 
umt.total_question_count=utq.questionsCount
where umt.id > 99999 and umt.id < 150000 and umt.id=uta.userTestId and uta.userTestId=utq.userTestId;

UPDATE user_module_test AS umt
inner join temp_usertestquestions AS utq ON umt.id=utq.userTestId
inner join temp_usertestansers AS uta ON uta.userTestId=uta.userTestId 
set umt.is_completed=1, 
umt.is_passed=if(ifnull(utq.questionsCount,0)-ifnull(uta.correctAnswersCount,0)=0,1,0), 
umt.correct_answers_count=uta.correctAnswersCount, 
umt.total_question_count=utq.questionsCount
where umt.id > 149000 and umt.id < 200000 and umt.id=uta.userTestId and uta.userTestId=utq.userTestId;

UPDATE user_module_test AS umt
inner join temp_usertestquestions AS utq ON umt.id=utq.userTestId
inner join temp_usertestansers AS uta ON uta.userTestId=uta.userTestId 
set umt.is_completed=1, 
umt.is_passed=if(ifnull(utq.questionsCount,0)-ifnull(uta.correctAnswersCount,0)=0,1,0), 
umt.correct_answers_count=uta.correctAnswersCount, 
umt.total_question_count=utq.questionsCount
where umt.id > 199999 and umt.id < 250000 and umt.id=uta.userTestId and uta.userTestId=utq.userTestId;

UPDATE user_module_test AS umt
inner join temp_usertestquestions AS utq ON umt.id=utq.userTestId
inner join temp_usertestansers AS uta ON uta.userTestId=uta.userTestId 
set umt.is_completed=1, 
umt.is_passed=if(ifnull(utq.questionsCount,0)-ifnull(uta.correctAnswersCount,0)=0,1,0), 
umt.correct_answers_count=uta.correctAnswersCount, 
umt.total_question_count=utq.questionsCount
where umt.id > 249999 and umt.id=uta.userTestId and uta.userTestId=utq.userTestId;

drop TABLE temp_usertestansers;
drop TABLE temp_usertestquestions;