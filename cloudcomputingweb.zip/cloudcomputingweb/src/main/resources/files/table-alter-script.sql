/* table alter scripts */
alter table users 
add column password_reset smallint default 0;

alter table videos
add column video_streaming_title varchar(100) default null;

-- June 02 2014
update users
set first_name = trim(first_name), last_name = trim(last_name), user_name = trim(user_name), email = trim(email);

-- June 03 2014
-- Dumping structure for table kidvisiondb.users
DROP TABLE IF EXISTS `users_login`;
CREATE TABLE IF NOT EXISTS `users_login` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `login_on` datetime DEFAULT NULL,
   PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*insert users_login data */
INSERT INTO kidvisiondb.users_login (id, user_id, login_on)
SELECT 
null,
id, 
last_login
FROM vpk.users;

-- June 04 2014
-- ALTER TABLE users MODIFY user_name varchar(100) BINARY NOT NULL;
-- ALTER TABLE users MODIFY email varchar(255) BINARY NOT NULL;


-- June 09 2014
update modules set icon_file = "Kite Icon Jpeg.jpg" where id=142;
update module_resources set deleted = 1 where id=23;

-- June 12 2014
alter table user_survey_answers
add column module_id int(11) unsigned default null;

insert into survey_questions (question, sequence, deleted)
values ("For training purposes", 6, 0);
insert into survey_questions (question, sequence, deleted)
values ("For teaching purposes", 7, 0);

-- June 19 2014
alter table users
add column prefix varchar(5) default null;

-- June 26 2014
alter table users add column school_name varchar(255) default null;

-- July 28 2014
alter table registration add column is_paid smallint default 0;

-- July 30 2014
alter table registration add column card_full_name varchar(255) default null;
alter table registration add column card_last_four varchar(10) default null;
alter table registration add column card_exp varchar(10) default null;
alter table registration add column sage_payment_order_number varchar(20) default null;
alter table registration add column sage_payment_reference varchar(20) default null;

-- Aug 05 2014
alter table user_module_test add column user_module_activity_id int(11) unsigned default null;

DROP TABLE IF EXISTS `user_module_pretest`;

DROP TABLE IF EXISTS `user_module_survey`;


DROP TABLE IF EXISTS `user_module_pretest_answers`;
CREATE TABLE IF NOT EXISTS `user_module_pretest_answers` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `module_id` int(11) DEFAULT NULL,
  `question_id` int(11) DEFAULT NULL,
  `answer_id` int(11) DEFAULT NULL,
  `created_on` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- Aug 06 2014
DROP TABLE IF EXISTS `module_survey_questions`;
CREATE TABLE IF NOT EXISTS `module_survey_questions` (
  `id` int(11) NOT NULL,
  `question` varchar(255) DEFAULT NULL,
  `sub_question` varchar(255) DEFAULT NULL,
  `sequence` int(11) DEFAULT NULL,
  `qtype` tinyint(11) DEFAULT NULL,
  `deleted` tinyint(4) DEFAULT NULL,
  `created_on` datetime DEFAULT NULL,
  `created_by` int(11) unsigned DEFAULT NULL,
  `modified_on` datetime DEFAULT NULL,
  `modified_by` int(11) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `user_module_survey_answers`;
CREATE TABLE IF NOT EXISTS `user_module_survey_answers` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `question_id` int(11) DEFAULT NULL,
  `module_id` int(11) DEFAULT NULL,
  `answer` int(11) DEFAULT NULL,
  `comment` varchar(255) DEFAULT NULL,
  `created_on` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

insert into module_survey_questions (id, question, sub_question, sequence, qtype, deleted, created_on, created_by)
values (1, "I was satisfied with the registration process.", null, 1, 0, 0, now(), 0);
insert into module_survey_questions (id, question, sub_question, sequence, qtype, deleted, created_on, created_by)
values (2, "Did the field trip and support materials support your learning process?", null, 2, 0, 0, now(), 0);
insert into module_survey_questions (id, question, sub_question, sequence, qtype, deleted, created_on, created_by)
values (3, "The course content was well organized.", null, 3, 0, 0, now(), 0);
insert into module_survey_questions (id, question, sub_question, sequence, qtype, deleted, created_on, created_by)
values (4, "Was the information presented in a clear and logical format?", null, 4, 0, 0, now(), 0);
insert into module_survey_questions (id, question, sub_question, sequence, qtype, deleted, created_on, created_by)
values (5, "Has your understanding of the VPK Education Standards increased as a result of this training?", null, 5, 0, 0, now(), 0);
insert into module_survey_questions (id, question, sub_question, sequence, qtype, deleted, created_on, created_by)
values (6, "Was the training a positive learning experience?", null, 6, 0, 0, now(), 0);
insert into module_survey_questions (id, question, sub_question, sequence, qtype, deleted, created_on, created_by)
values (7, "I would recommend the KidVision VPK program to others.", null, 7, 0, 0, now(), 0);
insert into module_survey_questions (id, question, sub_question, sequence, qtype, deleted, created_on, created_by)
values (8, "The course content met the objective and my expectations.", null, 8, 0, 0, now(), 0);
insert into module_survey_questions (id, question, sub_question, sequence, qtype, deleted, created_on, created_by)
values (9, "The instruction and delivery methods were effective.", null, 9, 0, 0, now(), 0);
insert into module_survey_questions (id, question, sub_question, sequence, qtype, deleted, created_on, created_by)
values (10, "I will be able to use the information from this workshop.", null, 10, 0, 0, now(), 0);
insert into module_survey_questions (id, question, sub_question, sequence, qtype, deleted, created_on, created_by)
values (11, "How do you intend to use the KidVision VPK program?", "For training purposes", 88, 1, 0, now(), 0);
insert into module_survey_questions (id, question, sub_question, sequence, qtype, deleted, created_on, created_by)
values (12, "How do you intend to use the KidVision VPK program?", "For teaching purposes", 89, 1, 0, now(), 0);
insert into module_survey_questions (id, question, sub_question, sequence, qtype, deleted, created_on, created_by)
values (13, "Additional comments and suggestions:", null, 99, 2, 0, now(), 0);


-- Aug 08 2014
alter table user_module_pretest_answers add column user_module_activity_id int(11) unsigned default null;
alter table user_module_survey_answers add column user_module_activity_id int(11) unsigned default null;

-- Aug 22 2014
alter table registration add column sage_payment_datetime datetime default null;
