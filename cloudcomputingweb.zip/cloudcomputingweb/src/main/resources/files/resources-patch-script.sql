Insert into kidvisiondb.resource_type
(id, type_name)
values(4, 'Module');

-- Dumping structure for table kidvisiondb.module_categories
DROP TABLE IF EXISTS `module_resources`;
CREATE TABLE IF NOT EXISTS `module_resources` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `module_id` int(11) unsigned DEFAULT NULL,
  `resource_id` int(11) DEFAULT NULL,
  `deleted` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- insert module_resources data
insert into module_resources (id, module_id, resource_id, deleted)
values( null, 121,1,0);
insert into module_resources (id, module_id, resource_id, deleted)
values( null, 122,2,0);
insert into module_resources (id, module_id, resource_id, deleted)
values( null, 123,3,0);
insert into module_resources (id, module_id, resource_id, deleted)
values( null, 124,4,0);
insert into module_resources (id, module_id, resource_id, deleted)
values( null, 125,5,0);
insert into module_resources (id, module_id, resource_id, deleted)
values( null, 126,6,0);
insert into module_resources (id, module_id, resource_id, deleted)
values( null, 127,7,0);
insert into module_resources (id, module_id, resource_id, deleted)
values( null, 128,8,0);
insert into module_resources (id, module_id, resource_id, deleted)
values( null, 129,9,0);
insert into module_resources (id, module_id, resource_id, deleted)
values( null, 130,10,0);
insert into module_resources (id, module_id, resource_id, deleted)
values( null, 131,11,0);
insert into module_resources (id, module_id, resource_id, deleted)
values( null, 132,12,0);

insert into module_resources (id, module_id, resource_id, deleted)
values( null, 133,13,0);
insert into module_resources (id, module_id, resource_id, deleted)
values( null, 134,14,0);
insert into module_resources (id, module_id, resource_id, deleted)
values( null, 135,15,0);
insert into module_resources (id, module_id, resource_id, deleted)
values( null, 136,16,0);
insert into module_resources (id, module_id, resource_id, deleted)
values( null, 137,17,0);
insert into module_resources (id, module_id, resource_id, deleted)
values( null, 138,18,0);
insert into module_resources (id, module_id, resource_id, deleted)
values( null, 139,19,0);
insert into module_resources (id, module_id, resource_id, deleted)
values( null, 140,20,0);
insert into module_resources (id, module_id, resource_id, deleted)
values( null, 141,21,0);
insert into module_resources (id, module_id, resource_id, deleted)
values( null, 142,22,0);
insert into module_resources (id, module_id, resource_id, deleted)
values( null, 142,23,0);
insert into module_resources (id, module_id, resource_id, deleted)
values( null, 143,24,0);
insert into module_resources (id, module_id, resource_id, deleted)
values( null, 144,25,0);
insert into module_resources (id, module_id, resource_id, deleted)
values( null, 145,26,0);
insert into module_resources (id, module_id, resource_id, deleted)
values( null, 146,27,0);
insert into module_resources (id, module_id, resource_id, deleted)
values( null, 147,28,0);
insert into module_resources (id, module_id, resource_id, deleted)
values( null, 148,29,0);
insert into module_resources (id, module_id, resource_id, deleted)
values( null, 149,30,0);
insert into module_resources (id, module_id, resource_id, deleted)
values( null, 150,31,0);
insert into module_resources (id, module_id, resource_id, deleted)
values( null, 151,32,0);
insert into module_resources (id, module_id, resource_id, deleted)
values( null, 152,33,0);
insert into module_resources (id, module_id, resource_id, deleted)
values( null, 153,34,0);
insert into module_resources (id, module_id, resource_id, deleted)
values( null, 154,35,0);
insert into module_resources (id, module_id, resource_id, deleted)
values( null, 155,36,0);
insert into module_resources (id, module_id, resource_id, deleted)
values( null, 156,37,0);
insert into module_resources (id, module_id, resource_id, deleted)
values( null, 157,38,0);
insert into module_resources (id, module_id, resource_id, deleted)
values( null, 158,39,0);
insert into module_resources (id, module_id, resource_id, deleted)
values( null, 159,40,0);
insert into module_resources (id, module_id, resource_id, deleted)
values( null, 160,41,0);
