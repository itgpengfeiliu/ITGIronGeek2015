delete from resources;
insert into resources (id, type_id, title,short_description, resource_url, image_file_path, created_by, created_on, modified_by, modified_on, deleted)
values (null, 4, 'Akido Dojo','Florida Aikido School', 'http://www.floridaaikikai.com/','akido_dojo.jpg',0,now(), null, null,0);

insert into resources (id, type_id, title,short_description, resource_url, image_file_path, created_by, created_on, modified_by, modified_on, deleted)
values (null, 4, 'Miami Airport','Tamiami Airport', 'http://www.miami-airport.com/kendall_tamiami.asp','miami_airport.jpg',0,now(), null, null,0);

insert into resources (id, type_id, title,short_description, resource_url, image_file_path, created_by, created_on, modified_by, modified_on, deleted)
values (null, 4, 'Animal Shelter','Palm Beach Animal Shelter', 'http://www.pbcgov.com/publicsafety/animalcare/','palmbeachanimalshelter.jpg',0,now(), null, null,0);

insert into resources (id, type_id, title,short_description, resource_url, image_file_path, created_by, created_on, modified_by, modified_on, deleted)
values (null, 4, 'Aquatic Complex','Ft. Lauderdale Aquatic Complex & International Swimming Hall of Fame', '"http://www.ishof.org/','aquatic_complex.jpg',0,now(), null, null,0);

insert into resources (id, type_id, title,short_description, resource_url, image_file_path, created_by, created_on, modified_by, modified_on, deleted)
values (null, 4, 'Bake Shop','Sweeter Days Bake Shop', 'http://www.sweeterdaysbakeshop.com/','bake_shop.jpg',0,now(), null, null,0);

insert into resources (id, type_id, title,short_description, resource_url, image_file_path, created_by, created_on, modified_by, modified_on, deleted)
values (null, 4, 'Bank & Money','Sun Trust Bank Miami Beach Branch', 'https://www.suntrust.com/FindUs?storesearch=33139','suntrustmiamibeach.jpg',0,now(), null, null,0);

insert into resources (id, type_id, title,short_description, resource_url, image_file_path, created_by, created_on, modified_by, modified_on, deleted)
values (null, 4, 'Baseball','Marlin?s Baseball Park', 'http://miami.marlins.mlb.com/index.jsp?c_id=mia','miamimarlins.jpg',0,now(), null, null,0);

insert into resources (id, type_id, title,short_description, resource_url, image_file_path, created_by, created_on, modified_by, modified_on, deleted)
values (null, 4, 'Biscayne National Park','Biscayne National Park', 'http://www.nps.gov/bisc/index.htm','biscaynenationalpark.jpg',0,now(), null, null,0);

insert into resources (id, type_id, title,short_description, resource_url, image_file_path, created_by, created_on, modified_by, modified_on, deleted)
values (null, 4, 'Butterfly World','Butterfly World at Tradewinds Park', 'http://www.butterflyworld.com/','butterflyworld.jpg',0,now(), null, null,0);

insert into resources (id, type_id, title,short_description, resource_url, image_file_path, created_by, created_on, modified_by, modified_on, deleted)
values (null, 4, 'Children`s Hospital','Joe DiMaggio Children`s Hospital', 'http://www.jdch.com/','joedimaggiohospital.jpg',0,now(), null, null,0);

insert into resources (id, type_id, title,short_description, resource_url, image_file_path, created_by, created_on, modified_by, modified_on, deleted)
values (null, 4, 'Children`s Theater','Ft. Lauderdale Children?s Theater', 'http://www.flct.org/','ftlauderdalechildrenstheater.jpg',0,now(), null, null,0);

insert into resources (id, type_id, title,short_description, resource_url, image_file_path, created_by, created_on, modified_by, modified_on, deleted)
values (null, 4, 'Construction Site','Suffolk Construction', 'http://www.suffolkconstruction.com/','suffolkconstruction.jpg',0,now(), null, null,0);

insert into resources (id, type_id, title,short_description, resource_url, image_file_path, created_by, created_on, modified_by, modified_on, deleted)
values (null, 4, 'Dentist`s Office','Miami Children`s Smiles Pediatric Dentistry', 'https://www.miamichildrensmiles.com/','miamichildrenssmiles.jpg',0,now(), null, null,0);

insert into resources (id, type_id, title,short_description, resource_url, image_file_path, created_by, created_on, modified_by, modified_on, deleted)
values (null, 4, 'Fire Station','Hollywood Fire Rescue Station #74', 'http://www.hollywoodfl.org/index.aspx?NID=95','fire_station.jpg',0,now(), null, null,0);

insert into resources (id, type_id, title,short_description, resource_url, image_file_path, created_by, created_on, modified_by, modified_on, deleted)
values (null, 4, 'Flamingo Gardens','Flamingo Gardens', 'http://www.flamingogardens.org/','flamingo_garden.jpg',0,now(), null, null,0);

insert into resources (id, type_id, title,short_description, resource_url, image_file_path, created_by, created_on, modified_by, modified_on, deleted)
values (null, 4, 'G.R.O.W. Project','G.R.O.W. Project', 'http://www.miamigrowproject.org/','grow_project.jpg',0,now(), null, null,0);

insert into resources (id, type_id, title,short_description, resource_url, image_file_path, created_by, created_on, modified_by, modified_on, deleted)
values (null, 4, 'Grocery Store','Whole Foods Market Aventura', 'http://www.wholefoodsmarket.com/stores/aventura','grocery_store.jpg',0,now(), null, null,0);

insert into resources (id, type_id, title,short_description, resource_url, image_file_path, created_by, created_on, modified_by, modified_on, deleted)
values (null, 4, 'Gymnastics','Miami Gymnastics and Dance Academy', 'http://www.miamigymnastics.com/','gymnastics.jpg',0,now(), null, null,0);

insert into resources (id, type_id, title,short_description, resource_url, image_file_path, created_by, created_on, modified_by, modified_on, deleted)
values (null, 4, 'Healthy Foods at Jungle Island','Jungle Island', 'http://www.jungleisland.com/','healthy_food.jpg',0,now(), null, null,0);

insert into resources (id, type_id, title,short_description, resource_url, image_file_path, created_by, created_on, modified_by, modified_on, deleted)
values (null, 4, 'Horse Farm','Condee Horse Farm', 'http://www.condeefarm.com/','horse_farm.jpg',0,now(), null, null,0);

insert into resources (id, type_id, title,short_description, resource_url, image_file_path, created_by, created_on, modified_by, modified_on, deleted)
values (null, 4, 'Kindergarten','Oakridge Elementary School', 'http://oakridge.browardschools.com/','kindergarten.jpg',0,now(), null, null,0);

insert into resources (id, type_id, title,short_description, resource_url, image_file_path, created_by, created_on, modified_by, modified_on, deleted)
values (null, 4, 'Kites','Skyward Kites', 'https://sites.google.com/site/skywardkites/home/','kites.jpg',0,now(), null, null,0);

insert into resources (id, type_id, title,short_description, resource_url, image_file_path, created_by, created_on, modified_by, modified_on, deleted)
values (null, 4, 'Kites','Haulover Park', 'http://www.miamidade.gov/parks/haulover.asp','kites_park.jpg',0,now(), null, null,0);

insert into resources (id, type_id, title,short_description, resource_url, image_file_path, created_by, created_on, modified_by, modified_on, deleted)
values (null, 4, 'Library','Miami-Dade Public Library Coral Gables Branch', 'http://www.mdpls.org/','library.jpg',0,now(), null, null,0);

insert into resources (id, type_id, title,short_description, resource_url, image_file_path, created_by, created_on, modified_by, modified_on, deleted)
values (null, 4, 'Music Store','Sam Ash Music Store Miami Lakes', 'http://samashmusic.com/portal/','music_store.jpg',0,now(), null, null,0);

insert into resources (id, type_id, title,short_description, resource_url, image_file_path, created_by, created_on, modified_by, modified_on, deleted)
values (null, 4, 'Native Village','Native Village', 'http://nativevillagezoo.angelfire.com/','native_village.jpg',0,now(), null, null,0);

insert into resources (id, type_id, title,short_description, resource_url, image_file_path, created_by, created_on, modified_by, modified_on, deleted)
values (null, 4, 'Oceanographic Center','Nova Southeastern University Oceanographic Center', 'http://www.nova.edu/ocean/','oceanographic.jpg',0,now(), null, null,0);

insert into resources (id, type_id, title,short_description, resource_url, image_file_path, created_by, created_on, modified_by, modified_on, deleted)
values (null, 4, 'Paper Niche',null, 'http://www.paperniche.com','paper_niche.jpg',0,now(), null, null,0);

insert into resources (id, type_id, title,short_description, resource_url, image_file_path, created_by, created_on, modified_by, modified_on, deleted)
values (null, 4, 'Pizza Restaurant','Peace A Pizza', 'http://www.PeaceAPizza.com','pizza_restaurant.jpg',0,now(), null, null,0);

insert into resources (id, type_id, title,short_description, resource_url, image_file_path, created_by, created_on, modified_by, modified_on, deleted)
values (null, 4, 'Playground','T.Y. Park', 'http://www.broward.org/parks/TopeekeegeeYugneePark/pages/default.aspx','playground.jpg',0,now(), null, null,0);

insert into resources (id, type_id, title,short_description, resource_url, image_file_path, created_by, created_on, modified_by, modified_on, deleted)
values (null, 4, 'Pottery Studio','Palm Beach Animal Shelter', 'http://www.joepicassos.com','pottery_studio.jpg',0,now(), null, null,0);

insert into resources (id, type_id, title,short_description, resource_url, image_file_path, created_by, created_on, modified_by, modified_on, deleted)
values (null, 4, 'Railroad Museum','Gold Coast Railroad Museum', 'http://gcrm.org/','railroad_museum.jpg',0,now(), null, null,0);

insert into resources (id, type_id, title,short_description, resource_url, image_file_path, created_by, created_on, modified_by, modified_on, deleted)
values (null, 4, 'Recycling Center','Waste Services of Florida', 'http://www.wasteservicesinc.com','recycling_center.jpg',0,now(), null, null,0);

insert into resources (id, type_id, title,short_description, resource_url, image_file_path, created_by, created_on, modified_by, modified_on, deleted)
values (null, 4, 'ReThink and ReUse Center','ReThink and ReUse Center', 'http://www.rethinkandreusemiami.org','rethink_reusecenter.jpg',0,now(), null, null,0);

insert into resources (id, type_id, title,short_description, resource_url, image_file_path, created_by, created_on, modified_by, modified_on, deleted)
values (null, 4, 'School Bus Depot','Miami-Dade County Public Schools Department of Transportation', 'http://dot.dadeschools.net','school_busdepot.jpg',0,now(), null, null,0);

insert into resources (id, type_id, title,short_description, resource_url, image_file_path, created_by, created_on, modified_by, modified_on, deleted)
values (null, 4, 'Science Museum','Miami Science Museum', 'https://www.miamisci.org','science_museum.jpg',0,now(), null, null,0);

insert into resources (id, type_id, title,short_description, resource_url, image_file_path, created_by, created_on, modified_by, modified_on, deleted)
values (null, 4, 'Sheriff`s Office','Martin County Sheriff?s Office', 'http://www.sheriff.martin.fl.us','sheriffs_office.jpg',0,now(), null, null,0);

insert into resources (id, type_id, title,short_description, resource_url, image_file_path, created_by, created_on, modified_by, modified_on, deleted)
values (null, 4, 'TV Station','WPBT Channel 2', 'http://www.wpbt2.org','tv_station.jpg',0,now(), null, null,0);

insert into resources (id, type_id, title,short_description, resource_url, image_file_path, created_by, created_on, modified_by, modified_on, deleted)
values (null, 4, 'Weather Station','National Weather Service & National Hurricane Center', 'http://www.weather.gov/miami','weather_station.jpg',0,now(), null, null,0);

insert into resources (id, type_id, title,short_description, resource_url, image_file_path, created_by, created_on, modified_by, modified_on, deleted)
values (null, 4, 'Young At Art Museum','Young At Art Museum', 'http://www.YoungAtArtMuseum.org','young_museum.jpg',0,now(), null, null,0);

insert into resources (id, type_id, title,short_description, resource_url, image_file_path, created_by, created_on, modified_by, modified_on, deleted)
values (null, 4, 'Zoo','Zoo Miami', 'http://www.zoomiami.org','zoomiami.jpg',0,now(), null, null,0);

