
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Dumping database structure for kidvisiondb
DROP DATABASE IF EXISTS `kidvisiondb`;
CREATE DATABASE IF NOT EXISTS `kidvisiondb` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `kidvisiondb`;


-- Dumping structure for table kidvisiondb.address
DROP TABLE IF EXISTS `address`;
CREATE TABLE IF NOT EXISTS `address` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `streetaddress` varchar(255) DEFAULT NULL,
  `country` varchar(45) DEFAULT NULL,
  `state` varchar(45) DEFAULT NULL,
  `city` varchar(45) DEFAULT NULL,
  `zipcode` varchar(45) DEFAULT NULL,
  `county` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.


-- Dumping structure for table kidvisiondb.answers
DROP TABLE IF EXISTS `answers`;
CREATE TABLE IF NOT EXISTS `answers` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `question_id` int(11) DEFAULT NULL,
  `answer_value` varchar(255) DEFAULT NULL,
  `correct` smallint(1) NOT NULL DEFAULT '0',
  `sequence` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table kidvisiondb.authentication_questions
DROP TABLE IF EXISTS `authentication_questions`;
CREATE TABLE IF NOT EXISTS `authentication_questions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `question` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.


-- Dumping structure for table kidvisiondb.authentication_user_answers
DROP TABLE IF EXISTS `authentication_user_answers`;
CREATE TABLE IF NOT EXISTS `authentication_user_answers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `authentication_question_id` int(11) DEFAULT NULL,
  `answer` varchar(100) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `created_on` datetime DEFAULT NULL,
  `updated_on` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.


-- Dumping structure for table kidvisiondb.categories
DROP TABLE IF EXISTS `categories`;
CREATE TABLE IF NOT EXISTS `categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category` varchar(255) DEFAULT NULL,
  `created_on` datetime DEFAULT NULL,
  `deleted` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.


-- Dumping structure for table kidvisiondb.config
DROP TABLE IF EXISTS `config`;
CREATE TABLE IF NOT EXISTS `config` (
  `id` int(11) NOT NULL,
  `tm_registration_amount` decimal(10,2) DEFAULT NULL,
  `discount_amount` int(11) DEFAULT NULL,
  `current_school_year_from` datetime DEFAULT NULL,
  `current_school_year_to` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.


-- Dumping structure for table kidvisiondb.modules
DROP TABLE IF EXISTS `modules`;
CREATE TABLE IF NOT EXISTS `modules` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `short_description` varchar(255) DEFAULT NULL,
  `long_description` longtext,
  `pdf_lesson_plan` varchar(255) DEFAULT NULL,
  `student_assessment_form` varchar(255) DEFAULT NULL,
  `activity_plan` varchar(255) DEFAULT NULL,
  `coloring_worksheets` varchar(255) DEFAULT NULL,
  `image_file` varchar(255) DEFAULT NULL,
  `icon_file` varchar(255) DEFAULT NULL,
  `sequence` int(11) DEFAULT NULL,
  `created_on` datetime DEFAULT NULL,
  `createdby_id` int(11) DEFAULT NULL,
  `updated_on` datetime DEFAULT NULL,
  `modifiedby_id` int(11) DEFAULT NULL,
  `deleted` smallint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table kidvisiondb.module_categories
DROP TABLE IF EXISTS `module_categories`;
CREATE TABLE IF NOT EXISTS `module_categories` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `module_id` int(11) unsigned DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL,
  `deleted` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping structure for table kidvisiondb.module_categories
DROP TABLE IF EXISTS `module_resources`;
CREATE TABLE IF NOT EXISTS `module_resources` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `module_id` int(11) unsigned DEFAULT NULL,
  `resource_id` int(11) DEFAULT NULL,
  `deleted` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- Dumping structure for table kidvisiondb.occupational_titles
DROP TABLE IF EXISTS `occupational_titles`;
CREATE TABLE IF NOT EXISTS `occupational_titles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `occupational_title` varchar(145) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.


-- Dumping structure for table kidvisiondb.questions
DROP TABLE IF EXISTS `questions`;
CREATE TABLE IF NOT EXISTS `questions` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `module_id` int(11) DEFAULT NULL,
  `standard` varchar(45) DEFAULT NULL,
  `standard_id` int(11) DEFAULT NULL,
  `question` varchar(255) DEFAULT NULL,
  `sequence` int(11) DEFAULT NULL,
  `deleted` smallint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table kidvisiondb.registration
DROP TABLE IF EXISTS `registration`;
CREATE TABLE IF NOT EXISTS `registration` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `order_dvd` tinyint(4) DEFAULT NULL,
  `from_datetime` datetime DEFAULT NULL,
  `to_datetime` datetime DEFAULT NULL,
  `createdon_datetime` datetime DEFAULT NULL,
  `createdby_id` int(11) unsigned DEFAULT NULL,
  `modifiedon_datetime` datetime DEFAULT NULL,
  `modifiedby_id` int(11) unsigned DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.


-- Dumping structure for table kidvisiondb.registrationtypes
DROP TABLE IF EXISTS `registrationtypes`;
CREATE TABLE IF NOT EXISTS `registrationtypes` (
  `id` tinyint(4) NOT NULL,
  `registrationtype_name` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.


-- Dumping structure for table kidvisiondb.resources
DROP TABLE IF EXISTS `resources`;
CREATE TABLE IF NOT EXISTS `resources` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `type_id` int(11) DEFAULT NULL,
  `title` varchar(145) DEFAULT NULL,
  `short_description` varchar(255) DEFAULT NULL,
  `resource_url` varchar(255) DEFAULT NULL,
  `image_file_path` varchar(255) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_on` datetime DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `modified_on` datetime DEFAULT NULL,
  `deleted` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.


-- Dumping structure for table kidvisiondb.resource_type
DROP TABLE IF EXISTS `resource_type`;
CREATE TABLE IF NOT EXISTS `resource_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type_name` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.


-- Dumping structure for table kidvisiondb.roles
DROP TABLE IF EXISTS `roles`;
CREATE TABLE IF NOT EXISTS `roles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role_name` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.


-- Dumping structure for table kidvisiondb.sponsors
DROP TABLE IF EXISTS `sponsors`;
CREATE TABLE IF NOT EXISTS `sponsors` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `image_file_path` varchar(255) DEFAULT NULL,
  `sponsor_url` varchar(255) DEFAULT NULL,
  `created_on` datetime DEFAULT NULL,
  `created_by` int(11) unsigned DEFAULT NULL,
  `modified_on` datetime DEFAULT NULL,
  `modified_by` int(11) unsigned DEFAULT NULL,
  `deleted` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.


-- Dumping structure for table kidvisiondb.standards
DROP TABLE IF EXISTS `standards`;
CREATE TABLE IF NOT EXISTS `standards` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `module_id` int(11) DEFAULT NULL,
  `title` varchar(45) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `standard_no` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.


-- Dumping structure for table kidvisiondb.survey_questions
DROP TABLE IF EXISTS `survey_questions`;
CREATE TABLE IF NOT EXISTS `survey_questions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `question` varchar(255) DEFAULT NULL,
  `sequence` int(11) DEFAULT NULL,
  `deleted` tinyint(4) DEFAULT NULL,
  `created_on` datetime DEFAULT NULL,
  `created_by` int(11) unsigned DEFAULT NULL,
  `modified_on` datetime DEFAULT NULL,
  `modified_by` int(11) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.


-- Dumping structure for table kidvisiondb.survey_results
DROP TABLE IF EXISTS `survey_results`;
CREATE TABLE IF NOT EXISTS `survey_results` (
  `question` int(11) unsigned NOT NULL,
  `yes` int(11) DEFAULT NULL,
  `no` int(11) DEFAULT NULL,
  PRIMARY KEY (`question`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table kidvisiondb.users
DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `middle_name` varchar(45) DEFAULT NULL,
  `user_name` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `role_id` tinyint(4) NOT NULL DEFAULT '2',
  `occupational_title_id` int(11) DEFAULT NULL,
  `other_occupational_title` varchar(255) DEFAULT NULL,
  `facility_type` varchar(50) DEFAULT NULL,
  `email_notification` tinyint(1) unsigned DEFAULT NULL,
  `phone` varchar(45) DEFAULT NULL,
  `registrationtype_id` tinyint(4) DEFAULT NULL,
  `current_registration_id` int(11) unsigned DEFAULT NULL,
  `primary_address_Id` int(11) unsigned DEFAULT NULL,
  `billing_address_Id` int(11) unsigned DEFAULT NULL,
  `shipping_address_Id` int(11) unsigned DEFAULT NULL,
  `pretest_completed` tinyint(1) unsigned DEFAULT '1',
  `created_on` datetime DEFAULT NULL,
  `updated_on` datetime DEFAULT NULL,
  `createdby_id` int(11) unsigned DEFAULT NULL,
  `updatedby_id` int(11) unsigned DEFAULT NULL,
  `is_active` smallint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table kidvisiondb.user_module_activity
DROP TABLE IF EXISTS `user_module_activity`;
CREATE TABLE IF NOT EXISTS `user_module_activity` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned DEFAULT NULL,
  `module_id` int(11) unsigned DEFAULT NULL,
  `activity_type` varchar(45) DEFAULT NULL,
  `activity_name` varchar(255) DEFAULT NULL,
  `is_completed` tinyint(4) DEFAULT NULL,
  `start_datetime` datetime DEFAULT NULL,
  `end_datetime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.


-- Dumping structure for table kidvisiondb.user_module_certificate
DROP TABLE IF EXISTS `user_module_certificate`;
CREATE TABLE IF NOT EXISTS `user_module_certificate` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `module_id` int(11) NOT NULL,
  `file_name` varchar(255) DEFAULT NULL,
  `created_on` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table kidvisiondb.user_module_test
DROP TABLE IF EXISTS `user_module_test`;
CREATE TABLE IF NOT EXISTS `user_module_test` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `module_id` int(11) DEFAULT NULL,
  `is_completed` tinyint(4) DEFAULT '0',
  `is_passed` tinyint(4) DEFAULT NULL,
  `correct_answers_count` tinyint(4) DEFAULT NULL,
  `total_question_count` tinyint(4) DEFAULT NULL,
  `started_on` datetime DEFAULT NULL,
  `completed_on` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_key_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.


-- Dumping structure for table kidvisiondb.user_module_test_answers
DROP TABLE IF EXISTS `user_module_test_answers`;
CREATE TABLE IF NOT EXISTS `user_module_test_answers` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `user_module_test_id` int(11) DEFAULT NULL,
  `question_id` int(11) DEFAULT NULL,
  `answer_id` int(11) DEFAULT NULL,
  `created_on` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.


-- Dumping structure for table kidvisiondb.user_pretest_answers
DROP TABLE IF EXISTS `user_pretest_answers`;
CREATE TABLE IF NOT EXISTS `user_pretest_answers` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `question_id` int(11) DEFAULT NULL,
  `answer_id` int(11) DEFAULT NULL,
  `created_on` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.


-- Dumping structure for table kidvisiondb.user_survey_answers
DROP TABLE IF EXISTS `user_survey_answers`;
CREATE TABLE IF NOT EXISTS `user_survey_answers` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned DEFAULT NULL,
  `survey_question_id` int(11) DEFAULT NULL,
  `survey_answer_yes_no` tinyint(4) DEFAULT NULL,
  `created_on` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.


-- Dumping structure for table kidvisiondb.videos
DROP TABLE IF EXISTS `videos`;
CREATE TABLE IF NOT EXISTS `videos` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `module_id` int(11) DEFAULT NULL,
  `file_name` varchar(255) DEFAULT NULL,
  `video_streaming_id` varchar(145) DEFAULT NULL,
  `is_overview` smallint(1) NOT NULL DEFAULT '0',
  `sequence` tinyint(4) DEFAULT NULL,
  `created_on` datetime DEFAULT NULL,
  `createdby_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- Data exporting was unselected.
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
