delete from kidvisiondb.users where created_on > '2014-05-30 15:47:58' and created_on < '2014-06-02 10:25:38' and id <> 0;
delete from kidvisiondb.user_module_test where started_on > '2014-05-30 15:47:58' and started_on < '2014-06-02 10:25:38';
delete from kidvisiondb.user_module_test_answers where created_on > '2014-05-30 15:47:58' and created_on < '2014-06-02 10:25:38';
delete from kidvisiondb.user_module_certificate where created_on > '2014-05-30 15:47:58' and created_on < '2014-06-02 10:25:38';
delete from kidvisiondb.user_module_activity where start_datetime > '2014-05-30 15:47:58' and start_datetime < '2014-06-02 10:25:38';

alter table users add column old_id int(11) unsigned Default NULL;

alter table user_module_test add column old_id int(11) unsigned Default NULL;

/*insert user data */
INSERT INTO kidvisiondb.users 
SELECT 
null, 
first_name, 
last_name,
null, 
user_name, 
password, 
email, 
CASE when is_admin=1 then 1 else 2 END as 'role_id' ,
null,
null,
facility_type,
send_mail,
null,
null,
null,
null,
null,
null,
"1",
created_on,
updated_on,
0,
0,
is_active,
0,
id
FROM vpk.users
where vpk.users.created_on > '2014-05-30 15:36:20';

/* update user occupation*/
update kidvisiondb.users ku
inner join vpk.users vu on ku.old_id=vu.id
inner join kidvisiondb.occupational_titles ko on vu.occuption=ko.occupational_title
set ku.occupational_title_id=ko.id,
ku.other_occupational_title=vu.other_occuption
where ku.occupational_title_id is null and ku.old_id is not null;

update kidvisiondb.users ku
inner join vpk.users vu on ku.old_id=vu.id
inner join kidvisiondb.occupational_titles ko on upper(vu.pos_title)=upper(ko.occupational_title)
set ku.occupational_title_id=ko.id
where vu.pos_title is not null and vu.pos_title <> '' and vu.occuption is null and ku.occupational_title_id is null and ku.old_id is not null;

update kidvisiondb.users ku inner join vpk.users vu on ku.Old_id=vu.id
set ku.occupational_title_id=6,
ku.other_occupational_title=vu.pos_title
where 
ku.occupational_title_id is null 
and ku.other_occupational_title is null
and vu.pos_title is not null 
and vu.pos_title <> ''
and vu.occuption is null
and ku.old_id is not null;

/* insert kidvisiondb.registration data */
insert into kidvisiondb.registration
select distinct
null,
ku.id,
0,
'2013-07-01 00:00:00',
'2014-07-01 00:00:00',
now(),
0,
null,
null,
1
from vpk.users vu 
inner join vpk.user_certificates vuc on vu.id=vuc.user_id
inner join kidvisiondb.users ku on vu.id=ku.old_id
where ku.role_id =2 and ku.updatedby_id=0 ;

/* update kidvisiondb.user registration data */
update kidvisiondb.users ku inner join kidvisiondb.registration kr on ku.id=kr.user_id
set ku.current_registration_id=kr.id, ku.registrationtype_id=2
where ku.updatedby_id=0;

update kidvisiondb.users ku set ku.registrationtype_id=1 where ku.registrationtype_id is null;




/* insert user module test data */
insert into kidvisiondb.user_module_test
SELECT
	null,
	ku.id,
	t.module_id,
	null,
	null,
	null,
	null,
	ut.created_on,
	ut.created_on,
        ut.id
FROM
	vpk.tests t
	INNER JOIN vpk.user_tests ut
	 ON t.id = ut.test_id
	 INNER JOIN kidvisiondb.users ku
	 ON ut.user_id=ku.old_id
where 
	ut.created_on > '2014-05-30 15:47:58'
union 
SELECT
	null,
	ku.id,
	t.module_id,
	null,
	null,
	null,
	null,
	ut.created_on,
	ut.created_on,
        ut.id

FROM
	vpk.tests t
	INNER JOIN vpk.user_tests ut
	 ON t.id = ut.test_id
	 INNER JOIN kidvisiondb.users ku
	 ON ut.user_id=ku.id
where 
	ut.created_on > '2014-05-30 15:47:58';
	 
/* insert user_module_test_answers data */
insert into kidvisiondb.user_module_test_answers
SELECT
	null,
	ua.user_id,
	umt.id,
	ua.question_id,
	ua.answer_id,
	ua.created_on
FROM
	vpk.user_answers ua
	INNER JOIN kidvisiondb.user_module_test umt
         on ua.user_test_id=umt.old_id
where
	ua.created_on > '2014-05-30 15:47:58';

	
	
/* insert user_module_certificate data*/

insert into kidvisiondb.user_module_certificate
SELECT
	null,
	ku.id,
	uc.module_id,
	uc.file,
	uc.created_on
FROM
	vpk.user_certificates uc
	INNER JOIN kidvisiondb.users ku
	 ON uc.user_id=ku.old_id
where
	uc.created_on > '2014-05-30 15:47:58'
union
SELECT
	null,
	ku.id,
	uc.module_id,
	uc.file,
	uc.created_on
FROM
	vpk.user_certificates uc
	INNER JOIN kidvisiondb.users ku
	 ON uc.user_id=ku.id
where
	uc.created_on > '2014-05-30 15:47:58';

/* insert user_module_activity data */
insert into kidvisiondb.user_module_activity
select null, ku.id, um.module_id, um.bookmark, null, um.viewed_videos, um.created_on, um.completed_on 
from vpk.user_modules um
	INNER JOIN kidvisiondb.users ku
	ON um.user_id=ku.old_id
where
		um.created_on > '2014-05-30 15:46:59'
union
select null, ku.id, um.module_id, um.bookmark, null, um.viewed_videos, um.created_on, um.completed_on 
from vpk.user_modules um
	INNER JOIN kidvisiondb.users ku
	ON um.user_id=ku.id
where
		um.created_on > '2014-05-30 15:46:59';

/* insert kidvisiondb.user_pretest_answers data */
insert into kidvisiondb.user_pretest_answers
select 
null,
ku.id,
qr.question_id,
qr.answer_id,
qr.created_on
from vpk.questionnaire_results qr
INNER JOIN kidvisiondb.users ku
	ON qr.user_id=ku.old_id
where
	qr.created_on > '2014-05-30 15:13:42'
union 
select 
null,
ku.id,
qr.question_id,
qr.answer_id,
qr.created_on
from vpk.questionnaire_results qr
INNER JOIN kidvisiondb.users ku
	ON qr.user_id=ku.id
where
	qr.created_on > '2014-05-30 15:13:42';

alter table users drop column old_id;
alter table user_module_test drop column old_id