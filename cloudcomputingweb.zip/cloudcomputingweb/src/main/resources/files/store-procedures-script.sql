-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               5.6.10 - MySQL Community Server (GPL)
-- Server OS:                    Win64
-- HeidiSQL Version:             8.3.0.4694
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Dumping structure for procedure kidvisiondb.createModuleFromExistingModule
DROP PROCEDURE IF EXISTS `createModuleFromExistingModule`;
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `createModuleFromExistingModule`(IN created_by_id int(11), IN from_module_id INT(11), IN new_module_title varchar(255) )
BEGIN
declare new_module_id int(11);
declare resource_id int(11);
-- declare new_resource_id int(11);

insert into modules
select 
null, 
new_module_title,
om.short_description,
om.long_description,
om.pdf_lesson_plan,
om.student_assessment_form,
om.activity_plan,
om.coloring_worksheets,
om.image_file,
om.icon_file,
null,
now(),
created_by_id,
null,
null,
1
from modules om
where om.id=from_module_id;

select id into new_module_id from modules where title=new_module_title;

select r.id into resource_id from resources r inner join module_resources mr on mr.resource_id=r.id
where mr.module_id=from_module_id and mr.deleted=0 limit 1;

-- insert into resources
-- select null, 4, title, short_description, resource_url, image_file_path, created_by_id, now(), null, null, 0
-- from resources
-- where id = resource_id;
-- SELECT LAST_INSERT_ID() INTO new_resource_id;

insert into module_resources
values (null, new_module_id, resource_id, 0);

insert into standards
select null, new_module_id, s.title, s.description, s.standard_no 
from standards s
where s.module_id = from_module_id;

insert into questions
select null, new_module_id, q.standard, q.standard_id, q.question, q.sequence, q.deleted 
from questions q
where q.module_id=from_module_id;

insert into answers
select
null,
q.new_question_id,
a.answer_value,
a.correct,
a.sequence
from answers a inner join (
SELECT distinct oq.id as 'old_question_id', nq.id as 'new_question_id', new_module_id as 'new_module_id'
FROM
	questions oq
inner join questions nq on oq.question=nq.question
where nq.module_id=new_module_id and oq.module_id=from_module_id) q on a.question_id=q.old_question_id;

insert into module_categories
select null, new_module_id, mc.category_id, mc.deleted
from module_categories mc
where mc.module_id=from_module_id;

/*select new_module_id;*/
SELECT * FROM modules WHERE modules.id = new_module_id;
END//
DELIMITER ;


-- Dumping structure for procedure kidvisiondb.getTranscriptDetails
DROP PROCEDURE IF EXISTS `getTranscriptDetails`;
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `getTranscriptDetails`(IN userId int(11), IN testYear int)
BEGIN

	-- , '1.0' as 'hrs'  , '0.1' as 'ceus'
select distinct m.id as 'course_id', m.title, umt.id as 'certificate_id', date(umt.started_on) as 'date',
max(case when s.standard_no = 1 then s.description end) as 's1', 
max(case when s.standard_no = 2 then s.description end) as 's2',
max(case when s.standard_no = 3 then s.description end) as 's3',
max(case when s.standard_no = 4 then s.description end) as 's4'
from user_module_test umt inner join modules m on umt.module_id=m.id
inner join standards s on s.module_id=m.id
where umt.is_passed=1 and umt.user_id=userId
and (year(umt.started_on)=testYear or year(umt.started_on)=testYear+1)
and date(umt.started_on) < date(CONCAT(testYear+1, '-07-01'))
and date(umt.started_on) > date(CONCAT(testYear, '-06-30'))
group by m.id;

END//
DELIMITER ;
-- --and ( date(umt.started_on) < date(CONCAT(testYear+1, '-07-01')) and date(umt.started_on) > date(CONCAT(testYear, '-06-30')) )



-- Dumping structure for procedure kidvisiondb.getTranscriptTitles
DROP PROCEDURE IF EXISTS `getTranscriptTitles`;
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `getTranscriptTitles`(IN userId int(11))
BEGIN

select distinct umt.user_id, case when month(umt.started_on) <= 12 and month(umt.started_on) > 6 then year(umt.started_on) else year(umt.started_on)-1 end AS test_year, 
case when month(umt.started_on) <= 12 and month(umt.started_on) > 6 then CONCAT('KIDVISION VPK TRAINING TRANSCRIPT - ', CONCAT(year(umt.started_on), '-', year(umt.started_on)+1)) else CONCAT('KIDVISION VPK TRAINING TRANSCRIPT - ', CONCAT(year(umt.started_on)-1, '-', year(umt.started_on))) end as test_title
from user_module_test umt
where umt.user_id=userId and umt.is_passed=1
order by umt.started_on desc;

END//
DELIMITER ;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;



-- Dumping structure for procedure kidvisiondb.getModuleResources
DROP PROCEDURE IF EXISTS `getModuleResources`;
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `getModuleResources`(IN moduleId int(11))
BEGIN

select r.*
from resources r inner join module_resources mr on mr.resource_id=r.id
where mr.module_id=moduleId and mr.deleted=0;

END//
DELIMITER ;


-- Dumping structure for procedure kidvisiondb.syncDataAnddeleteDuplicateId
DROP PROCEDURE IF EXISTS `syncDataAnddeleteDuplicateId`;
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `syncDataAnddeleteDuplicateId`(IN `deleteUserId` int(11), IN `updateUserId` int(11))
BEGIN

update user_module_test set user_id=updateUserId where user_id=deleteUserId;
update user_module_test_answers set user_id=updateUserId where user_id=deleteUserId;
update user_pretest_answers set user_id=updateUserId where user_id=deleteUserId;
update user_survey_answers set user_id=updateUserId where user_id=deleteUserId;
update users_login set user_id=updateUserId where user_id=deleteUserId;
delete from users where id=deleteUserId;

END//
DELIMITER ;


-- Dumping structure for procedure kidvisiondb.updateSchoolFiscalYear
DROP PROCEDURE IF EXISTS `updateSchoolFiscalYear`;
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `updateSchoolFiscalYear`()
BEGIN

declare config_currentSchoolYearFrom datetime;

UPDATE config SET current_school_year_from = DATE_ADD(current_school_year_from, INTERVAL 1 YEAR), current_school_year_to = DATE_ADD(current_school_year_to, INTERVAL 1 YEAR)
where year(current_school_year_to)=year(now());

select current_school_year_from into config_currentSchoolYearFrom from config;

update registration set is_active=0 where is_active=1 and from_datetime <> config_currentSchoolYearFrom;

END//
DELIMITER ;
