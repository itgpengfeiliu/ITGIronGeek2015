insert into modules (title, short_description, long_description,
	pdf_lesson_plan, student_assessment_form, activity_plan, coloring_worksheets,
	image_file, icon_file, sequence, created_on, createdby_id, updated_on, modifiedby_id, deleted)
values ("Post Office 2013-2014", null, "The KidVision VPK group talks in front of the post office, next to the mailbox",
    "VPK-Post-Office-2013-Lesson-Plans.pdf", "VPK-Post-Office-2013-Assessment.pdf", null,
    "VPK-Post-Office-Take-Home.pdf", "vpkpostoffice_thumbnail_1920.jpg", "PostOffice_ icon_125x125.png",
    null, now(), 0, null, null, 0);
    
SET @newId = 0;
select id INTO @newId from modules where title = "Post Office 2013-2014";

update modules set sequence = @newId where id = @newId;
    
--insert into videos (module_id, file_name, video_streaming_id, is_overview, sequence, created_on, createdby_id)
--values (@newId, "postofficefieldtrip.mp4", "yQxb2UR-lPg", 0, null, now(), 0);
--insert into videos(module_id, file_name, video_streaming_id, is_overview, sequence, created_on, createdby_id)
--values (@newId, "postofficestandup.mp4", "Rt5V0vZXr7U", 1, null, now(), 0);

SET @sid0 = 0;
insert into standards (module_id, title, description, standard_no)
values (@newId, "standard_1", "Emergent Reading: Phonological Awareness", 0);
SELECT LAST_INSERT_ID() INTO @sid0;

SET @sid1 = 0;
insert into standards (module_id, title, description, standard_no)
values (@newId, "standard_2", "Emergent Reading: Motivation", 1);
SELECT LAST_INSERT_ID() INTO @sid1;

SET @sid2 = 0;
insert into standards (module_id, title, description, standard_no)
values (@newId, "standard_3", "Mathematical Thinking: Geometry", 2);
SELECT LAST_INSERT_ID() INTO @sid2;

SET @sid3 = 0;
insert into standards (module_id, title, description, standard_no)
values (@newId, "standard_4", "Social Studies: Individual Development and Identity", 3);
SELECT LAST_INSERT_ID() INTO @sid3;


SET @qid0 = 0;
insert into questions (module_id, standard, standard_id, question, sequence, deleted)
values (@newId, null, @sid0, "The standard “Shows age-appropriate phonological awareness” is in what sub-domain of the Language, Communication, and Emergent Literacy domain?", 1, 0);
SELECT LAST_INSERT_ID() INTO @qid0;

insert into answers (question_id, answer_value, correct, sequence)
values (@qid0, "Speaking", 0, 1);
insert into answers (question_id, answer_value, correct, sequence)
values (@qid0, "Sentences and Structure", 0, 2);
insert into answers (question_id, answer_value, correct, sequence)
values (@qid0, "Conversation", 0, 3);
insert into answers (question_id, answer_value, correct, sequence)
values (@qid0, "Emergent Reading", 1, 4);


SET @qid1 = 0;
insert into questions (module_id, standard, standard_id, question, sequence, deleted)
values (@newId, null, @sid1, "The standard “Shows motivation for reading” is in what developmental domain?", 2, 0);
SELECT LAST_INSERT_ID() INTO @qid1;

insert into answers (question_id, answer_value, correct, sequence)
values (@qid1, "Language, Communication, and Emergent Literacy", 1, 1);
insert into answers (question_id, answer_value, correct, sequence)
values (@qid1, "Cognitive Development and General Knowledge", 0, 2);
insert into answers (question_id, answer_value, correct, sequence)
values (@qid1, "Approaches to Learning", 0, 3);
insert into answers (question_id, answer_value, correct, sequence)
values (@qid1, "Physical Development", 0, 4);


SET @qid2 = 0;
insert into questions (module_id, standard, standard_id, question, sequence, deleted)
values (@newId, null, @sid2, "The standard “Understands various two-dimensional shapes, including circle, triangle, square, rectangle, oval, and other less common shapes” is in what area of the Mathematical Thinking sub-domain?", 3, 0);
SELECT LAST_INSERT_ID() INTO @qid2;

insert into answers (question_id, answer_value, correct, sequence)
values (@qid2, "Spatial Relations", 0, 1);
insert into answers (question_id, answer_value, correct, sequence)
values (@qid2, "Numbers and Operations", 0, 2);
insert into answers (question_id, answer_value, correct, sequence)
values (@qid2, "Geometry", 1, 3);
insert into answers (question_id, answer_value, correct, sequence)
values (@qid2, "Patterns and Seriation", 0, 4);



SET @qid3 = 0;
insert into questions (module_id, standard, standard_id, question, sequence, deleted)
values (@newId, null, @sid3, "The standard “Shows awareness and describes some social roles and jobs that people do” is in what area of the Social Studies sub-domain?", 4, 0);
SELECT LAST_INSERT_ID() INTO @qid3;

insert into answers (question_id, answer_value, correct, sequence)
values (@qid3, "People, Places and Environments", 0, 1);
insert into answers (question_id, answer_value, correct, sequence)
values (@qid3, "Technology in Our World", 0, 2);
insert into answers (question_id, answer_value, correct, sequence)
values (@qid3, "Individual Development and Identity", 1, 3);
insert into answers (question_id, answer_value, correct, sequence)
values (@qid3, "Civic Ideals and Practices", 0, 4);

 
