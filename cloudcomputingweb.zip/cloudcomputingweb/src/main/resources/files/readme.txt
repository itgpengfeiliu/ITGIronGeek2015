Set-up.....................
First Install Tomact7, MySQl
Create system variable KIDVISION_HOME and set the path (ex. E:\kidvision)
create new folder '.youtube-api-oauth-credentials' under $KIDVISION_HOM\vpk\ (ex E:\kidvision\vpk\.youtube-api-oauth-credentials)
copy "myuploads" and "YoutubeUploadVideoImpl" files under $KIDVISION_HOM\vpk\.youtube-api-oauth-credentials
copy kidvision.properties file under $KIDVISION_HOM\vpk\
change the kidvision.properties property value based on your mysql environment (database.username and database.password)

Database set-up.......................
open Mysql Workbench, login to localhost database
create new schema "vpk" in mysql, this is to import client existing data
run "vpksqldump.sql" script on "vpk" schema, this will create the schema and load data
Now run script "kidvisiondb.sql", this will create new schema name "kidvisiondb" and tabes.
Now run "data-migrate-script.sql" script, this will load the data from vpk database to kidvisondb database
make sure, all scripts executes without any error.

executing sql scripts from command line
#open command prompt
#navigate to mysqld path, in my case mysqld.exe is in C:\Program Files\MySQL\MySQL Server 5.6\bin location 
cd C:\Program Files\MySQL\MySQL Server 5.6\bin
mysql -uroot -p
#enter password when asked
#enter \. <path to 'kidvisiondb.sql" file> in my case 'kidvisiondb.sql' file is in C:\Users\patha_000\Dropbox\kidvision\setup so
\. C:\Users\patha_000\Dropbox\kidvision\setup\kidvisiondb.sql
#similarly run the data-migrate-script.sql and then 'update-user-test-table.sql' script

Site Deployment
Open system services and stop the "Apache Tomcat 7.0 Tomcat7" service
copy empathweb.war under tomcat7 webapp folder (ex. C:\Program Files\Apache Software Foundation\Tomcat 7.0\webapps)
start the "Apache Tomcat 7.0 Tomcat7" service

open browser and navigate to http://localhost:8080/kidvisionweb

# Current youtube account Info
register with email: pliu@comexpinc.com
password: 51cragwood


# Recovery username and password email sent from
# communicationexpertsnj@gmail.com
# password: 51cragwood
kidvisionvpk@gmail.com
kidvisionvpk2014

#Youtube video references
If the current youtube account is changed then we need to do following steps
1. Update video stream id on index.jsp file
2. Update video stream id on teacher_development.jsp page.
3. Update video stream id on build_portfolios_video.html page

Sequence for script execution
1. restore latest VPK database in to 'vpk' db
2. run kidvisiondb.sql
3. run data-migrate-script.sql
4. run update-user-test-table.sql
4. run table-alter-script.sql
5. run store-procedures-script.sql
6. run table-indexes-script-.sql
//latest vpk db has this module already 7. run insert_post_office_module.sql

<Context docBase="/opt/kidvision/vpk/module_images" path="/moduleimage" />
<Context docBase="/opt/kidvision/vpk/module_icons" path="/moduleicon" />
<Context docBase="/opt/kidvision/vpk/module_resource_images" path="/moduleresourceimage" />