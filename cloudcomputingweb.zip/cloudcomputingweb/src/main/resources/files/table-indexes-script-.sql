/* create indexes on tables */
/* index on table user_module_test_answers */
CREATE INDEX idx_user_module_test_answers_user_module_test_id ON user_module_test_answers (user_module_test_id);
/* index on table user_module_test */
CREATE INDEX idx_UserModuleTest_user_id ON user_module_test (user_id);
CREATE INDEX idx_UserModuleTest_module_id ON user_module_test (module_id);
/* index on table standards */
CREATE INDEX idx_standards_module_id ON standards (module_id);
/* index on table users_login */
CREATE INDEX idx_users_login_user_id ON users_login (user_id);

-- 08/04/2014
CREATE INDEX idx_registration_user_id ON registration (user_id);