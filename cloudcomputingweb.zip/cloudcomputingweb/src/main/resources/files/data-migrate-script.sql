/*clean data */
/* lookup data */
/* SET SQL_SAFE_UPDATES=0; */
delete from kidvisiondb.config;
delete from kidvisiondb.occupational_titles;
delete from kidvisiondb.roles;
delete from kidvisiondb.registrationtypes;
delete from kidvisiondb.resource_type;
delete from kidvisiondb.authentication_questions;

/* import transaction data */
delete from kidvisiondb.users;
delete from kidvisiondb.modules;
delete from kidvisiondb.standards;
delete from kidvisiondb.videos;
delete from kidvisiondb.questions;
delete from kidvisiondb.answers;
delete from kidvisiondb.survey_results;
delete from kidvisiondb.user_module_test;
delete from kidvisiondb.user_module_test_answers;
delete from kidvisiondb.user_module_certificate;
delete from kidvisiondb.user_module_activity;
delete from kidvisiondb.user_pretest_answers;

/* insert config data */
INSERT INTO kidvisiondb.config
(id, tm_registration_amount,discount_amount, current_school_year_from, current_school_year_to)
VALUES(1,30,5, '2013-07-01 00:00:00', '2014-07-01 00:00:00');

/* insert occupational_titles data */
insert into kidvisiondb.occupational_titles(occupational_title)
values('VPK Teacher');
insert into kidvisiondb.occupational_titles(occupational_title)
values('Teacher');
insert into kidvisiondb.occupational_titles(occupational_title)
values('Teacher Aide');
insert into kidvisiondb.occupational_titles(occupational_title)
values('Administrator');
insert into kidvisiondb.occupational_titles(occupational_title)
values('Early Childhood Specialist');
insert into kidvisiondb.occupational_titles(occupational_title)
values('Other');


/* insert roles data */
Insert into kidvisiondb.roles
(id, role_name)
values(1, 'Administrator');
Insert into roles
(id, role_name)
values(2, 'User');

/* insert registrationtypes data */
INSERT INTO kidvisiondb.registrationtypes
(id,registrationtype_name)
VALUES(1,'General');
INSERT INTO kidvisiondb.registrationtypes
(id,registrationtype_name)
VALUES(2,'Teacher Membership');

/* insert resource_type data */
Insert into kidvisiondb.resource_type
(id, type_name)
values(1, 'All');
Insert into kidvisiondb.resource_type
(id, type_name)
values(2, 'Teacher');
Insert into kidvisiondb.resource_type
(id, type_name)
values(3, 'Parent');
Insert into kidvisiondb.resource_type
(id, type_name)
values(4, 'Module');

/* insert kidvisiondb.authentication_questions data */
insert into kidvisiondb.authentication_questions(question)
values('What is my favorite subject in High School?');
insert into kidvisiondb.authentication_questions(question)
values('What is the name of the street you grew up in?');
insert into kidvisiondb.authentication_questions(question)
values('What is the name of your best friend in Elementary School?');
insert into kidvisiondb.authentication_questions(question)
values('What is the name of your first pet?');
insert into kidvisiondb.authentication_questions(question)
values('What is your Mother`s maiden name?');

/* insert system user entry */
INSERT INTO kidvisiondb.users
	(id, first_name, last_name, user_name, email, password, occupational_title_id, other_occupational_title, facility_type, email_notification, is_active, role_id, created_on, updated_on, createdby_id, updatedby_id)
VALUES
	(0, 'sys', 'admin', 'sysadmin', 'sp@comexpinc.com', 'sys123#', 6, 'Systeam Administrator', null, 0, 1,1,now() ,null ,0 ,null );

update kidvisiondb.users set id=0 where user_name='sysadmin';

/*insert user data */
INSERT INTO kidvisiondb.users 
SELECT 
id, 
first_name, 
last_name,
null, 
user_name, 
password, 
email, 
CASE when is_admin=1 then 1 else 2 END as 'role_id' ,
null,
null,
facility_type,
send_mail,
null,
null,
null,
null,
null,
null,
"1",
created_on,
updated_on,
0,
null,
is_active
FROM vpk.users;

/* update user occupattion*/
update kidvisiondb.users ku
inner join vpk.users vu on ku.id=vu.id
inner join kidvisiondb.occupational_titles ko on vu.occuption=ko.occupational_title
set ku.occupational_title_id=ko.id,
ku.other_occupational_title=vu.other_occuption;

update kidvisiondb.users ku
inner join vpk.users vu on ku.id=vu.id
inner join kidvisiondb.occupational_titles ko on upper(vu.pos_title)=upper(ko.occupational_title)
set ku.occupational_title_id=ko.id
where vu.pos_title is not null and vu.pos_title <> '' and vu.occuption is null;

update kidvisiondb.users ku inner join vpk.users vu on ku.id=vu.id
set ku.occupational_title_id=6,
ku.other_occupational_title=vu.pos_title
where 
ku.occupational_title_id is null 
and ku.other_occupational_title is null
and vu.pos_title is not null 
and vu.pos_title <> ''
and vu.occuption is null;

/* insert kidvisiondb.registration data */
insert into kidvisiondb.registration
select distinct
null,
ku.id,
0,
'2013-07-01 00:00:00',
'2014-07-01 00:00:00',
now(),
0,
null,
null,
1
from vpk.users vu 
inner join vpk.user_certificates vuc on vu.id=vuc.user_id
inner join kidvisiondb.users ku on vu.id=ku.id
where ku.role_id =2;

/* update kidvisiondb.user registration data */
update kidvisiondb.users ku inner join kidvisiondb.registration kr on ku.id=kr.user_id
set ku.current_registration_id=kr.id, ku.registrationtype_id=2;

update kidvisiondb.users ku set ku.registrationtype_id=1 where ku.registrationtype_id is null;

update kidvisiondb.users ku inner join vpk.users vu on ku.id=vu.id 
set ku.school_name=vu.facility_name
where ku.id=vu.id and (ku.school_name is null or trim(ku.school_name) <> '') and trim(vu.facility_name) <> '';

/* insert modules data*/
insert into kidvisiondb.modules
SELECT
	id,
	title,
	null,
	description,
	pdf_lesson_plan,
	student_assessment_form,
	activity_plan,
	coloring_worksheets,
	image_file,
	icon_file,
	sequence,
	created_on,
	0,
	updated_on,
	null,
	deleted
FROM
	vpk.modules;
	
/* Insert modules standards NULL */
INSERT INTO kidvisiondb.standards
select 0, id, 'standard_1', standard_1, 1 from vpk.modules;
INSERT INTO kidvisiondb.standards
select 0, id, 'standard_2', standard_2, 2 from vpk.modules;
INSERT INTO kidvisiondb.standards
select 0, id, 'standard_3', standard_3, 3 from vpk.modules;
INSERT INTO kidvisiondb.standards
select 0, id, 'standard_4', standard_4, 4 from vpk.modules;

/* insert videos */
insert into kidvisiondb.videos
SELECT
	id,
	module_id,
	file,
	null,
	is_overview,
	sequence,
	created_on,
	0
FROM
	vpk.videos;

/* insert questions */
insert into kidvisiondb.questions
SELECT
	q.id,
	t.module_id,
	q.standard,
	null,
	q.copy,
	q.sequence,
	q.deleted
	
FROM
	vpk.questions q 
	inner join vpk.tests t on q.test_id=t.id;
/* update question standard_id */
update questions 
inner join standards on questions.module_id=standards.module_id 
	 AND questions.standard=standards.title
set questions.standard_id=standards.id;

/* insert answers */
insert into kidvisiondb.answers
SELECT
	id,
	question_id,
	copy,
	correct,
	sequence
FROM
	vpk.answers;
	
/* insert survey_questions */
insert into kidvisiondb.survey_questions
values (1, "Was the training a positive learning experience?", 1, 0, null, null, null, null);
insert into kidvisiondb.survey_questions
values (2, "Did the field trip and support materials support your learning process?", 2, 0, null, null, null, null);
insert into kidvisiondb.survey_questions
values (3, "Was the information presented in a clear and logical format?", 3, 0, null, null, null, null);
insert into kidvisiondb.survey_questions
values (4, "Has your understanding of the VPK Education Standards increased as a result of this training?", 4, 0, null, null, null, null);
insert into kidvisiondb.survey_questions
values (5, "How do you intend to use the KidVision VPK program? Please check all that apply:", 5, 0, null, null, null, null);

/* insert survey_results data*/
insert into kidvisiondb.survey_results
select question, yes, no from vpk.survey_results;

/* insert user module test data */
insert into kidvisiondb.user_module_test
SELECT
	user_tests.id,
	user_tests.user_id,
	tests.module_id,
	null,
	null,
	null,
	null,
	user_tests.created_on,
	user_tests.created_on
FROM
	vpk.tests
	INNER JOIN vpk.user_tests
	 ON tests.id = user_tests.test_id;
	 
/* insert user_module_test_answers data */
insert into kidvisiondb.user_module_test_answers
SELECT
	user_answers.id,
	user_answers.user_id,
	user_answers.user_test_id,
	user_answers.question_id,
	user_answers.answer_id,
	user_answers.created_on
FROM
	vpk.user_answers;
	
	
/* insert user_module_certificate data*/

insert into kidvisiondb.user_module_certificate
SELECT
	user_certificates.id,
	user_certificates.user_id,
	user_certificates.module_id,
	user_certificates.file,
	user_certificates.created_on
FROM
	vpk.user_certificates;

/* insert user_module_activity data */
insert into kidvisiondb.user_module_activity
select id, user_id, module_id, bookmark, null, viewed_videos, created_on, completed_on from vpk.user_modules;

/* insert kidvisiondb.user_pretest_answers data */
insert into kidvisiondb.user_pretest_answers
select 
qr.id,
qr.user_id,
qr.question_id,
qr.answer_id,
qr.created_on
from vpk.questionnaire_results qr;


/* insert resources data*/
delete from resources;
insert into resources (id, type_id, title,short_description, resource_url, image_file_path, created_by, created_on, modified_by, modified_on, deleted)
values (null, 4, 'Akido Dojo','Florida Aikido School', 'http://www.floridaaikikai.com/','akido_dojo.jpg',0,now(), null, null,0);

insert into resources (id, type_id, title,short_description, resource_url, image_file_path, created_by, created_on, modified_by, modified_on, deleted)
values (null, 4, 'Miami Airport','Tamiami Airport', 'http://www.miami-airport.com/kendall_tamiami.asp','miami_airport.jpg',0,now(), null, null,0);

insert into resources (id, type_id, title,short_description, resource_url, image_file_path, created_by, created_on, modified_by, modified_on, deleted)
values (null, 4, 'Animal Shelter','Palm Beach Animal Shelter', 'http://www.pbcgov.com/publicsafety/animalcare/','palmbeachanimalshelter.jpg',0,now(), null, null,0);

insert into resources (id, type_id, title,short_description, resource_url, image_file_path, created_by, created_on, modified_by, modified_on, deleted)
values (null, 4, 'Aquatic Complex','Ft. Lauderdale Aquatic Complex & International Swimming Hall of Fame', '"http://www.ishof.org/','aquatic_complex.jpg',0,now(), null, null,0);

insert into resources (id, type_id, title,short_description, resource_url, image_file_path, created_by, created_on, modified_by, modified_on, deleted)
values (null, 4, 'Bake Shop','Sweeter Days Bake Shop', 'http://www.sweeterdaysbakeshop.com/','bake_shop.jpg',0,now(), null, null,0);

insert into resources (id, type_id, title,short_description, resource_url, image_file_path, created_by, created_on, modified_by, modified_on, deleted)
values (null, 4, 'Bank & Money','Sun Trust Bank Miami Beach Branch', 'https://www.suntrust.com/FindUs?storesearch=33139','suntrustmiamibeach.jpg',0,now(), null, null,0);

insert into resources (id, type_id, title,short_description, resource_url, image_file_path, created_by, created_on, modified_by, modified_on, deleted)
values (null, 4, 'Baseball','Marlin?s Baseball Park', 'http://miami.marlins.mlb.com/index.jsp?c_id=mia','miamimarlins.jpg',0,now(), null, null,0);

insert into resources (id, type_id, title,short_description, resource_url, image_file_path, created_by, created_on, modified_by, modified_on, deleted)
values (null, 4, 'Biscayne National Park','Biscayne National Park', 'http://www.nps.gov/bisc/index.htm','biscaynenationalpark.jpg',0,now(), null, null,0);

insert into resources (id, type_id, title,short_description, resource_url, image_file_path, created_by, created_on, modified_by, modified_on, deleted)
values (null, 4, 'Butterfly World','Butterfly World at Tradewinds Park', 'http://www.butterflyworld.com/','butterflyworld.jpg',0,now(), null, null,0);

insert into resources (id, type_id, title,short_description, resource_url, image_file_path, created_by, created_on, modified_by, modified_on, deleted)
values (null, 4, 'Children`s Hospital','Joe DiMaggio Children`s Hospital', 'http://www.jdch.com/','joedimaggiohospital.jpg',0,now(), null, null,0);

insert into resources (id, type_id, title,short_description, resource_url, image_file_path, created_by, created_on, modified_by, modified_on, deleted)
values (null, 4, 'Children`s Theater','Ft. Lauderdale Children?s Theater', 'http://www.flct.org/','ftlauderdalechildrenstheater.jpg',0,now(), null, null,0);

insert into resources (id, type_id, title,short_description, resource_url, image_file_path, created_by, created_on, modified_by, modified_on, deleted)
values (null, 4, 'Construction Site','Suffolk Construction', 'http://www.suffolkconstruction.com/','suffolkconstruction.jpg',0,now(), null, null,0);

insert into resources (id, type_id, title,short_description, resource_url, image_file_path, created_by, created_on, modified_by, modified_on, deleted)
values (null, 4, 'Dentist`s Office','Miami Children`s Smiles Pediatric Dentistry', 'https://www.miamichildrensmiles.com/','miamichildrenssmiles.jpg',0,now(), null, null,0);

insert into resources (id, type_id, title,short_description, resource_url, image_file_path, created_by, created_on, modified_by, modified_on, deleted)
values (null, 4, 'Fire Station','Hollywood Fire Rescue Station #74', 'http://www.hollywoodfl.org/index.aspx?NID=95','fire_station.jpg',0,now(), null, null,0);

insert into resources (id, type_id, title,short_description, resource_url, image_file_path, created_by, created_on, modified_by, modified_on, deleted)
values (null, 4, 'Flamingo Gardens','Flamingo Gardens', 'http://www.flamingogardens.org/','flamingo_garden.jpg',0,now(), null, null,0);

insert into resources (id, type_id, title,short_description, resource_url, image_file_path, created_by, created_on, modified_by, modified_on, deleted)
values (null, 4, 'G.R.O.W. Project','G.R.O.W. Project', 'http://www.miamigrowproject.org/','grow_project.jpg',0,now(), null, null,0);

insert into resources (id, type_id, title,short_description, resource_url, image_file_path, created_by, created_on, modified_by, modified_on, deleted)
values (null, 4, 'Grocery Store','Whole Foods Market Aventura', 'http://www.wholefoodsmarket.com/stores/aventura','grocery_store.jpg',0,now(), null, null,0);

insert into resources (id, type_id, title,short_description, resource_url, image_file_path, created_by, created_on, modified_by, modified_on, deleted)
values (null, 4, 'Gymnastics','Miami Gymnastics and Dance Academy', 'http://www.miamigymnastics.com/','gymnastics.jpg',0,now(), null, null,0);

insert into resources (id, type_id, title,short_description, resource_url, image_file_path, created_by, created_on, modified_by, modified_on, deleted)
values (null, 4, 'Healthy Foods at Jungle Island','Jungle Island', 'http://www.jungleisland.com/','healthy_food.jpg',0,now(), null, null,0);

insert into resources (id, type_id, title,short_description, resource_url, image_file_path, created_by, created_on, modified_by, modified_on, deleted)
values (null, 4, 'Horse Farm','Condee Horse Farm', 'http://www.condeefarm.com/','horse_farm.jpg',0,now(), null, null,0);

insert into resources (id, type_id, title,short_description, resource_url, image_file_path, created_by, created_on, modified_by, modified_on, deleted)
values (null, 4, 'Kindergarten','Oakridge Elementary School', 'http://oakridge.browardschools.com/','kindergarten.jpg',0,now(), null, null,0);

insert into resources (id, type_id, title,short_description, resource_url, image_file_path, created_by, created_on, modified_by, modified_on, deleted)
values (null, 4, 'Kites','Skyward Kites', 'https://sites.google.com/site/skywardkites/home/','kites.jpg',0,now(), null, null,0);

insert into resources (id, type_id, title,short_description, resource_url, image_file_path, created_by, created_on, modified_by, modified_on, deleted)
values (null, 4, 'Kites','Haulover Park', 'http://www.miamidade.gov/parks/haulover.asp','kites_park.jpg',0,now(), null, null,0);

insert into resources (id, type_id, title,short_description, resource_url, image_file_path, created_by, created_on, modified_by, modified_on, deleted)
values (null, 4, 'Library','Miami-Dade Public Library Coral Gables Branch', 'http://www.mdpls.org/','library.jpg',0,now(), null, null,0);

insert into resources (id, type_id, title,short_description, resource_url, image_file_path, created_by, created_on, modified_by, modified_on, deleted)
values (null, 4, 'Music Store','Sam Ash Music Store Miami Lakes', 'http://samashmusic.com/portal/','music_store.jpg',0,now(), null, null,0);

insert into resources (id, type_id, title,short_description, resource_url, image_file_path, created_by, created_on, modified_by, modified_on, deleted)
values (null, 4, 'Native Village','Native Village', 'http://nativevillagezoo.angelfire.com/','native_village.jpg',0,now(), null, null,0);

insert into resources (id, type_id, title,short_description, resource_url, image_file_path, created_by, created_on, modified_by, modified_on, deleted)
values (null, 4, 'Oceanographic Center','Nova Southeastern University Oceanographic Center', 'http://www.nova.edu/ocean/','oceanographic.jpg',0,now(), null, null,0);

insert into resources (id, type_id, title,short_description, resource_url, image_file_path, created_by, created_on, modified_by, modified_on, deleted)
values (null, 4, 'Paper Niche',null, 'http://www.paperniche.com','paper_niche.jpg',0,now(), null, null,0);

insert into resources (id, type_id, title,short_description, resource_url, image_file_path, created_by, created_on, modified_by, modified_on, deleted)
values (null, 4, 'Pizza Restaurant','Peace A Pizza', 'http://www.PeaceAPizza.com','pizza_restaurant.jpg',0,now(), null, null,0);

insert into resources (id, type_id, title,short_description, resource_url, image_file_path, created_by, created_on, modified_by, modified_on, deleted)
values (null, 4, 'Playground','T.Y. Park', 'http://www.broward.org/parks/TopeekeegeeYugneePark/pages/default.aspx','playground.jpg',0,now(), null, null,0);

insert into resources (id, type_id, title,short_description, resource_url, image_file_path, created_by, created_on, modified_by, modified_on, deleted)
values (null, 4, 'Pottery Studio','Palm Beach Animal Shelter', 'http://www.joepicassos.com','pottery_studio.jpg',0,now(), null, null,0);

insert into resources (id, type_id, title,short_description, resource_url, image_file_path, created_by, created_on, modified_by, modified_on, deleted)
values (null, 4, 'Railroad Museum','Gold Coast Railroad Museum', 'http://gcrm.org/','railroad_museum.jpg',0,now(), null, null,0);

insert into resources (id, type_id, title,short_description, resource_url, image_file_path, created_by, created_on, modified_by, modified_on, deleted)
values (null, 4, 'Recycling Center','Waste Services of Florida', 'http://www.wasteservicesinc.com','recycling_center.jpg',0,now(), null, null,0);

insert into resources (id, type_id, title,short_description, resource_url, image_file_path, created_by, created_on, modified_by, modified_on, deleted)
values (null, 4, 'ReThink and ReUse Center','ReThink and ReUse Center', 'http://www.rethinkandreusemiami.org','rethink_reusecenter.jpg',0,now(), null, null,0);

insert into resources (id, type_id, title,short_description, resource_url, image_file_path, created_by, created_on, modified_by, modified_on, deleted)
values (null, 4, 'School Bus Depot','Miami-Dade County Public Schools Department of Transportation', 'http://dot.dadeschools.net','school_busdepot.jpg',0,now(), null, null,0);

insert into resources (id, type_id, title,short_description, resource_url, image_file_path, created_by, created_on, modified_by, modified_on, deleted)
values (null, 4, 'Science Museum','Miami Science Museum', 'https://www.miamisci.org','science_museum.jpg',0,now(), null, null,0);

insert into resources (id, type_id, title,short_description, resource_url, image_file_path, created_by, created_on, modified_by, modified_on, deleted)
values (null, 4, 'Sheriff`s Office','Martin County Sheriff?s Office', 'http://www.sheriff.martin.fl.us','sheriffs_office.jpg',0,now(), null, null,0);

insert into resources (id, type_id, title,short_description, resource_url, image_file_path, created_by, created_on, modified_by, modified_on, deleted)
values (null, 4, 'TV Station','WPBT Channel 2', 'http://www.wpbt2.org','tv_station.jpg',0,now(), null, null,0);

insert into resources (id, type_id, title,short_description, resource_url, image_file_path, created_by, created_on, modified_by, modified_on, deleted)
values (null, 4, 'Weather Station','National Weather Service & National Hurricane Center', 'http://www.weather.gov/miami','weather_station.jpg',0,now(), null, null,0);

insert into resources (id, type_id, title,short_description, resource_url, image_file_path, created_by, created_on, modified_by, modified_on, deleted)
values (null, 4, 'Young At Art Museum','Young At Art Museum', 'http://www.YoungAtArtMuseum.org','young_museum.jpg',0,now(), null, null,0);

insert into resources (id, type_id, title,short_description, resource_url, image_file_path, created_by, created_on, modified_by, modified_on, deleted)
values (null, 4, 'Zoo','Zoo Miami', 'http://www.zoomiami.org','zoomiami.jpg',0,now(), null, null,0);


/* insert module resources data */
-- insert module_resources data
insert into module_resources (id, module_id, resource_id, deleted)
values( null, 121,1,0);
insert into module_resources (id, module_id, resource_id, deleted)
values( null, 122,2,0);
insert into module_resources (id, module_id, resource_id, deleted)
values( null, 123,3,0);
insert into module_resources (id, module_id, resource_id, deleted)
values( null, 124,4,0);
insert into module_resources (id, module_id, resource_id, deleted)
values( null, 125,5,0);
insert into module_resources (id, module_id, resource_id, deleted)
values( null, 126,6,0);
insert into module_resources (id, module_id, resource_id, deleted)
values( null, 127,7,0);
insert into module_resources (id, module_id, resource_id, deleted)
values( null, 128,8,0);
insert into module_resources (id, module_id, resource_id, deleted)
values( null, 129,9,0);
insert into module_resources (id, module_id, resource_id, deleted)
values( null, 130,10,0);
insert into module_resources (id, module_id, resource_id, deleted)
values( null, 131,11,0);
insert into module_resources (id, module_id, resource_id, deleted)
values( null, 132,12,0);

insert into module_resources (id, module_id, resource_id, deleted)
values( null, 133,13,0);
insert into module_resources (id, module_id, resource_id, deleted)
values( null, 134,14,0);
insert into module_resources (id, module_id, resource_id, deleted)
values( null, 135,15,0);
insert into module_resources (id, module_id, resource_id, deleted)
values( null, 137,16,0);
insert into module_resources (id, module_id, resource_id, deleted)
values( null, 136,17,0);
insert into module_resources (id, module_id, resource_id, deleted)
values( null, 138,18,0);
insert into module_resources (id, module_id, resource_id, deleted)
values( null, 139,19,0);
insert into module_resources (id, module_id, resource_id, deleted)
values( null, 140,20,0);
insert into module_resources (id, module_id, resource_id, deleted)
values( null, 141,21,0);
insert into module_resources (id, module_id, resource_id, deleted)
values( null, 142,22,0);
insert into module_resources (id, module_id, resource_id, deleted)
values( null, 142,23,0);
insert into module_resources (id, module_id, resource_id, deleted)
values( null, 143,24,0);
insert into module_resources (id, module_id, resource_id, deleted)
values( null, 144,25,0);
insert into module_resources (id, module_id, resource_id, deleted)
values( null, 145,26,0);
insert into module_resources (id, module_id, resource_id, deleted)
values( null, 146,27,0);
insert into module_resources (id, module_id, resource_id, deleted)
values( null, 147,28,0);
insert into module_resources (id, module_id, resource_id, deleted)
values( null, 148,29,0);
insert into module_resources (id, module_id, resource_id, deleted)
values( null, 150,30,0);
insert into module_resources (id, module_id, resource_id, deleted)
values( null, 149,31,0);
insert into module_resources (id, module_id, resource_id, deleted)
values( null, 152,32,0);
insert into module_resources (id, module_id, resource_id, deleted)
values( null, 151,33,0);
insert into module_resources (id, module_id, resource_id, deleted)
values( null, 153,34,0);
insert into module_resources (id, module_id, resource_id, deleted)
values( null, 154,35,0);
insert into module_resources (id, module_id, resource_id, deleted)
values( null, 155,36,0);
insert into module_resources (id, module_id, resource_id, deleted)
values( null, 156,37,0);
insert into module_resources (id, module_id, resource_id, deleted)
values( null, 157,38,0);
insert into module_resources (id, module_id, resource_id, deleted)
values( null, 158,39,0);
insert into module_resources (id, module_id, resource_id, deleted)
values( null, 159,40,0);
insert into module_resources (id, module_id, resource_id, deleted)
values( null, 160,41,0);


